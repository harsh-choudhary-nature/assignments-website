import gameSettings

class GhostRules:

	def __init__(self, num_rows, num_cols, cost_function):
		self.num_rows = num_rows	
		self.num_cols = num_cols
		self.cost_function = cost_function
		self.check_empty_positions = {	"noop": 			[],
										"left":				[(0,-1)],
										"right":			[(0,1)],
										"jump":				[(-1,0)],
										"short_jump_left":	[(-1,0), (-1,-1)],
										"short_jump_right":	[(-1,0), (-1,1)],
										"long_jump_left":	[(-1,0), (-1,-1), (-1,-2)],
										"long_jump_right":	[(-1,0), (-1,1), (-1,2)]
										}
		self.next_facing = {"left":				"left",
							"right":			"right",
							"short_jump_left":	"left",
							"short_jump_right":	"right",
							"long_jump_left":	"left",
							"long_jump_right":	"right"
							}


	def is_valid(self, pos):
		x, y = pos
		return x>=0 and x<self.num_rows and y>=0 and y<self.num_cols

	def get_actions(self, agent_index, game_state):
		ghost_pos, ghost_active, ghost_reborn = game_state.ghosts_details[agent_index-1].pos, game_state.ghosts_details[agent_index-1].active, game_state.ghosts_details[agent_index-1].reborn
		assert self.is_valid(ghost_pos)

		actions = []

		if ghost_active>0 or ghost_reborn:
			return ["noop"]

		for action in gameSettings.ghost_possible_actions:
			for neigh_pos in self.check_empty_positions[action]:
				next_pos = (ghost_pos[0]+neigh_pos[0], ghost_pos[1]+neigh_pos[1])
				if not self.is_valid(next_pos) or next_pos in game_state.blocks_pos:
					break
			else:
				actions.append(action)	
		return actions

	def get_next_game_state(self, agent_index, game_state, action):
		
		next_game_state = game_state.shallow_copy()
		ghost_pos, ghost_active, ghost_reborn = game_state.ghosts_details[agent_index-1].pos, game_state.ghosts_details[agent_index-1].active, game_state.ghosts_details[agent_index-1].reborn

		if action in self.next_facing:
			next_game_state.ghosts_details[agent_index-1].facing = self.next_facing[action]

		traced_path = [ghost_pos] + [(ghost_pos[0]+neigh_pos[0], ghost_pos[1]+neigh_pos[1]) for neigh_pos in self.check_empty_positions[action]]
		
		next_pos = traced_path[-1]
		while next_pos[0]+1<game_state.num_rows and (next_pos[0]+1,next_pos[1]) not in game_state.blocks_pos:
			next_pos = (next_pos[0]+1,next_pos[1])
			traced_path.append(next_pos)

		player_eaten_at_index_of_traced_path = -1

		for traced_path_index, temp_pos in enumerate(traced_path):

			next_game_state.ghosts_details[agent_index-1].pos = temp_pos
			if temp_pos == next_game_state.player_details.pos:
				assert ghost_active==0 
				if not ghost_reborn:
					player_eaten_at_index_of_traced_path = traced_path_index  # maybe we can show some animation of killed, value is unimportant
					next_game_state.player_details.alive = False
					break
		else:
			next_game_state.ghosts_details[agent_index-1].reborn = False
			next_game_state.ghosts_details[agent_index-1].active = max(next_game_state.ghosts_details[agent_index-1].active-1, 0)

		return next_game_state, traced_path[:traced_path_index+1], player_eaten_at_index_of_traced_path

	def get_actions_from_ghost_pos(self, ghost_pos, blocks_pos):
		assert self.is_valid(ghost_pos)

		actions = [] 

		for action in gameSettings.ghost_possible_actions:
			for neigh_pos in self.check_empty_positions[action]:
				next_pos = (ghost_pos[0]+neigh_pos[0], ghost_pos[1]+neigh_pos[1])
				if not self.is_valid(next_pos) or next_pos in blocks_pos:
					break
			else:
				actions.append(action)
		return actions