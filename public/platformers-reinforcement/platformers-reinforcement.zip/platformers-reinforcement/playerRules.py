import gameSettings
import utils

class PlayerRules:

	def __init__(self, num_rows, num_cols, cost_function):
		self.num_rows = num_rows
		self.num_cols = num_cols
		self.cost_function = cost_function
		self.check_empty_positions = {	"noop": 			[],
										"left":				[(0,-1)],
										"right":			[(0,1)],
										"jump":				[(-1,0)],
										"short_jump_left":	[(-1,0), (-1,-1)],
										"short_jump_right":	[(-1,0), (-1,1)],
										"long_jump_left":	[(-1,0), (-1,-1), (-1,-2)],
										"long_jump_right":	[(-1,0), (-1,1), (-1,2)]
										}
		self.next_facing = {"left":				"left",
							"right":			"right",
							"short_jump_left":	"left",
							"short_jump_right":	"right",
							"long_jump_left":	"left",
							"long_jump_right":	"right"
							}

	def is_valid(self, pos):
		x, y = pos
		return x>=0 and x<self.num_rows and y>=0 and y<self.num_cols

	def get_actions(self, game_state):
		player_pos = game_state.player_details.pos
		assert self.is_valid(player_pos)

		actions = []

		for action in gameSettings.possible_actions:
			for neigh_pos in self.check_empty_positions[action]:
				next_pos = (player_pos[0]+neigh_pos[0], player_pos[1]+neigh_pos[1])
				if not self.is_valid(next_pos) or next_pos in game_state.blocks_pos:
					break
			else:
				actions.append(action)
		return actions

	def get_actions_from_player_pos(self, player_pos, blocks_pos):
		assert self.is_valid(player_pos)

		actions = []

		for action in gameSettings.possible_actions:
			for neigh_pos in self.check_empty_positions[action]:
				next_pos = (player_pos[0]+neigh_pos[0], player_pos[1]+neigh_pos[1])
				if not self.is_valid(next_pos) or next_pos in blocks_pos:
					break
			else:
				actions.append(action)
		return actions

	def get_next_game_state(self, game_state, action):
		
		next_game_state = game_state.shallow_copy()
		player_pos = game_state.player_details.pos

		if action in self.next_facing:
			next_game_state.player_details.facing = self.next_facing[action]

		traced_path = [player_pos] + [(player_pos[0]+neigh_pos[0], player_pos[1]+neigh_pos[1]) for neigh_pos in self.check_empty_positions[action]]

		
		next_pos = traced_path[-1]
		while next_pos[0]+1<game_state.num_rows and (next_pos[0]+1,next_pos[1]) not in game_state.blocks_pos:
			next_pos = (next_pos[0]+1,next_pos[1])
			traced_path.append(next_pos)


		food_indices_eaten_at_index_of_traced_path = dict()
		freezer_indices_eaten_at_index_of_traced_path = dict()
		inactive_ghost_indices_eaten_at_index_of_traced_path = dict()
		active_ghost_indices_eaten_at_index_of_traced_path = dict()		# no visible impact for frozen ghosts eaten

		# eat the foods, freezers, inactive ghosts and beware of live ghosts
		for traced_path_index, temp_pos in enumerate(traced_path):
			# typically, jump and noop have no effect
			next_game_state.player_details.pos = temp_pos

			# check food
			if temp_pos in next_game_state.foods_pos:
				food_indices_eaten_at_index_of_traced_path[traced_path_index] = utils.get_all_indices(game_state.foods_pos, temp_pos)
				next_game_state.foods_pos.remove(temp_pos)

			if len(next_game_state.foods_pos) == 0:
				break

			# check freezer
			if temp_pos in next_game_state.freezers_pos:
				freezer_indices_eaten_at_index_of_traced_path[traced_path_index] = utils.get_all_indices(game_state.freezers_pos, temp_pos)
				next_game_state.freezers_pos.remove(temp_pos)
				for ghost_details in next_game_state.ghosts_details:
					ghost_details.active = gameSettings.freeze_duration

			# check ghost
			'''*** so if freezer and ghost at same position, then first ghost freezes and then reborns'''
			for i in range(len(next_game_state.ghosts_details)):
				if temp_pos == next_game_state.ghosts_details[i].pos:
					if next_game_state.ghosts_details[i].active>0:
						if traced_path_index in inactive_ghost_indices_eaten_at_index_of_traced_path:
							inactive_ghost_indices_eaten_at_index_of_traced_path[traced_path_index].append((i, temp_pos))
						else:
							inactive_ghost_indices_eaten_at_index_of_traced_path[traced_path_index] = [(i, temp_pos)]
						next_game_state.ghosts_details[i].active = 0
						next_game_state.ghosts_details[i].reborn = True
						next_game_state.ghosts_details[i].pos = next_game_state.ghosts_details[i].initial_pos  # due to this, now the same ghost may collide on further temp_pos in traced_path, so it will not be allowed to eat as it would have been reborn
					elif next_game_state.ghosts_details[i].reborn:
						continue
					else:
						if traced_path_index in active_ghost_indices_eaten_at_index_of_traced_path:
							active_ghost_indices_eaten_at_index_of_traced_path[traced_path_index].append(i)
						else:
							active_ghost_indices_eaten_at_index_of_traced_path[traced_path_index] = [i]
						next_game_state.player_details.alive = False
						break 		# once player killed, it cannot eat anymore food

			if not next_game_state.player_details.alive:
				break

		return next_game_state, traced_path[:traced_path_index+1], food_indices_eaten_at_index_of_traced_path, freezer_indices_eaten_at_index_of_traced_path, inactive_ghost_indices_eaten_at_index_of_traced_path, active_ghost_indices_eaten_at_index_of_traced_path