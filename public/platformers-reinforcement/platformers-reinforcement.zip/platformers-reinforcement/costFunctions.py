import gameSettings


def distance_based_cost(agent_index, game_state, action, next_game_state):
	if agent_index == 0:

		cur_pos = game_state.player_details.pos
		next_pos = next_game_state.player_details.pos
		default_distance_travelled = {	"noop":				1,
										"left":				1,
										"right":			1,
										"jump":				2,
										"short_jump_left":	2,
										"short_jump_right":	2,
										"long_jump_left":	3,
										"long_jump_right":	3
										}
		extra_distance_travelled = {	"noop":				0,
										"left":				next_pos[0]-cur_pos[0],
										"right":			next_pos[0]-cur_pos[0],
										"jump":				0,
										"short_jump_left":	next_pos[0]-cur_pos[0] + 1,
										"short_jump_right":	next_pos[0]-cur_pos[0] + 1,
										"long_jump_left":	next_pos[0]-cur_pos[0] + 1,
										"long_jump_right":	next_pos[0]-cur_pos[0] + 1

										}
		dist_travelled = default_distance_travelled[action] + extra_distance_travelled[action]
		foods_eaten = len(game_state.foods_pos)-len(next_game_state.foods_pos)
		inactive_ghosts_eaten = len([1 for ghost_details in next_game_state.ghosts_details if ghost_details.reborn])
		player_died = 1 if not next_game_state.player_details.alive else 0
		food_over = 1 if len(next_game_state.foods_pos)==0 else 0

		points = gameSettings.points_per_move*dist_travelled + gameSettings.points_per_food*foods_eaten + gameSettings.points_per_ghost*inactive_ghosts_eaten + gameSettings.points_for_losing*player_died + gameSettings.points_for_winning*food_over
		return -points
	else:

		player_died = 1 if not next_game_state.player_details.alive else 0

		points = gameSettings.points_for_losing*player_died
		return -points 
	