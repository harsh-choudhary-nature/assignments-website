import pygame
import utils
import featureExtractor

class KeyboardAgent:
	def __init__(self, args):
		pass

	def act(self, state, problem):
		keys = pygame.key.get_pressed()
		actions = problem.get_actions(0, state)		# player is always index 0, and actions will be different based on mdp or platformer

		if keys[pygame.K_LEFT] and "left" in actions:
			action = "left"
		elif keys[pygame.K_RIGHT] and "right" in actions:
			action = "right"
		elif keys[pygame.K_UP] and "up" in actions:
			action = "up"
		elif keys[pygame.K_DOWN] and "down" in actions:
			action = "down"
		elif keys[pygame.K_SPACE] and "jump" in actions:
			action = "jump"
		elif keys[pygame.K_a] and "long_jump_left" in actions:
			action = "long_jump_left"
		elif keys[pygame.K_s] and "short_jump_left" in actions:
			action = "short_jump_left"
		elif keys[pygame.K_d] and "short_jump_right" in actions:
			action = "short_jump_right"
		elif keys[pygame.K_f] and "long_jump_right" in actions:
			action = "long_jump_right"
		else:
			action = "noop"

		return action

class RandomAgent:
    def __init__(self, args):
        self.rng = args['rng']

    def act(self, state, problem):
        actions = problem.get_actions(0, state)		# player is always index 0
        return self.rng.choice(actions)

class ValueIterationAgent:
	'''
	Guaranteed for only MDP problems.
	1. Runs value iteration algorithm.
	2. The no. of iterations is given in self.iterations.
	3. You can check for convergence, but do not break early on convergence.
	4. The values should match upto rounding till 5th decimal place.
	5. Terminal states have value 0 and policy None, and they have no entry in Q Table
	'''
	def __init__(self, args):
		self.rng = args['rng']
		self.iterations = args['iterations']
		self.discount = args['discount']

		# should be populated in one go, call format: self.values[state]
		self.values = dict()		
		# should be populated in one go, call format: self.q_values[state][action]
		# Thus, self.q_values[state] must also be a dictionary
		self.q_values = dict()		
		# should be populated in one go, call format: self.policy[state]
		self.policy = dict()   		

		self.iterated = False

	@utils.timeout(4)
	def act(self, state, problem):
		if not self.iterated:
			self.run_value_iteration(problem)	# must populate self.values
			self.populate_q_values(problem)		# must populate self.QValues
			self.populate_policy(problem)		# must populate self.policy
			self.iterated = True
		return self.policy[state]			

	
	'''
	Q1: Runs the value iteration algorithm for self.iterations iterations.
	a.) Must ensure that self.values is maintained correctly as per the algorithm in every iteration before the call of problem.register_values(self.values, k). 
	b.) Initialize the values of all states with 0.
	'''
	def run_value_iteration(self, problem):
		'''
		Helpful APIs:-
		1. problem.get_states(): Returns list of all states in MDP
		2. problem.is_terminal(state): Returns a bool indicating whether given state is a terminal state or not
		3. problem.get_actions(0, state): 0 is the agent index for player agent. Returns a list of valid actions from given state.
		4. problem.get_transition_states_and_probs(state, action): Returns a list of (next_state, probability) tuples for a specified state- action pair as per the MDP model. The probabilities sum to 1
		5. problem.get_reward(state, action, next_state): Gives the reward associated with the transition from state to next_state using action.
		'''

		# initialisation
		states = problem.get_states()
		for state in states:
			self.values[state] = 0

		''' YOUR CODE HERE '''

		for k in range(self.iterations):
			
			''' YOUR CODE HERE '''

			# Make sure self.values is populated for this iteration correctly
			problem.register_values(self.values, k)		# must call at end of every iteration

		raise utils.MethodNotImplementedError('run_value_iteration')


	'''
	Q1: Populates the q values in self.q_values. self.values is already populated by the time this is called.
	'''
	def populate_q_values(self, problem):
		'''
		Helpful APIs:-
		1. problem.get_states(): Returns list of all states in MDP
		2. problem.is_terminal(state): Returns a bool indicating whether given state is a terminal state or not
		3. problem.get_actions(0, state): 0 is the agent index for player agent. Returns a list of valid actions from given state.
		4. problem.get_transition_states_and_probs(state, action): Returns a list of (next_state, probability) tuples for a specified state- action pair as per the MDP model. The probabilities sum to 1
		5. problem.get_reward(state, action, next_state): Gives the reward associated with the transition from state to next_state using action.
		'''

		''' YOUR CODE HERE '''

		raise utils.MethodNotImplementedError('populate_q_values')


	'''
	Q1: Make sure self.policy is correctly populated. self.values and self.q_values are already populated by the time this is called.
	'''
	def populate_policy(self, problem):
		'''
		Helpful APIs:-
		1. problem.get_states(): Returns list of all states in MDP
		2. problem.is_terminal(state): Returns a bool indicating whether given state is a terminal state or not
		3. problem.get_actions(0, state): 0 is the agent index for player agent. Returns a list of valid actions from given state.
		'''

		''' YOUR CODE HERE '''

		raise utils.MethodNotImplementedError('populate_policy')

class PolicyIterationAgent:
	'''
	Guaranteed for only MDP problems.
	1. Runs policy iteration algorithm.
	2. The no. of iterations is given in self.iterations.
	3. You can check for convergence, but do not break early on convergence.
	4. The values should match upto rounding till 5th decimal place.
	5. Terminal states have value 0 and policy None, and they have no entry in Q Table
	'''
	def __init__(self, args):
		self.rng = args['rng']
		# use both for policy iteration and policy evaluation
		self.iterations = args['iterations']	
		self.discount = args['discount']

		# should be populated in one go, call format: self.values[state]
		self.values = dict()
		# should be populated in one go, call format: self.q_values[state][action]
		# Thus, self.q_values[state] must also be a dictionary		
		self.q_values = dict()
		# should be populated in one go, call format: self.policy[state]
		self.policy = dict()  

		self.iterated = False

	@utils.timeout(4)
	def act(self, state, problem):
		if not self.iterated:
			self.run_policy_iteration(problem)		# must populate self.policy
			self.populate_values(problem)			# must populate self.values
			self.populate_q_values(problem)			# must populate self.QValues
			self.iterated = True
		return self.policy[state]			

	'''
	Q2: Implements policy evaluation, i.e., returns a dictionary, say ans, such that ans[state] is long term values from state following the given input policy.
	'''
	def policy_evaluation(self, policy, problem):
		'''
		Helpful APIs:-
		1. problem.get_states(): Returns list of all states in MDP
		2. problem.is_terminal(state): Returns a bool indicating whether given state is a terminal state or not
		3. problem.get_transition_states_and_probs(state, action): Returns a list of (next_state, probability) tuples for a specified state- action pair as per the MDP model. The probabilities sum to 1
		4. problem.get_reward(state, action, next_state): Gives the reward associated with the transition from state to next_state using action.
		'''

		''' YOUR CODE HERE '''

		raise utils.MethodNotImplementedError('policy_evaluation')

	'''
	Q2: Runs the policy iteration algorithm for self.iterations iterations.
	a.) Must ensure that self.policy is maintained correctly as per the algorithm in every iteration before the call to problem.register_policy(self.policy, k). 
	b.) Initialize the policy randomly using self.rng.choice(actions) for all non terminal states and None for terminal states, to be compatible with the autograder.
	'''
	def run_policy_iteration(self, problem):
		'''
		Helpful APIs:-
		1. problem.get_states(): Returns list of all states in MDP
		2. problem.is_terminal(state): Returns a bool indicating whether given state is a terminal state or not
		3. problem.get_actions(0, state): 0 is the agent index for player agent. Returns a list of valid actions from given state.
		4. problem.get_transition_states_and_probs(state, action): Returns a list of (next_state, probability) tuples for a specified state- action pair as per the MDP model. The probabilities sum to 1
		5. problem.get_reward(state, action, next_state): Gives the reward associated with the transition from state to next_state using action.
		'''

		''' YOUR CODE HERE '''

		for k in range(self.iterations):
			
			''' YOUR CODE HERE '''
			
			# make sure self.policy is populated correctly for this iteration
			problem.register_policy(self.policy, k)	# leave this line intact

		raise utils.MethodNotImplementedError('run_policy_iteration')

	'''
	Q2: Updates self.values so that self.values[state] gives correct long term values from state. sef.policy is alredy populated by the time this is called.
	'''
	def populate_values(self, problem):

		''' YOUR CODE HERE '''

		raise utils.MethodNotImplementedError('populate_values')

	'''
	Q2: Populates the q values in self.q_values. self.values and self.policy are already populated by the time this is called.
	'''
	def populate_q_values(self, problem):
		'''
		Helpful APIs:-
		1. problem.get_states(): Returns list of all states in MDP
		2. problem.is_terminal(state): Returns a bool indicating whether given state is a terminal state or not
		3. problem.get_actions(0, state): 0 is the agent index for player agent. Returns a list of valid actions from given state.
		4. problem.get_transition_states_and_probs(state, action): Returns a list of (next_state, probability) tuples for a specified state- action pair as per the MDP model. The probabilities sum to 1
		5. problem.get_reward(state, action, next_state): Gives the reward associated with the transition from state to next_state using action.
		'''

		''' YOUR CODE HERE '''

		raise utils.MethodNotImplementedError('populate_q_values')

class TDQLearningAgent:
	'''
	Online temporal difference Q learning agent.
	1. learning rate for temporal difference learning is self.alpha.
	2. self.q_values is a dictionary, terminal states should not be in self.q_values, self.q_values[state] will be a dictionary and self.q_values[state][action] should be the q value associated with the state action pair.
	3. The values should match upto rounding till 5th decimal place.
	4. You may optionally maintain self.policy, but it won't be counted for autograding.
	'''
	def __init__(self, args):
		self.rng = args['rng']
		self.discount = args['discount']
		self.alpha = args['alpha']
		# should be populated in one go, call format: self.q_values[state][action]
		# Thus, self.q_values[state] must also be a dictionary		
		self.q_values = dict()		
		self.policy = dict()	# optional, only displays policy in PlatformersMdp problem visuals

	def stop_training(self):
		self.alpha = 0

	'''
	Q3: Return the best action for state based on the q values so far. 
	This should make a call to self.get_q_value(state, action)
	'''
	@utils.timeout(1)
	def act(self, state, problem):
		'''
		Helpful APIs:-
		1. problem.is_terminal(state): Returns a bool indicating whether given state is a terminal state or not
		2. problem.get_actions(0, state): 0 is the agent index for player agent. Returns a list of valid actions from given state.
		3. self.get_q_value(state, action): Gives the q value associated with the state action pair.
		'''

		''' YOUR CODE HERE '''

		raise utils.MethodNotImplementedError('act')

	'''
	Q3: Return q value associated with state action pair. If the state action pair does not exist in self.q_values, insert it with a value of 0 and return 0 for this.
	'''
	def get_q_value(self, state, action):
		''' YOUR CODE HERE '''
		
		raise utils.MethodNotImplementedError('get_q_value')

	'''
	Q3: Implement the temporal difference learning equation here to update the q value after one game ply completes.
	'''
	@utils.timeout(1)
	def observe_transition(self, state, action, next_state, reward, problem):
		'''
		Helpful APIs:-
		1. problem.is_terminal(state): Returns a bool indicating whether given state is a terminal state or not
		2. problem.get_actions(0, state): 0 is the agent index for player agent. Returns a list of valid actions from given state.
		3. self.get_q_value(state, action): Gives the q value associated with the state action pair.
		'''

		''' YOUR CODE HERE '''

		raise utils.MethodNotImplementedError('observe_transition')

class EpsilonGreedyQAgent(TDQLearningAgent):
	'''
	Epsilon Greedy addition to temporal difference q learning agent.
	'''
	def __init__(self, args):
		super().__init__(args)
		self.epsilon = args['epsilon']

	def stop_training(self):
		self.epsilon = 0
		self.alpha = 0

	'''
	Q4: Epsilon Greedy with Q Learning. With probability self.epsilon, take a random action and otherwise take the best action so far.
	'''
	@utils.timeout(1)
	def act(self, state, problem):
		'''
		Helpful APIs:-
		1. self.rng.random(): Returns a random float.
		2. problem.get_actions(0, state): 0 is the agent index for player agent. Returns a list of valid actions from given state.
		3. self.rng.choice(lst): Samples a random element from the list lst.
		4. super().act(state, problem): Returns the action by the parent TDQLearningAgent.
		'''

		''' YOUR CODE HERE '''

		raise utils.MethodNotImplementedError('act')

class ApproximateQLearningAgent:
	'''
	An approximate Q Learning agent.
	1. self.weights is a dictionary, and self.weights[feature] will hold the weight learned for that feature.
	2. self.feature_extractor specifies the function to be called to give a dictionary features with feature, value pairs for a given state, action pair.
	3. self.feature_extractor_cache is a dictionary which will be passed to feature extractor to pass additional arguments or avoid recomputations.
	'''
	def __init__(self, args):
		self.feature_extractor = getattr(featureExtractor, args['feature_extractor'])
		self.rng = args['rng']
		self.discount = args['discount']
		self.alpha = args['alpha']
		self.epsilon = args['epsilon']
		# self.weights[feature] keeps the weight for a feature string
		self.weights = dict()		
		# policy can't be kept for ApproximateQLearningAgent as no. of states will be large
		self.feature_extractor_cache = dict()


	def stop_training(self):
		self.epsilon = 0
		self.alpha = 0
		self.feature_extractor_cache = dict()		# cause the layout may change


	'''
	Q5: Choose the best action following epsilon greedy approach too! The function still calls get_q_value but implementation of get_q_value has changed. get_q_value also takes in the problem parameter as it needs to call self.feature_extractor and pass the problem for reference.
	'''
	@utils.timeout(1)
	def act(self, state, problem):
		'''
		Helpful APIs:-
		1. problem.is_terminal(state): Returns a bool indicating whether given state is a terminal state or not
		2. problem.get_actions(0, state): 0 is the agent index for player agent. Returns a list of valid actions from given state.
		3. self.get_q_value(state, action, problem): Gives the q value associated with the state action pair.
		4. self.rng.random(): Returns a random float.
		5. self.rng.choice(lst): Samples a random element from the list lst.
		'''

		''' YOUR CODE HERE '''

		raise utils.MethodNotImplementedError('act')

	'''
	This time it requires problem also as it has to pass it to feature extractor. The purpose of the function is still to return q-value associated with given state action pair, but it calculates it at the moment as a weighted sum of features.
	'''
	def get_q_value(self, state, action, problem):
		'''
		Helpful APIs:-
		1. self.feature_extractor(state, action, problem, self.feature_extractor_cache): Gives a dictionary of the form {'feature1': value1, 'feature2': value2,....} corresponding to the state action pair. Keys are the features and they have been kept str, values are floats.
		'''

		''' YOUR CODE HERE '''

		raise utils.MethodNotImplementedError('get_q_value')

	'''
	Here it updates self.weights using the temporal difference weight update equation.
	'''
	@utils.timeout(1)
	def observe_transition(self, state, action, next_state, reward, problem):
		'''
		Helpful APIs:-
		1. self.get_q_value(state, action, problem): Gives the q value associated with the state action pair.
		2. problem.is_terminal(state): Returns a bool indicating whether given state is a terminal state or not
		3. problem.get_actions(0, state): 0 is the agent index for player agent. Returns a list of valid actions from given state.
		4. self.feature_extractor(state, action, problem, self.feature_extractor_cache): Gives a dictionary of the form {'feature1': value1, 'feature2': value2,....} corresponding to the state action pair. Keys are the features and they have been kept str, values are floats.
		'''

		''' YOUR CODE HERE '''

		raise utils.MethodNotImplementedError('observe_transition')