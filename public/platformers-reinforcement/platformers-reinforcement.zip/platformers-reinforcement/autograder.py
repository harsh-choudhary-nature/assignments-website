import utils
import argparse, copy
import os, sys
import re
import problems
import gameSettings
import numpy as np
import platformersMdp, playerAgents

def print_q_table(q_table):
	for state in q_table:
		for action in q_table[state]:
			print(f'{state} - {action}: {q_table[state][action]}')

def parse_test_file(file_path):
	with open(file_path, 'r') as file:
		content = file.read()

	# Remove comments
	content = re.sub(r'#.*', '', content)

	# Extract key-value pairs enclosed in triple or double quotes
	matches = re.findall(r'(\w+):\s*("""(?:.|\n)*?"""|".*?")', content)
	# Process the matches into a dictionary
	parsed_data = {}
	for key, value in matches:
		# Strip the quotes from the value
		value = value.strip('"')
		parsed_data[key] = value
	return parsed_data

def parse_graph(graph_str):
	lines = graph_str.split("\n")
	adjlist = dict()
	for line in lines:
		stripped_line = line.strip()
		if len(stripped_line)>0:
			try:
				state, action, next_state = stripped_line.split(' ')	# if successor is invalid will lead to value error 
			except ValueError:
				print(f'*** The .test file is not valid')
				sys.exit(1)

			if state not in adjlist:
				adjlist[state] = []

			adjlist[state].append((action, next_state))
	return adjlist

def parse_evaluation(evaluation_str):
	cache = dict()
	lines = evaluation_str.split("\n")
	for line in lines:
		stripped_line = line.strip()
		if len(stripped_line)>0:
			try:
				state, evaluation_val = stripped_line.split()
			except ValueError:
				print(f'*** The .test file is not valid')
				sys.exit(1)
			state = state.strip()
			evaluation_val = float(evaluation_val.strip())
			cache[state] = evaluation_val
	return cache

def parse_limits_data(limits_str):
	cache = dict()
	lower_bounds = list()
	lines = limits_str.split("\n")
	for line in lines:
		stripped_line = line.strip()
		if len(stripped_line)>0:
			lower_bound, grade = stripped_line.split()
			lower_bound = int(lower_bound.strip())
			grade = float(grade.strip())
			cache[lower_bound] = grade
			lower_bounds.append(lower_bound)
	return cache, lower_bounds

def parse_values_info(string):
	ans = {}
	lines = string.split('\n')
	for line in lines:
		stripped_line = line.strip()
		if len(stripped_line)>0:
			state, info = stripped_line.split(':')
			state = eval(state.strip())
			info = eval(info.strip())
			assert isinstance(state, tuple)
			assert isinstance(info, (float, int))
			ans[state] = info

	return ans

def parse_policy_info(string):
	ans = {}
	lines = string.split('\n')
	for line in lines:
		stripped_line = line.strip()
		if len(stripped_line)>0:
			state, info = stripped_line.split(':')
			state = eval(state.strip())
			info = eval(info.strip())
			assert isinstance(state, tuple)
			assert isinstance(info, str) or info is None
			ans[state] = info

	return ans

def parse_q_value_info(string):
	ans = {}
	lines = string.split('\n')
	for line in lines:
		stripped_line = line.strip()
		if len(stripped_line)>0:
			state_action, info = stripped_line.split(':')
			state, action = state_action.split('-')
			state = eval(state.strip())
			action = eval(action.strip())
			info = eval(info.strip())
			assert isinstance(state, tuple)
			assert isinstance(info, (float, int))
			assert isinstance(action, str)
			if state not in ans:
				ans[state] = {action: info}
			else:
				ans[state][action] = info

	return ans

def parse_weights_info(string):
	ans = {}
	lines = string.split('\n')
	for line in lines:
		stripped_line = line.strip()
		if len(stripped_line)>0:
			feature, weight = stripped_line.split(':')
			feature = feature.strip()
			weight = eval(weight.strip())
			assert isinstance(feature, str)
			assert isinstance(weight, (float, int))
			ans[feature] = weight

	return ans

class PlatformersReinforcementProblemTester:
	def __init__(self, question_data, solution_data):
		self.question_data = question_data
		self.solution_data = solution_data

	def get_problem_args(self):
		problem_args = {'layout_filename': self.question_data['layout'],
				'test_layout_filename': self.question_data['testLayout'], 
				'player_agent': self.question_data['playerAgent'],
				'cost_function': self.question_data['costFn'],
				'ghost_agent': self.question_data['ghostAgent'],
				'feature_extractor': self.question_data['featureExtractor'],
				'ghost_noise': self.question_data['ghostEpsilon'],
				'no_train_graphics': not train_display,
				'no_test_graphics':	not test_display,
				'discount': self.question_data['discount'],
				'alpha': self.question_data['learningRate'],
				'epsilon': self.question_data['epsilon']
				}
		simpleRNG = np.random.default_rng(seed = self.question_data['fixSeed'])

		problem_args['fix_seed'] = simpleRNG.integers(0, 2**32)
		return problem_args

	def test(self, scheme):
		# returns 1 if passed else 0 for scheme is strict
		# returns the scored point if the scheme is partial
		problem = problems.PlatformersReinforcementProblem(self.get_problem_args())
		correct_iteration_wise_weights = dict()
		if hasattr(problem.player_agent, "weights") and self.question_data['featureExtractor'] == 'simple_feature_extractor':
			for key in self.solution_data:
				if key.startswith('iteration_'):
					correct_iteration_wise_weights[int(key[len("iteration_"):])] = parse_weights_info(self.solution_data[key])		
		
		# at max 10 prints should come from training
		if self.question_data['train']<=10:
			batch_size = 1
		else:
			num_batches = 10
			batch_size = np.ceil(self.question_data['train']/num_batches)

		total_score_of_batch = 0
		wins_of_batch = 0
		last_train_index = -1
		student_iteration_wise_weights_info = dict()	
		for i in range(self.question_data['train']):
			print_train = ((i+1)%batch_size == 0) or (i==self.question_data['train']-1 and last_train_index!=i)
			
			try:
				won, score = problem.solve(train=True)
			except Exception as e:
				utils.print_exception(e)
				return 0

			total_score_of_batch += score
			wins_of_batch += int(won)
			if print_train:
				print(f"Total for {i-last_train_index} games: {total_score_of_batch}\nAverage for {i-last_train_index} games: {total_score_of_batch/(i-last_train_index)}\nWon games: {wins_of_batch}\n------------------")
				last_train_index = i
				total_score_of_batch = 0
				wins_of_batch = 0

			problem.reset()
			if i in correct_iteration_wise_weights:
				student_iteration_wise_weights_info[i] = copy.deepcopy(problem.player_agent.weights)

		games_won = 0
		total_won_scores = []
		for i in range(self.question_data['test']):
			print(f'{i}:', end = ' ')
			won, score = problem.solve(train=False)
			problem.reset()
			if won:
				games_won += 1
				total_won_scores.append(score)
				print(f'You won!\tScore: {score}')
			else:
				print(f'You lost!\tScore: {score}')

		if scheme == "strict":
			if games_won >= self.question_data["winThreshold"]:
				failed = False
				for iteration in correct_iteration_wise_weights:
					if len(correct_iteration_wise_weights[iteration])!=len(student_iteration_wise_weights_info[iteration]):
							print(f"*** The length of student's feature weights do not match with correct weights at iteration {iteration}!\ncorrect_weights: {correct_iteration_wise_weights[iteration]}\nStudent's weights: {student_iteration_wise_weights_info[iteration]}")
							failed = True
					else:
						for feature in correct_iteration_wise_weights[iteration]:
							if feature not in student_iteration_wise_weights_info[iteration]:
								print(f"*** Feature {feature} not found in Student's weights at iteration {iteration}!\nStudent's weights: {student_iteration_wise_weights_info[iteration]}")
								# print(type(feature))
								failed = True
								break
							elif round(correct_iteration_wise_weights[iteration][feature], 5)!=round(student_iteration_wise_weights_info[iteration][feature], 5):
								print(f"*** The weights for feature {feature} diverged at iteration {iteration} at precision of 1e-5!\nCorrect weight: {round(correct_iteration_wise_weights[iteration][feature], 5)}\nStudent's weight: {round(student_iteration_wise_weights_info[iteration][feature], 5)}")
								failed = True
								break

					if failed:
						break

				return int(not failed)
			else:
					print(f"Student won games: {games_won}\nMinimum No. of games to win: {self.question_data['winThreshold']}")
					return 0
		else:
			print(f'\nGrading Scheme:-\nGames Won:-\n{self.question_data["winsThresholdsStr"]}\nAverage of top 5 won:-\n{self.question_data["avgThresholdsStr"]}')
			grade_dict_lower_bounds, lower_bounds = parse_limits_data(self.question_data["winsThresholds"])
			grade_dict_avg_score, avg_score_lower_bounds = parse_limits_data(self.question_data["avgThresholds"])
			assert len(lower_bounds) == 1 
			if games_won >= lower_bounds[0]:
				secured = grade_dict_lower_bounds[lower_bounds[0]]
				avg_top_5 = sum(sorted(total_won_scores, reverse=True)[:5])/5
				for i, lower_bound in enumerate(avg_score_lower_bounds):
					if avg_top_5 < lower_bound:
						if i>0:
							print(f'\n*** Games won: {games_won}\nWon Game Scores: {total_won_scores}\nAverage of top 5 won games: {avg_top_5}\nProviding Partial Marks: {grade_dict_avg_score[avg_score_lower_bounds[i-1]]}')

							return grade_dict_avg_score[avg_score_lower_bounds[i-1]]
						else:
							print(f'\n*** Games won: {games_won}\nWon Game Scores: {total_won_scores}\nAverage of top 5 won games: {avg_top_5}\nProviding Partial Marks: {secured}')

						return secured
				else:
					print(f'\nGames won: {games_won}\nWon Game Scores: {total_won_scores}\nAverage of top 5: {avg_top_5}\nProviding Full Marks: {grade_dict_avg_score[lower_bound]}')
					return grade_dict_avg_score[lower_bound]		# make sure it works
			else:
				print(f'\n*** Games Won: {games_won}\nProviding Partial Marks: 0')
				return 0

	def validate_solution(self, scheme):
		pass

	def validate_question(self, scheme):
		defined_layouts, defined_player_agents, defined_ghost_agents, defined_feature_extractors = utils.get_files_in_dir("layouts"), utils.get_class_names(gameSettings.player_agents_file_name), utils.get_class_names(gameSettings.ghost_agents_file_name), utils.get_function_names(gameSettings.feature_extractors_file_name)

		self.question_data['costFn'] = gameSettings.default_cost_function

		if 'featureExtractor' not in self.question_data:
			self.question_data['featureExtractor'] = gameSettings.default_feature_extractor
		if 'ghostEpsilon' not in self.question_data:
			self.question_data['ghostEpsilon'] = gameSettings.default_ghost_noise_value
		if 'ghostAgent' not in self.question_data:
			self.question_data['ghostAgent'] = gameSettings.default_ghost_agent
		if 'discount' not in self.question_data:
			self.question_data['discount'] = gameSettings.default_discount_value
		if 'learningRate' not in self.question_data:
			self.question_data['learningRate'] = gameSettings.default_alpha_value
		if 'epsilon' not in self.question_data:
			self.question_data['epsilon'] = gameSettings.default_epsilon_value

		self.question_data['ghostEpsilon'], self.question_data['discount'], self.question_data['learningRate'], self.question_data['epsilon'] = float(self.question_data['ghostEpsilon']), float(self.question_data['discount']), float(self.question_data['learningRate']), float(self.question_data['epsilon'])

		assert "layout" in self.question_data and "playerAgent" in self.question_data and self.question_data["playerAgent"] != "KeyboardAgent" and self.question_data['layout'] in defined_layouts and self.question_data['playerAgent'] in defined_player_agents and self.question_data['featureExtractor'] in defined_feature_extractors and 0<=self.question_data['ghostEpsilon']<=1 and self.question_data['ghostAgent'] in defined_ghost_agents and 0<=self.question_data['discount']<=1 and 0<=self.question_data['learningRate']<=1 and 0<=self.question_data['epsilon']<=1 and 'fixSeed' in self.question_data and 'train' in self.question_data and 'test' in self.question_data

		self.question_data['fixSeed'], self.question_data['train'], self.question_data['test'] = int(self.question_data['fixSeed']), int(self.question_data['train']), int(self.question_data['test'])

		assert 0<=self.question_data['fixSeed']<=2**32-1

		if scheme == "strict":
			assert "winThreshold" in self.question_data
			self.question_data["winThreshold"] = int(self.question_data["winThreshold"])
		else:
			assert "winsThresholds" in self.question_data and "winsThresholdsStr" in self.question_data and "avgThresholds" in self.question_data and "avgThresholdsStr" in self.question_data
		
		if 'testLayout' not in self.question_data:
			self.question_data['testLayout'] = self.question_data['layout']
		assert self.question_data['testLayout'] in defined_layouts

	def print_solution(self, solution_file_path):
		problem = problems.PlatformersReinforcementProblem(self.get_problem_args())

		if not hasattr(problem.player_agent, "weights") or self.question_data.get('featureExtractor') != 'simple_feature_extractor':
			return

		iterations = list(map(int, self.question_data['checkIterations'].split()))
		fh = open(solution_file_path, "w")
		for i in range(self.question_data['train']):
			try:
				won, score = problem.solve(train=True)
			except Exception as e:
				utils.print_exception(e)
				sys.exit(1)

			problem.reset()
			if i in iterations:
				fh.write(f"iteration_{i}: \"\"\"\n")
				for feature in problem.player_agent.weights:
					fh.write(f'{feature}: {round(problem.player_agent.weights[feature], 5)}\n')
				fh.write(f"\n\"\"\"\n")
		fh.close()

class PlatformersMdpProblemTester:
	def __init__(self, question_data, solution_data):
		self.question_data = question_data
		self.solution_data = solution_data

	def get_agent_and_problem(self):
		layout = platformersMdp.parse_layout(self.question_data['layout'])
		# s value, t value and w value will be treated as default itself
		if 'fixSeed' in self.question_data:
			simpleRNG = np.random.default_rng(seed = self.question_data['fixSeed'])
		else:
			simpleRNG = np.random.default_rng()
		
		agent_args = {	'iterations': 		self.question_data.get('iterations'),
						'discount':			self.question_data.get('discount'),
						'rng': 				np.random.default_rng(seed = simpleRNG.integers(0,2**32)),
						'alpha': 			self.question_data.get('learningRate'),
						'epsilon':			self.question_data.get('epsilon'), 
						'feature_extractor':	self.question_data.get('featureExtractor')
						}
		agent = getattr(playerAgents, self.question_data['playerAgent'])(agent_args)
		problem = platformersMdp.PlatformersMdpProblem(layout, simpleRNG.integers(0, 2**32), living_reward = self.question_data['livingReward'], noise = self.question_data['noise'])

		return agent, problem

	def test(self):
		if 'fixSeed' in self.question_data:
			simpleRNG = np.random.default_rng(seed = self.question_data['fixSeed'])
		else:
			simpleRNG = np.random.default_rng()
		# returns 1 if passed else 0
		correct_agent_iteration_wise_values = dict() 
		correct_agent_iteration_wise_policy = dict()
		correct_agent_iteration_wise_q_values = dict() 
		correct_iteration_wise_weights = dict()
		correct_agent_q_values = dict()
		correct_agent_values = dict()
		correct_agent_policy = dict()

		for key in self.solution_data:
			if key.startswith('iteration_'):
				if self.question_data['playerAgent'] == "ValueIterationAgent":
					correct_agent_iteration_wise_values[int(key[len("iteration_"):])] = parse_values_info(self.solution_data[key])	
				elif self.question_data['playerAgent'] == "PolicyIterationAgent":
					correct_agent_iteration_wise_policy[int(key[len("iteration_"):])] = parse_policy_info(self.solution_data[key])	
				elif self.question_data['playerAgent'] in ["TDQLearningAgent", "EpsilonGreedyQAgent"]:
					correct_agent_iteration_wise_q_values[int(key[len("iteration_"):])] = parse_q_value_info(self.solution_data[key])
				else:
					correct_iteration_wise_weights[int(key[len("iteration_"):])] = parse_weights_info(self.solution_data[key])

			elif key == 'QValues':
				assert len(correct_agent_q_values)==0
				correct_agent_q_values = parse_q_value_info(self.solution_data[key])
			elif key == 'Policy':
				assert len(correct_agent_policy) == 0
				correct_agent_policy = parse_policy_info(self.solution_data[key])
			elif key == 'Values':
				assert len(correct_agent_values) == 0
				correct_agent_values = parse_values_info(self.solution_data[key])
			else:
				assert False
		
		agent, problem = self.get_agent_and_problem()

		if self.question_data['train']<=10:
			batch_size = 1
		else:
			num_batches = 10
			batch_size = np.ceil(self.question_data['train']/num_batches)
		total_score_of_batch = 0
		last_train_index = -1
		
		student_iteration_wise_q_values = dict()
		student_iteration_wise_weights = dict()
		for i in range(self.question_data['train']):
			print_train = ((i+1)%batch_size == 0) or (i==self.question_data['train']-1 and last_train_index!=i)

			try:
				score = platformersMdp.run_episode(agent, problem, self.question_data['discount'], train_display, simpleRNG.integers(0,2**32), False)
			except Exception as e:
				utils.print_exception(e)
				return 0
			total_score_of_batch += score

			if print_train:
				print(f"Total for {i-last_train_index} games: {total_score_of_batch}\nAverage for {i-last_train_index} games: {total_score_of_batch/(i-last_train_index)}\n------------------")
				last_train_index = i
				total_score_of_batch = 0

			if i in correct_agent_iteration_wise_q_values:
				student_iteration_wise_q_values[i] = copy.deepcopy(agent.q_values)
			if i in correct_iteration_wise_weights:
				student_iteration_wise_weights[i] = copy.deepcopy(agent.weights)


		if hasattr(agent, 'stop_training'):
			agent.stop_training()

		for i in range(self.question_data['test']):
			score = platformersMdp.run_episode(agent, problem, self.question_data['discount'], test_display, simpleRNG.integers(0,2**32), False)
			print(f'Score: {score}')


		failed = False
		# compare iteration wise values (nothing happens if its empty, so makes sense only for value iteration agent)
		for iteration in correct_agent_iteration_wise_values:
			if len(correct_agent_iteration_wise_values[iteration])!=len(problem.agent_iteration_wise_values[iteration]):
					print(f"*** The length of student's values do not match with correct values at iteration {iteration}!\nCorrect Values: {correct_agent_iteration_wise_values[iteration]}\nStudent's Values: {problem.agent_iteration_wise_values[iteration]}")
					failed = True
			else:
				for state in correct_agent_iteration_wise_values[iteration]:
					if state not in problem.agent_iteration_wise_values[iteration]:
						print(f"*** State {state} not found in Student's Values at iteration {iteration}!\nStudent's Values: {problem.agent_iteration_wise_values[iteration]}")
						failed = True
						break
					elif round(correct_agent_iteration_wise_values[iteration][state], 5)!=round(problem.agent_iteration_wise_values[iteration][state], 5):
						print(f"*** The values for state {state} diverged at iteration {iteration} at precision of 1e-5!\nCorrect Value: {round(correct_agent_iteration_wise_values[iteration][state], 5)}\nStudent's Value: {round(problem.agent_iteration_wise_values[iteration][state], 5)}")
						failed = True
						break
			if failed:
				break

		# compare iteration wise policy (nothing happens if its empty, so makes sense only for policy iteration agent)
		for iteration in correct_agent_iteration_wise_policy:
			if len(correct_agent_iteration_wise_policy[iteration])!=len(problem.agent_iteration_wise_policy[iteration]):
					print(f"*** The length of student's policies do not match with correct policies at iteration {iteration}!\nCorrect Policy: {correct_agent_iteration_wise_policy[iteration]}\nStudent's Policy: {problem.agent_iteration_wise_policy[iteration]}")
					failed = True
			else:
				for state in correct_agent_iteration_wise_policy[iteration]:
					if state not in problem.agent_iteration_wise_policy[iteration]:
						print(f"*** State {state} not found in Student's Policy at iteration {iteration}!\nStudent's Policy: {problem.agent_iteration_wise_policy[iteration]}")
						failed = True
						break
					elif correct_agent_iteration_wise_policy[iteration][state]!=problem.agent_iteration_wise_policy[iteration][state]:
						print(f"*** The policy for state {state} diverged at iteration {iteration}!\nCorrect Action: {correct_agent_iteration_wise_policy[iteration][state]}\nStudent's Action: {problem.agent_iteration_wise_policy[iteration]}")
						failed = True
						break
			if failed:
				break

		# compare iteration wise q values (nothing happens if its empty, so makes sense only for Q Learning agent and epsilon greedy)
		for iteration in correct_agent_iteration_wise_q_values:
			if len(correct_agent_iteration_wise_q_values[iteration])!=len(student_iteration_wise_q_values[iteration]):
					print(f"*** The length of student's Q Table does not match with correct Q Table at iteration {iteration}!\nCorrect Q Table:")
					print_q_table(correct_agent_iteration_wise_q_values[iteration])
					print(f"Student's Q Table:")
					print_q_table(student_iteration_wise_q_values[iteration])
					failed = True
			else:
				for state in correct_agent_iteration_wise_q_values[iteration]:
					if state not in student_iteration_wise_q_values[iteration]:
						print(f"*** State {state} not found in Student's Q Table at iteration {iteration}!\nStudent's Q Table:")
						print_q_table(student_iteration_wise_q_values[iteration])
						failed = True
					else:
						for action in correct_agent_iteration_wise_q_values[iteration][state]:
							if action not in student_iteration_wise_q_values[iteration][state]:
								print(f"*** Action {action} not found in Student's Q Table for state {state} at iteration {iteration}!\nStudent's Q Table:")
								print_q_table(student_iteration_wise_q_values[iteration])
								failed = True
								break
							elif round(correct_agent_iteration_wise_q_values[iteration][state][action], 5)!=round(student_iteration_wise_q_values[iteration][state][action], 5):
								print(f"*** The Q Value for state {state}, action {action} diverged at iteration {iteration} at precision of 1e-5!\nCorrect Q Value: {round(correct_agent_iteration_wise_q_values[iteration][state][action], 5)}\nStudent's Q Value: {round(student_iteration_wise_q_values[iteration][state][action], 5)}")
								failed = True
								break
					if failed:
						break
			if failed:
				break
			
		# compare iteration wise weights (nothing happens if its empty, so makes sense only for approx Q Learning agent)
		for iteration in correct_iteration_wise_weights:
			if len(correct_iteration_wise_weights[iteration])!=len(student_iteration_wise_weights[iteration]):
					print(f"*** The length of student's feature weights do not match with correct weights at iteration {iteration}!\ncorrect_weights: {correct_iteration_wise_weights[iteration]}\nStudent's weights: {student_iteration_wise_weights[iteration]}")
					failed = True
			else:
				for feature in correct_iteration_wise_weights[iteration]:
					if feature not in student_iteration_wise_weights[iteration]:
						print(f"*** Feature {feature} not found in Student's weights at iteration {iteration}!\nStudent's weights: {student_iteration_wise_weights[iteration]}")
						# print(type(feature))
						failed = True
						break
					elif round(correct_iteration_wise_weights[iteration][feature], 5)!=round(student_iteration_wise_weights[iteration][feature], 5):
						print(f"*** The weights for feature {feature} diverged at iteration {iteration} at precision of 1e-5!\nCorrect weight: {round(correct_iteration_wise_weights[iteration][feature], 5)}\nStudent's weight: {round(student_iteration_wise_weights[iteration][feature], 5)}")
						failed = True
						break
			if failed:
				break

		# compare values (nothing happens if values are empty)
		if self.question_data['playerAgent'] == 'PolicyIterationAgent':
			if len(correct_agent_values)!=len(agent.values):
				print(f"*** The length of student's values do not match with correct values!\nCorrect Values: {correct_agent_values[iteration]}\nStudent's Values: {agent.values}")
				failed = True
			else:
				for state in correct_agent_values:
					if state not in agent.values:
						print(f"*** State {state} not found in Student's Values!\nStudent's Values: {agent.values}")
						failed = True
						break
					elif round(correct_agent_values[state], 5)!=round(agent.values[state], 5):
						print(f"*** The values for state {state} diverged at precision of 1e-5!\nCorrect Value: {round(correct_agent_values[state], 5)}\nStudent's Value: {round(agent.values[state], 5)}")
						failed = True
						break

		# compare policy (nothing happens if policy is empty)
		if self.question_data['playerAgent'] == 'ValueIterationAgent':
			if len(correct_agent_policy)!=len(agent.policy):
				print(f"*** The length of student's policies do not match with correct policies!\nCorrect Policy: {correct_agent_policy}\nStudent's Policy: {agent.policy}")
				failed = True
			else:
				for state in correct_agent_policy:
					if state not in agent.policy:
						print(f"*** State {state} not found in Student's Policy!\nStudent's Policy: {agent.policy}")
						failed = True
						break
					elif correct_agent_policy[state]!=agent.policy[state]:
						print(f"*** The policy for state {state} diverged!\nCorrect Action: {correct_agent_policy[state]}\nStudent's Action: {agent.policy[state]}")
						failed = True
						break
		
		# compare q values (nothing happens if q values are empty)
		if self.question_data['playerAgent'] in ['PolicyIterationAgent', 'ValueIterationAgent']:
			if len(correct_agent_q_values)!=len(agent.q_values):
					print(f"*** The length of student's Q Table does not match with correct Q Table!\nCorrect Q Table:")
					print_q_table(correct_agent_q_values)
					print(f"Student's Q Table:")
					print_q_table(agent.q_values)
					failed = True
			else:
				for state in correct_agent_q_values:
					if state not in agent.q_values:
						print(f"*** State {state} not found in Student's Q Table!\nStudent's Q Table:")
						print_q_table(agent.q_values)
						failed = True
					else:
						for action in correct_agent_q_values[state]:
							if action not in agent.q_values[state]:
								print(f"*** Action {action} not found in Student's Q Table for state {state}!\nStudent's Q Table:") 
								print_q_table(agent.q_values)
								failed = True
								break
							elif round(correct_agent_q_values[state][action], 5)!=round(agent.q_values[state][action], 5):
								print(f"*** The Q Value for state {state}, action {action} diverged at precision of 1e-5!\nCorrect Q Value: {round(correct_agent_q_values[state][action], 5)}\nStudent's Q Value: {round(agent.q_values[state][action], 5)}")
								failed = True
								break
					if failed:
						break
		return int(not failed)

	def validate_solution(self):
		pass

	def validate_question(self):
		defined_layouts = [file for file in utils.get_files_in_dir("layouts") if file.startswith('mdp')]
		defined_player_agents = utils.get_class_names('playerAgents.py')

		assert 'playerAgent' in self.question_data and self.question_data['playerAgent'] in defined_player_agents and "layout" in self.question_data and self.question_data['layout'] in defined_layouts and "discount" in self.question_data and "noise" in self.question_data and "livingReward" in self.question_data

		self.question_data['discount'] = float(self.question_data['discount'])
		self.question_data['noise'] = float(self.question_data['noise'])
		self.question_data['livingReward'] = float(self.question_data['livingReward'])
		
		assert 0<= self.question_data['discount'] <= 1 and 0<= self.question_data['noise'] <= 1

		if 'fixSeed' in self.question_data:
			self.question_data['fixSeed'] = int(self.question_data['fixSeed'])
			assert 0<=self.question_data['fixSeed']<2**32
		
		if self.question_data['playerAgent'] in ['ValueIterationAgent', 'PolicyIterationAgent']:
			if 'episodes' in self.question_data:
				self.question_data['episodes'] = int(self.question_data['episodes'])
				assert self.question_data['episodes'] == 1
			else:
				self.question_data['episodes'] = 1
			self.question_data['train'] = self.question_data['episodes']
			self.question_data['test'] = 0

			assert "iterations" in self.question_data
			self.question_data['iterations'] = int(self.question_data['iterations'])
			assert self.question_data['iterations'] >= 1
		else:
			assert 'train' in self.question_data and int(self.question_data['train'])>=0
			self.question_data['train'] = int(self.question_data['train'])
			if 'test' in self.question_data:
				self.question_data['test'] = int(self.question_data['test'])
				assert self.question_data['test'] >= 0
			else:
				self.question_data['test'] = 0
			assert 'learningRate' in self.question_data
			self.question_data['learningRate'] = float(self.question_data['learningRate'])
			assert 0 <= self.question_data['learningRate'] <= 1
			if self.question_data['playerAgent'] in ['EpsilonGreedyQAgent', 'ApproximateQLearningAgent']:
				assert 'epsilon' in self.question_data
				self.question_data['epsilon'] = float(self.question_data['epsilon'])
				assert 0 <= self.question_data['epsilon'] <= 1
			else:
				self.question_data['epsilon'] = gameSettings.default_epsilon_value
			if 'epsilon' in self.question_data:
				self.question_data['epsilon'] = float(self.question_data['epsilon'])
				assert 0<=self.question_data['epsilon']<=1
			defined_feature_extractors = utils.get_function_names(gameSettings.feature_extractors_file_name)
			if 'featureExtractor' in self.question_data:
				assert self.question_data['featureExtractor'] in defined_feature_extractors
			else:
				self.question_data['featureExtractor'] = gameSettings.default_feature_extractor
			
	def print_solution(self, solution_file_path):
		fh = open(solution_file_path, "w")

		if 'fixSeed' in self.question_data:
			simpleRNG = np.random.default_rng(seed = self.question_data['fixSeed'])
		else:
			simpleRNG = np.random.default_rng()

		iterations = list(map(int, self.question_data['checkIterations'].split()))
		agent, problem = self.get_agent_and_problem()

		for i in range(self.question_data['train']):
			try:
				score = platformersMdp.run_episode(agent, problem, self.question_data['discount'], False, simpleRNG.integers(0,2**32), False)
			except Exception as e:
				utils.print_exception(e)
				sys.exit(1)
			problem.reset()
			if i in iterations and self.question_data['playerAgent'] not in ['PolicyIterationAgent', 'ValueIterationAgent']:
				fh.write(f"iteration_{i}: \"\"\"\n")			
				if self.question_data['playerAgent'] in ["TDQLearningAgent", "EpsilonGreedyQAgent"]:
					for state in agent.q_values:
						for action in agent.q_values[state]:
							fh.write(f'{state} - \'{action}\': {round(agent.q_values[state][action], 5)}\n')
				elif self.question_data['playerAgent']=="ApproximateQLearningAgent":
					for feature in agent.weights:
						fh.write(f'{feature}: {round(agent.weights[feature], 5)}\n')

				fh.write(f"\n\"\"\"\n")


		if self.question_data['playerAgent'] == "ValueIterationAgent":
			for iteration in iterations:
				fh.write(f"iteration_{iteration}: \"\"\"\n")
				for state in problem.agent_iteration_wise_values[iteration]:
					fh.write(f"{state}: {round(problem.agent_iteration_wise_values[iteration][state], 5)}\n")
				fh.write(f"\n\"\"\"\n")
		elif self.question_data['playerAgent'] == 'PolicyIterationAgent':
			for iteration in iterations:
				fh.write(f"iteration_{iteration}: \"\"\"\n")
				for state in problem.agent_iteration_wise_policy[iteration]:
					if problem.agent_iteration_wise_policy[iteration][state] is None:
						fh.write(f"{state}: {problem.agent_iteration_wise_policy[iteration][state]}\n")
					else:
						fh.write(f"{state}: \'{problem.agent_iteration_wise_policy[iteration][state]}\'\n")
				fh.write(f"\n\"\"\"\n")

		if self.question_data['playerAgent'] in ['PolicyIterationAgent', 'ValueIterationAgent']:		
			fh.write(f"QValues: \"\"\"\n")
			for state in agent.q_values:
				for action in agent.q_values[state]:
					fh.write(f'{state} - \'{action}\': {round(agent.q_values[state][action], 5)}\n')
			fh.write(f"\n\"\"\"\n")
		
		if self.question_data['playerAgent'] == 'ValueIterationAgent':
			fh.write(f"Policy: \"\"\"\n")
			for state in agent.policy:
				if agent.policy[state] is None:
					fh.write(f"{state}: {agent.policy[state]}\n")
				else:
					fh.write(f"{state}: \'{agent.policy[state]}\'\n")
			fh.write(f"\n\"\"\"\n")
		elif self.question_data['playerAgent'] == 'PolicyIterationAgent':
			fh.write(f"Values: \"\"\"\n")
			for state in agent.values:
				fh.write(f"{state}: {round(agent.values[state], 5)}\n")
			fh.write(f"\n\"\"\"\n")

		fh.close()


def run_one_test(test_dir, test_file_name, valid_problems, train_display, test_display, scheme, write_solution=False):
	# returns 1 if passed else 0 for scheme is strict
	# returns the scored point if the scheme is partial
	script_dir = os.path.dirname(os.path.abspath(__file__))
	path = os.path.join(script_dir,"test_cases",test_dir,test_file_name)

	test_case_name = test_file_name.split(".")[0]
	solution_file_path = os.path.join(script_dir,"test_cases",test_dir,test_case_name+".solution")
	question_data = parse_test_file(path)
	solution_data = parse_test_file(solution_file_path)

	assert "problem" in question_data, "The test file has no problem specified"

	print(f"Running test case {path}")
	result = 0
	if scheme == "strict":
		# returns 1 or 0 based on passed or failed
		if question_data["problem"]=="PlatformersReinforcementProblem":

			tester = PlatformersReinforcementProblemTester(question_data, solution_data)
			tester.validate_question(scheme)
			if not write_solution:
				tester.validate_solution(scheme)
				result = tester.test(scheme)
				if result == 1:
					print(f"{test_file_name} passed!")
				else:
					print(f"*** Test failed {test_file_name}")
			else:
				tester.print_solution(solution_file_path)

		elif question_data["problem"]=="PlatformersMdpProblem":
			tester = PlatformersMdpProblemTester(question_data, solution_data)
			tester.validate_question()
			if not write_solution:
				tester.validate_solution()
				result = tester.test()
				if result == 1:
					print(f"{test_file_name} passed!")
				else:
					print(f"*** Test failed {test_file_name}")
			else:
				tester.print_solution(solution_file_path)
		else:
			assert False
	else:
		if question_data["problem"]=="PlatformersReinforcementProblem":
			tester = PlatformersReinforcementProblemTester(question_data, solution_data)
			tester.validate_question(scheme)
			if not write_solution:
				tester.validate_solution(scheme)	
				result = tester.test(scheme)
		else:
			assert False
		
	print("-------------------------------------------------------------------")
	return result

def run_one_test_directory(test_dir, valid_problems, train_display, test_display, write_solution = False)->tuple:
	# path is test_cases/test_dir
	print(f"Testing {test_dir}.........")
	script_dir = os.path.dirname(os.path.abspath(__file__))
	path = os.path.join(script_dir,"test_cases",test_dir)

	# get the config details
	config_file_path = os.path.join(path, "CONFIG")
	config_file_data = parse_test_file(config_file_path)
	assert "scheme" in config_file_data
	if config_file_data['scheme'] == "strict":
		assert "maxPoints" in config_file_data
		total_points = int(config_file_data['maxPoints'])
		num_tests = 0
		num_tests_passed = 0
		for file in os.listdir(path):
			if file.endswith(".test"):
				num_tests += 1
				correct_pts = run_one_test(test_dir, file, valid_problems, train_display, test_display, "strict", write_solution)
				if correct_pts == 1:
					num_tests_passed += 1
		if num_tests_passed < num_tests:
			correct_points = 0
		else:
			correct_points = total_points
	else:
		assert 'maxPoints' in config_file_data, "The config file is not correct"
		total_points = float(config_file_data['maxPoints'])
		num_tests = 0
		correct_points = 0
		for file in os.listdir(path):
			if file.endswith(".test"):
				num_tests += 1
				correct_pts = run_one_test(test_dir, file, valid_problems, train_display, test_display, "partial", write_solution)
				correct_points += correct_pts
				
		assert correct_points <= total_points

	if not write_solution:
		print(f"Verdict: {test_dir} {'failed' if correct_points<total_points else 'passed'}\nPoints: {correct_points}/{total_points}")
	print("====================================================================")
	print()

	return total_points, correct_points



defined_tests = utils.get_dirs_in_dir("test_cases")
total_tests = len(defined_tests)

arg_parser = argparse.ArgumentParser(description='Run the test cases for your implementation. Run "python3 autograder.py -h" to view the list of argument options available')

# Define the expected command-line arguments
arg_parser.add_argument('-q', type=str, help='Specify the name of specific tests folder in test_cases', choices = defined_tests, nargs = '+')
arg_parser.add_argument('--test', type=str, help='Specify the name of specific tests folder followed by slash(/) followed by test case file name (Overrules -q argument)')
arg_parser.add_argument('--noGraphics', action='store_true', help='Disable graphics display')
arg_parser.add_argument('--noTrainGraphics', action='store_true', help='Disable graphics display during training')
arg_parser.add_argument('--noTestGraphics', action='store_true', help='Disable graphics display during testing')

# Parse the command-line arguments
args = arg_parser.parse_args()
print("Autograding in progress......\n")

display = not args.noGraphics
train_display = not args.noTrainGraphics
test_display = not args.noTestGraphics

if not display:
	train_display, test_display = False, False

valid_problems = utils.get_class_names("problems.py")
onetest = args.test
write_solution = False
if not onetest:
	tests = args.q

	if tests is None:
		# run all the tests
		tests = defined_tests
	val = 0
	total = 0
	for test in tests:
		dir_tot, dir_val = run_one_test_directory(test, valid_problems, train_display, test_display, write_solution)
		total += dir_tot
		val += dir_val

	if not write_solution:
		if total > val:
			print(f"*** Some tests failed. Retry!")

		if total_tests == len(tests):
			print(f"Total points: {total}\nScored points: {val}\nScore: {val}/{total}")
else:

	try:
		folder, filename = onetest.split('/')
		folder = folder.strip()
		filename = filename.strip()
		script_dir = os.path.dirname(os.path.abspath(__file__))
		path = os.path.join(script_dir,"test_cases",folder, filename)

		# get the config details
		config_file_path = os.path.join(script_dir,"test_cases",folder, "CONFIG")
		config_file_data = parse_test_file(config_file_path)
		assert "maxPoints" in config_file_data
		total_points = float(config_file_data['maxPoints'])
		correct_pts = run_one_test(folder, filename, valid_problems, train_display, test_display, config_file_data['scheme'], write_solution)
		assert correct_pts <= total_points
		print("====================================================================\n")
	except FileNotFoundError:
		print(f'Invalid test case!')
		sys.exit(1)
	except ValueError as e:
		print(f'{e}')
		sys.exit(1)