import utils
import gameState
import game
import playerAgents, ghostAgents
import ghostRules, playerRules
import costFunctions
import pygame
import gameSettings
import numpy as np


# This problem will have two parts, one with and one without MDP

class PlatformersReinforcementProblem:

	def __init__(self, args):
		layout = utils.parse(args['layout_filename'])
		test_layout = utils.parse(args['test_layout_filename'])
		self.fix_seed_value = args['fix_seed']
		self.problemRNG = np.random.default_rng(seed = args['fix_seed'])
		self.train_graphics_enabled = not args['no_train_graphics']
		self.test_graphics_enabled = not args['no_test_graphics']
		self.game_state = gameState.GameState(layout)
		self.test_game_state = gameState.GameState(test_layout)
		self.starting_game_state = self.game_state.shallow_copy()
		self.starting_test_game_state = self.test_game_state.shallow_copy()
		self.num_ghosts = len(self.game_state.ghosts_details)
		self.test_num_ghosts = len(self.test_game_state.ghosts_details)
		self.cost_function = getattr(costFunctions, args['cost_function'])
		self.ghost_rules = ghostRules.GhostRules(self.game_state.num_rows, self.game_state.num_cols, self.cost_function)
		self.test_ghost_rules = ghostRules.GhostRules(self.test_game_state.num_rows, self.test_game_state.num_cols, self.cost_function)
		self.player_rules = playerRules.PlayerRules(self.game_state.num_rows, self.game_state.num_cols, self.cost_function)
		self.test_player_rules = playerRules.PlayerRules(self.test_game_state.num_rows, self.test_game_state.num_cols, self.cost_function)
		self.score = 0

		if args['player_agent']=='KeyboardAgent' and (not self.train_graphics_enabled or not self.test_graphics_enabled):
			assert False

		player_args = {'epsilon': args['epsilon'], 'alpha': args['alpha'], 'discount': args['discount'], 'rng': self.problemRNG, 'feature_extractor': args['feature_extractor']}
		self.player_agent = getattr(playerAgents, args['player_agent'])(player_args)
		ghost_args = {'ghost_noise': args['ghost_noise'], 'rng': self.problemRNG}
		self.ghost_agent = getattr(ghostAgents, args['ghost_agent'])(ghost_args)

		if args['player_agent'] in ['ValueIterationAgent', 'PolicyIterationAgent']:
			assert False, f"The agent {args['player_agent']} requires a model to train, but platformers has no model"


	# this is like one episode, but now this problem is created only once, so is the agent and hence the parameters are not lost
	def solve(self, train):
		won, score = None, None
		if train:
			self.train = True
			if self.train_graphics_enabled:
				self.game = game.Game(self.num_ghosts, self.game_state.num_rows, self.game_state.num_cols, self.game_state.blocks_pos, self.game_state.foods_pos, self.game_state.freezers_pos, self.game_state.player_details.pos, [ghost_details.pos for ghost_details in self.game_state.ghosts_details], self.score, self.fix_seed_value)
				self.game.init_offset(self.game_state.player_details.pos)
				won, score = self.solve_with_graphics(train)
			else:
				won, score = self.solve_no_graphics(train)
		else:
			self.train = False
			if hasattr(self.player_agent, 'stop_training'):
				self.player_agent.stop_training()

			if self.test_graphics_enabled:
				self.game = game.Game(self.test_num_ghosts, self.test_game_state.num_rows, self.test_game_state.num_cols, self.test_game_state.blocks_pos, self.test_game_state.foods_pos, self.test_game_state.freezers_pos, self.test_game_state.player_details.pos, [ghost_details.pos for ghost_details in self.test_game_state.ghosts_details], self.score, self.fix_seed_value)
				self.game.init_offset(self.test_game_state.player_details.pos)
				won, score = self.solve_with_graphics(train)
			else:
				won, score = self.solve_no_graphics(train)

		assert won is not None and score is not None
		return won, score

	def solve_with_graphics(self, train):
		run = True
		clock = pygame.time.Clock()
		self.game.draw()
		pygame.display.update()
		won = False
		score = 0
		while run:
			clock.tick(gameSettings.FPS)
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					run = False
					score = self.score
					break

			done = self.game.handle_action_locking(self)	# the game checks if animation from last action is pending, if yes then continues that animation
			self.game.draw()

			pygame.display.update()
			if done:
				run = False
				if len(self.get_current_game_state().foods_pos)==0:
					won = True
					score = self.score
				else:
					won = False
					score = self.score
				break

		pygame.quit()
		return won, score

	def get_current_game_state(self):
		if self.train:
			return self.game_state
		return self.test_game_state
	
	def get_current_player_rules(self):
		if self.train:
			return self.player_rules
		return self.test_player_rules
	
	def get_current_ghost_rules(self):
		if self.train:
			return self.ghost_rules
		return self.test_ghost_rules
	
	def set_current_game_state(self, game_state):
		if self.train:
			self.game_state = game_state
		else:
			self.test_game_state = game_state

	def get_num_ghosts(self):
		if self.train:
			return self.num_ghosts
		return self.test_num_ghosts

	def solve_no_graphics(self, train):
		won, score = False, 0
		while not self.get_current_game_state().is_goal_state():
			initial_state = self.get_current_game_state().shallow_copy()
			initial_score = self.score

			cur_game_state = self.get_current_game_state()
			player_action = self.player_agent.act(cur_game_state, self)
			
			next_game_state, traced_path, food_indices_eaten_at_index_of_traced_path, freezer_indices_eaten_at_index_of_traced_path, inactive_ghost_indices_eaten_at_index_of_traced_path, active_ghost_indices_eaten_at_index_of_traced_path = self.get_current_player_rules().get_next_game_state(cur_game_state, player_action)
			self.score -= self.cost_function(0, cur_game_state, player_action, next_game_state)



			cur_game_state = next_game_state
			
			if not cur_game_state.is_goal_state():
				for i in range(self.get_num_ghosts()):

					ghost_action = self.ghost_agent.act(i+1, cur_game_state, self)
					next_game_state, traced_path, player_eaten_at_index_of_traced_path = self.get_current_ghost_rules().get_next_game_state(i+1, cur_game_state, ghost_action)
					self.score -= self.cost_function(i+1, cur_game_state, ghost_action, next_game_state)
					cur_game_state = next_game_state
			
					if cur_game_state.is_goal_state():
						break
			else:
				self.set_current_game_state(cur_game_state)

				final_state = self.get_current_game_state().shallow_copy()
				final_score = self.score
				reward = final_score - initial_score

				self.player_agent.observe_transition(initial_state, player_action, final_state, reward, self)
	
				break

			self.set_current_game_state(cur_game_state)

			final_state = self.get_current_game_state().shallow_copy()
			final_score = self.score
			reward = final_score - initial_score

			if hasattr(self.player_agent, 'observe_transition'):
				
				self.player_agent.observe_transition(initial_state, player_action, final_state, reward, self)
			
		if len(self.get_current_game_state().foods_pos)==0:
			won, score = True, self.score
		else:
			won, score = False, self.score
		return won, score

	def get_actions(self, agent_index, game_state):
		if agent_index == 0:
			return self.get_current_player_rules().get_actions(game_state)
		else:
			return self.get_current_ghost_rules().get_actions(agent_index, game_state)

	def get_num_agents(self):
		return 1 + self.get_num_ghosts()

	def is_goal_state(self, game_state):
		return game_state.is_goal_state()

	def get_next_game_state(self, agent_index, game_state, action):
		if agent_index == 0:
			return self.get_current_player_rules().get_next_game_state(game_state, action)[0]
		else:
			return self.get_current_ghost_rules().get_next_game_state(agent_index, game_state, action)[0]

	def get_actions_from_player_pos(self, player_pos):
		# these two members accesses from game_state do not change and hence it can be accessed from any instance
		return self.get_current_player_rules().get_actions_from_player_pos(player_pos, self.get_current_game_state().blocks_pos)


	def get_next_pos_from_player_pos_and_action(self, player_pos, action):

		traced_path = [player_pos] + [(player_pos[0]+neigh_pos[0], player_pos[1]+neigh_pos[1]) for neigh_pos in self.get_current_player_rules().check_empty_positions[action]]

		next_pos = traced_path[-1]
		# these two members accesses from game_state do not change and hence it can be accessed from any instance
		while next_pos[0]+1<self.get_current_game_state().num_rows and (next_pos[0]+1,next_pos[1]) not in self.get_current_game_state().blocks_pos:
			next_pos = (next_pos[0]+1,next_pos[1])
			traced_path.append(next_pos)
		return next_pos, traced_path

	def get_actions_from_ghost_pos(self, ghost_pos):
		return self.get_current_ghost_rules().get_actions_from_ghost_pos(ghost_pos, self.get_current_game_state().blocks_pos)

	def get_next_pos_from_ghost_pos_and_action(self, ghost_pos, action):

		traced_path = [ghost_pos] + [(ghost_pos[0]+neigh_pos[0], ghost_pos[1]+neigh_pos[1]) for neigh_pos in self.get_current_ghost_rules().check_empty_positions[action]]

		
		next_pos = traced_path[-1]
		# these members accesses from game_state do not change and hence it can be accessed from any instance
		while next_pos[0]+1<self.get_current_game_state().num_rows and (next_pos[0]+1,next_pos[1]) not in self.get_current_game_state().blocks_pos:
			next_pos = (next_pos[0]+1,next_pos[1])
			traced_path.append(next_pos)
		return next_pos, traced_path

	def reset(self):
		if self.train:
			self.game_state = self.starting_game_state
		else:
			self.test_game_state = self.starting_test_game_state
		self.score = 0

	def is_terminal(self, state):
		return self.is_goal_state(state)