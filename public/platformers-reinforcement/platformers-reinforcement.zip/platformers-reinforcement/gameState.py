import ghostDetails, playerDetails
import gameSettings

class GameState:

	def __init__(self, layout = None):
		if layout is None:
			return
		self.blocks_pos = list()
		self.foods_pos = list()
		self.freezers_pos = list()
		self.ghosts_details = list()
		self.player_details = None
		self.num_rows = len(layout)
		assert self.num_rows>1
		self.num_cols = len(layout[0])
		for i in range(self.num_rows):
			for j in range(self.num_cols):
				if layout[i][j] == 'B':
					self.blocks_pos.append((i,j))
				elif layout[i][j] == 'D':
					self.foods_pos.append((i,j))
				elif layout[i][j] == 'P':
					assert self.player_details is None
					self.player_details = playerDetails.PlayerDetails(0,(i,j))
				elif layout[i][j] == 'G':
					self.ghosts_details.append(ghostDetails.GhostDetails(len(self.ghosts_details)+1,(i,j)))
				elif layout[i][j] == 'F':
					self.freezers_pos.append((i,j))

		assert self.player_details is not None

	def is_goal_state(self):
		return len(self.foods_pos)==0 or not self.player_details.alive

	def __str__(self):
		return f"{gameSettings.short_terminal_separator}\nfoods_pos: {self.foods_pos}\nfreezers_pos: {self.freezers_pos}\nghosts_details: {self.ghosts_details}\nplayer_details: {self.player_details}\n{gameSettings.short_terminal_separator}"

	def shallow_copy(self):
		# does not copies the static entities of game state
		copied_game_state = GameState()
		copied_game_state.blocks_pos = self.blocks_pos		# shallow copy
		copied_game_state.foods_pos = [pos for pos in self.foods_pos]	
		copied_game_state.freezers_pos = [pos for pos in self.freezers_pos]
		copied_game_state.ghosts_details = [ghost_details.deep_copy() for ghost_details in self.ghosts_details]
		copied_game_state.player_details = self.player_details.deep_copy()
		copied_game_state.num_rows = self.num_rows
		copied_game_state.num_cols = self.num_cols
		return copied_game_state

	def __eq__(self, other):
		if isinstance(other, GameState):
			return self.blocks_pos == other.blocks_pos and self.foods_pos == other.foods_pos and self.freezers_pos == other.freezers_pos and self.ghosts_details == other.ghosts_details and self.player_details == other.player_details and self.num_rows == other.num_rows and self.num_cols == other.num_cols
		return False


	def __hash__(self):
		# Convert lists to tuples (which are hashable)
		return hash((
			tuple(self.blocks_pos), 
			tuple(self.foods_pos), 
			tuple(self.freezers_pos), 
			tuple(self.ghosts_details),  	# GhostDetails must also be hashable
			self.player_details,  			# PlayerDetails must be hashable
			self.num_rows, 
			self.num_cols, 
			))

	def get_player_position(self):
		return self.player_details.pos

	def get_ghosts_positions(self):
		return [ghost_details.pos for ghost_details in self.ghosts_details]

	def get_foods_positions(self):
		return [food_pos for food_pos in self.foods_pos]

	def get_ghosts_active_after_times(self):
		return [ghost_details.active for ghost_details in self.ghosts_details]

	def get_ghosts_reborn(self):
		return [ghost_details.reborn for ghost_details in self.ghosts_details]

	def get_num_foods(self):
		return len(self.foods_pos)

	def get_blocks_positions(self):
		return self.blocks_pos

	def get_num_rows(self):
		return self.num_rows

	def get_num_cols(self):
		return self.num_cols

	def get_ghosts_reborn(self):
		return [ghost_details.reborn for ghost_details in self.ghosts_details]

	def get_ghosts_initial_pos(self):
		return [ghost_details.initial_pos for ghost_details in self.ghosts_details]

	def get_freezers_positions(self):
		return [freezer_pos for freezer_pos in self.freezers_pos]
