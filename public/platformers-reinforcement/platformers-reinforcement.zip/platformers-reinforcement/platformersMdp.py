import os, sys
import argparse
import numpy as np
import pygame
import gameSettings, utils
import playerAgents
import copy

def parse_layout(layout_file_name):
    layout = list()
    script_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(script_dir, "layouts", layout_file_name)
    fh = open(path, "r")
    for line in fh:
        layout.append(list())
        for char in line:
            if char == '.':
                layout[-1].append('.')
            elif char == 'B':
                layout[-1].append('B')
            elif char == 'S':
                layout[-1].append('S')
            elif char == 'P':
                layout[-1].append('P')
            elif char == 'T':
                layout[-1].append('T')
            elif char == 'L':
                layout[-1].append('L')
            elif char == 'W':
                layout[-1].append('W') 

    return layout

def get_files_in_dir(dir):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(script_dir,dir)
    return [file for file in os.listdir(path) if os.path.isfile(os.path.join(path, file)) and file.startswith('mdp')]

def flip(sprites):
    return [pygame.transform.flip(sprite, flip_x = True, flip_y = False) for sprite in sprites]

def load_sprite_sheets(dir1, dir2, width, height, grid_size, direction=False):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(script_dir, "assets", dir1, dir2)
    images = [f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))]

    all_sprites = {}

    for image in images:
        sprite_sheet = pygame.image.load(os.path.join(path, image)).convert_alpha()

        sprites = []
        for i in range(sprite_sheet.get_width() // width):
            surface = pygame.Surface((width, height), pygame.SRCALPHA, 32)
            rect = pygame.Rect(i * width, 0, width, height)
            surface.blit(sprite_sheet, (0, 0), rect)
            sprites.append(pygame.transform.scale(surface,(grid_size,grid_size)))  # we need 64x64 instead of 32x32 images

        if direction:
            all_sprites[image.replace(".png", "") + "_right"] = sprites
            all_sprites[image.replace(".png", "") + "_left"] = flip(sprites)
        else:
            all_sprites[image.replace(".png", "")] = sprites
    return all_sprites

def get_food_image(bg_file_name, dir1, dir2, width, height, grid_size):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    sprite_sheet = pygame.image.load(os.path.join(script_dir,"assets",dir1, dir2, bg_file_name)).convert_alpha()
    sprites = []
    for i in range(sprite_sheet.get_width() // width):
        surface = pygame.Surface((width, height), pygame.SRCALPHA, 32)
        rect = pygame.Rect(i * width, 0, width, height)
        surface.blit(sprite_sheet, (0, 0), rect)
        sprites.append(pygame.transform.scale(surface,(grid_size, grid_size)))  # we need 64x64 instead of 32x32 images
    return sprites

def get_image_3(bg_file_name, dir1, dir2, dir3, width, height, grid_size):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    sprite_sheet = pygame.image.load(os.path.join(script_dir,"assets",dir1, dir2, dir3, bg_file_name)).convert_alpha()
    sprites = []
    for i in range(sprite_sheet.get_width() // width):

        surface = pygame.Surface((width, height), pygame.SRCALPHA, 32)
        rect = pygame.Rect(i * width, 0, width, height)
        surface.blit(sprite_sheet, (0, 0), rect)
        sprites.append(pygame.transform.scale(surface,(grid_size, grid_size)))  # we need 64x64 instead of 32x32 images
    return sprites

def get_image(bg_file_name, dirname, grid_size):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    image = pygame.image.load(os.path.join(script_dir,"assets",dirname,bg_file_name))
    return pygame.transform.scale(image, (grid_size, grid_size))

class PlatformersMdpPlayer:
    def __init__(self, start_pos, grid_size, rng):
        self.rng = rng
        self.grid_size = grid_size
        self.player_sprite_sheets = load_sprite_sheets(gameSettings.characters_folder ,gameSettings.player_name ,gameSettings.sprite_sheet_height ,gameSettings.sprite_sheet_height ,self.grid_size, True)
        self.locked = False
        self.dx = 0
        self.dy = 0
        self.gravity = gameSettings.gravity
        self.xvel = 1
        self.yvel = 1
        self.yvel_max = gameSettings.yvel_max
        self.yvel_min = gameSettings.yvel_min
        self.sprite_index_cur_count = 0
        self.sprite_index_update_count = gameSettings.animation_update_cnt
        self.start_pos = start_pos
        self.cur_state = None
        self.player_action = "noop"
        self.next_state = None
        self.traced_path = None
        self.animation_suffix = self.rng.choice(["left", "right"])
        self.traced_path_index = 0
        self.action_animation_list_index = 0
        self.action_animation_list_map =   {    "noop":              ["idle_"],
                                                "left":             ["run_", "fall_"],
                                                "right":            ["run_", "fall_"],
                                                "up":               ["jump_wave_"],
                                                "down":             ["fall_"]
                                            }
        self.sprite_sheet_cur_index = {    "idle_":             0,
                                            "run_":             0,
                                            "fall_":            0,
                                            "jump_wave_":       0,
                                        }
        
    def init_animate(self, state, chosen_action, next_state, traced_path):
        self.locked = True
        self.cur_state = state
        self.player_action = chosen_action
        self.next_state = next_state
        self.traced_path = traced_path
        self.animation_suffix = "left" if chosen_action == "left" else "right" if chosen_action == "right" else self.animation_suffix
        self.traced_path_index = 0
        self.action_animation_list_index = 0
        self.yvel = self.yvel_max if chosen_action == "up" else self.yvel_min
        
    def animate(self):
        if self.player_action == "noop":
            self.handle_noop()
        elif self.player_action == "left":
            self.handle_left()
        elif self.player_action == "right":
            self.handle_right()
        elif self.player_action == "up":
            self.handle_up()
        elif self.player_action == "down":
            self.handle_down()

    def handle_noop(self):
        self.unlock()

    def handle_left(self):
        if self.action_animation_list_index == 0:
            self.dx -= self.xvel
            if abs(self.dx)>=self.grid_size:
                self.action_animation_list_index += 1
        else:
            if abs(self.dx)<self.grid_size:
                self.dx -= self.xvel
            if abs(self.dy)<self.grid_size*(self.traced_path[-1][0]-self.traced_path[1][0]):
                self.dy += self.yvel
                self.yvel = min(self.yvel+self.gravity, self.yvel_max)
            elif abs(self.dx)>=self.grid_size:
                self.unlock()

    def handle_right(self):
        if self.action_animation_list_index == 0:
            self.dx += self.xvel
            if abs(self.dx) >= self.grid_size:
                self.action_animation_list_index += 1
        else:
            if abs(self.dx) < self.grid_size:
                self.dx += self.xvel
            if abs(self.dy) < self.grid_size*(self.traced_path[-1][0]-self.traced_path[1][0]):
                self.dy += self.yvel
                self.yvel = min(self.yvel+self.gravity, self.yvel_max)
            elif abs(self.dx) >= self.grid_size:
                self.unlock()

    def handle_up(self):
        if self.action_animation_list_index == 0:
            self.dy -= self.yvel
            self.yvel = max(self.yvel_min, self.yvel - self.gravity)
            if abs(self.dy) >= self.grid_size:
                self.unlock()

    def handle_down(self):
        if self.action_animation_list_index == 0:
            self.dy += self.yvel
            self.yvel = min(self.yvel_max, self.yvel + self.gravity)
            if abs(self.dy) >= self.grid_size*(self.traced_path[-1][0]-self.traced_path[0][0]):
                self.unlock()

    def unlock(self):
        self.cur_state = self.next_state
        self.player_action = "noop"
        self.next_state = None
        self.action_animation_list_index = 0
        self.dx = 0
        self.dy = 0
        self.xvel = 1
        self.yvel = 1
        self.locked = False

    def draw(self, window, offset_x, offset_y):
        if self.cur_state is not None:
            player_pos = self.cur_state
        else:
            player_pos = self.start_pos

        x = player_pos[1]*self.grid_size + self.dx
        y = player_pos[0]*self.grid_size + self.dy

        cur_sprite_sheet_key = self.action_animation_list_map[self.player_action][self.action_animation_list_index]
        cur_sprite_sheet_index = self.sprite_sheet_cur_index[cur_sprite_sheet_key]
        cur_sprite_sheet = cur_sprite_sheet_key + self.animation_suffix
        window.blit(self.player_sprite_sheets[cur_sprite_sheet][cur_sprite_sheet_index],(x-offset_x,y-offset_y))

        self.sprite_index_cur_count += 1
        if self.sprite_index_cur_count == self.sprite_index_update_count:
            self.sprite_sheet_cur_index[cur_sprite_sheet_key] = (cur_sprite_sheet_index + 1)%len(self.player_sprite_sheets[cur_sprite_sheet])
            self.sprite_index_cur_count = 0
        return (x-offset_x, y-offset_y)

class PlatformersMdpPlayerRules:
    def __init__(self, game_state):
        self.static_game_state = game_state
        self.check_empty_positions = {      "noop":             [],
                                            "left":             [(0,-1)],
                                            "right":            [(0,1)],
                                            "up":               [(-1,0)],
                                            "down":             [(1,0)],
                                        }


    def is_valid(self, pos):
        x, y = pos
        return x>=0 and x<self.static_game_state.num_rows and y>=0 and y<self.static_game_state.num_cols

    def get_actions(self, state: tuple):
        assert self.is_valid(state)
        assert not self.static_game_state.is_terminal(state)

        actions = []

        for action in self.check_empty_positions:
            for neigh_pos in self.check_empty_positions[action]:
                next_pos = (state[0]+neigh_pos[0], state[1]+neigh_pos[1])
                if action == "up":
                    # only up, because we can go down even if there is no ladder, only thing is that we fall then
                    # definitely, going down is possible only if the below pos is not a block pos
                    if not self.is_valid(next_pos) or next_pos not in self.static_game_state.ladders_pos:
                        break
                else:
                    if not self.is_valid(next_pos) or next_pos in self.static_game_state.blocks_pos:
                        break
            else:
                actions.append(action)
        return actions

    def get_next_state(self, state, action):
        assert not self.static_game_state.is_terminal(state)
        # this action is the one that is performed after being altered by environment
        next_state = list(state)

        traced_path = [state] + [(state[0]+neigh_pos[0], state[1]+neigh_pos[1]) for neigh_pos in self.check_empty_positions[action]]

        
        next_pos = traced_path[-1]
        while next_pos not in self.static_game_state.ladders_pos and next_pos[0]+1<self.static_game_state.num_rows and (next_pos[0]+1,next_pos[1]) not in self.static_game_state.blocks_pos:
            # for action 'up', on first check itself the traced_path[-1] is resting on a ladder, so works well still
            next_pos = (next_pos[0]+1,next_pos[1])
            traced_path.append(next_pos)

        terminal_state_reached_at_index_of_traced_path = dict()

        for traced_path_index, temp_pos in enumerate(traced_path):
            next_state = temp_pos
            if temp_pos in self.static_game_state.terminal_states:
                terminal_state_reached_at_index_of_traced_path[traced_path_index] = temp_pos
                break
        return next_state, traced_path[:traced_path_index+1], terminal_state_reached_at_index_of_traced_path

class Graphics:
    def __init__(self, num_rows, num_cols, blocks_pos, ladders_pos, terminal_states, score, start_state, fix_seed):
        # print(f'[platformersMdp.py] [Graphics] terminal_states {terminal_states}')
        pygame.init()
        self.rng = np.random.default_rng(seed = fix_seed)
        self.grid_size = 64
        info = pygame.display.Info()
        self.screen_width = info.current_w*3//4
        self.screen_height = info.current_h*3//4
        self.max_rows = self.screen_height//self.grid_size
        self.max_cols = self.screen_width//self.grid_size
        self.top_left = (self.screen_width//8, self.screen_height//8)

        self.num_rows = num_rows
        self.num_cols = num_cols
        self.blocks_pos = blocks_pos
        self.ladders_pos = ladders_pos
        self.terminal_states = terminal_states
        self.score = score
        self.game_height, self.game_width = min(self.num_rows*self.grid_size, self.max_rows*self.grid_size), min(self.num_cols*self.grid_size, self.max_cols*self.grid_size)

        os.environ['SDL_VIDEO_WINDOW_POS'] = f'{self.top_left[0]}, {self.top_left[1]}'
        pygame.display.set_caption('Platformers - MDP')
        self.window = pygame.display.set_mode((self.game_width, self.game_height))

        self.player = PlatformersMdpPlayer(start_state, self.grid_size, self.rng)
        self.init_offset(start_state)
        self.locked = False



        self.font = pygame.font.Font(None, 24)
        self.background_image = get_image("Yellow.png", gameSettings.background_folder, self.grid_size)
        self.block_image = get_image(gameSettings.block_file_name, gameSettings.block_folder, self.grid_size)
        self.ladder_image = get_food_image("magnet.png", "Traps", "Magnet", 1280, 1279, self.grid_size)[0]
        self.good_image = get_image_3("End.png", "Items", "Checkpoints", "End", 51, 51, self.grid_size)[0]
        self.best_image_sheet = get_image_3("end.png", "Items", "Checkpoints", "End", 46, 38, self.grid_size)
        self.bad_image_sheet = get_food_image("on.png", "Traps", "Saw", 38, 38, self.grid_size)
        self.good_image_index = 0
        self.bad_image_sheet_index = 0
        self.best_image_sheet_index = 0
        self.ladder_image_sheet_index = 0
        self.index_cur_count = 0
        self.index_update_cnt = gameSettings.animation_update_cnt


        self.up_image = get_food_image("red_up.png", "Traps", "Arrow", 64, 64, self.grid_size//2)[0]
        self.down_image = get_food_image("red_down.png", "Traps", "Arrow", 64, 64, self.grid_size//2)[0]
        self.left_image = get_food_image("red_left.png", "Traps", "Arrow", 64, 64, self.grid_size//2)[0]
        self.right_image = get_food_image("red_right.png", "Traps", "Arrow", 64, 64, self.grid_size//2)[0]
        self.stop_image = get_food_image("stop.png", "Traps", "Arrow", 204, 192, self.grid_size//2)[0]
        self.policy_for_arrows = None

        self.arrows_dict = { "up":       self.up_image,
                            "down":     self.down_image,
                            "left":     self.left_image,
                            "right":    self.right_image,
                            "noop":     self.stop_image
                            }

    def init_offset(self, initial_player_pos):
        if self.num_rows*self.grid_size<=self.game_height and self.num_cols*self.grid_size<=self.game_width:
            self.offset_x = 0
            self.offset_y = 0
        else:
            player_x = initial_player_pos[1]*self.grid_size
            player_y = initial_player_pos[0]*self.grid_size
            if player_x + self.grid_size > self.game_width - self.grid_size:
                self.offset_x = player_x + self.grid_size - self.game_width + (self.grid_size if initial_player_pos[1]<self.num_cols-1 else 0)
            else:
                self.offset_x = 0
            if player_y + self.grid_size > self.game_height - self.grid_size:
                self.offset_y = player_y + self.grid_size - self.game_height + (self.grid_size if initial_player_pos[0]<self.num_rows-1 else 0)
            else:
                self.offset_y = 0
        
    def adjust_offset(self, top_left_player):
        
        player_pixel_x, player_pixel_y = top_left_player
        if player_pixel_x <2*self.grid_size:
            if self.offset_x > 0:
                self.offset_x += player_pixel_x - 2*self.grid_size
        elif player_pixel_x + self.grid_size > self.game_width - 2*self.grid_size:
            if self.offset_x < (self.grid_size*self.num_cols - self.game_width):    # max offset possible
                self.offset_x += player_pixel_x + self.grid_size - self.game_width + 2*self.grid_size

        if player_pixel_y <2*self.grid_size:
            if self.offset_y > 0:
                self.offset_y += player_pixel_y - 2*self.grid_size

        elif player_pixel_y + self.grid_size > self.game_height - 2*self.grid_size:
            if self.offset_y < (self.grid_size*self.num_rows - self.game_height):   # max offset possible
                self.offset_y += player_pixel_y + self.grid_size - self.game_height + 2*self.grid_size


    def draw_background(self):
        for i in range(0, self.num_cols):
            for j in range(0, self.num_rows):
                x = i*self.grid_size
                y = j*self.grid_size
                self.window.blit(self.background_image,(x-self.offset_x,y-self.offset_y))
                if self.policy_for_arrows is not None:
                    # check if this pos is a valid position
                    if (j, i) in self.policy_for_arrows and self.policy_for_arrows[(j, i)] in self.arrows_dict:
                        self.window.blit(self.arrows_dict[self.policy_for_arrows[(j, i)]],(x-self.offset_x+self.grid_size//4,y-self.offset_y+self.grid_size//4))

    def draw_blocks(self):
        for block in self.blocks_pos:
            x = block[1]*self.grid_size
            y = block[0]*self.grid_size
            self.window.blit(self.block_image,(x-self.offset_x,y-self.offset_y))

    def draw_ladders(self):
        for ladder in self.ladders_pos:
            x = ladder[1]*self.grid_size
            y = ladder[0]*self.grid_size
            self.window.blit(self.ladder_image,(x-self.offset_x,y-self.offset_y))
            if self.policy_for_arrows is not None:
                # check if this pos is a valid position
                if ladder in self.policy_for_arrows and self.policy_for_arrows[ladder] in self.arrows_dict:
                    self.window.blit(self.arrows_dict[self.policy_for_arrows[ladder]],(x-self.offset_x+self.grid_size//4,y-self.offset_y+self.grid_size//4))

    def draw_goods(self):
        for state in self.terminal_states:
            if self.terminal_states[state]>0:
                good = state

                x = good[1]*self.grid_size
                y = good[0]*self.grid_size

                if self.terminal_states[state] == max(self.terminal_states.values()):
                    self.window.blit(self.best_image_sheet[(self.best_image_sheet_index)%len(self.best_image_sheet)],(x-self.offset_x,y-self.offset_y))
                else:
                    self.window.blit(self.good_image,(x-self.offset_x,y-self.offset_y))
                if self.policy_for_arrows is not None:
                    # check if this pos is a valid position
                    if state in self.policy_for_arrows and self.policy_for_arrows[state] in self.arrows_dict:
                        self.window.blit(self.arrows_dict[self.policy_for_arrows[state]],(x-self.offset_x+self.grid_size//4,y-self.offset_y+self.grid_size//4))

        if self.index_cur_count == self.index_update_cnt:
            self.best_image_sheet_index = (self.best_image_sheet_index + 1)%len(self.best_image_sheet)


    def draw_bads(self):
        for state in self.terminal_states:
            if self.terminal_states[state]<0:
                bad = state

                x = bad[1]*self.grid_size
                y = bad[0]*self.grid_size
                self.window.blit(self.bad_image_sheet[(self.bad_image_sheet_index)%len(self.bad_image_sheet)],(x-self.offset_x,y-self.offset_y))

                if self.policy_for_arrows is not None:
                    # check if this pos is a valid position
                    if state in self.policy_for_arrows and self.policy_for_arrows[state] in self.arrows_dict:
                        self.window.blit(self.arrows_dict[self.policy_for_arrows[state]],(x-self.offset_x+self.grid_size//4,y-self.offset_y+self.grid_size//4))

        if self.index_cur_count == self.index_update_cnt:
            self.bad_image_sheet_index = (self.bad_image_sheet_index + 1)%len(self.bad_image_sheet)

    def draw_score(self):
        text = self.font.render(f'Score: {round(self.score, 5)}', True, (0, 0, 0))
        text_rect = text.get_rect()
        text_rect.topleft = (10, 10)
        self.window.blit(text, text_rect)

    def draw(self):
        self.index_cur_count += 1
        self.draw_background()
        self.draw_blocks()
        self.draw_ladders()
        self.draw_goods()
        self.draw_bads()
        top_left_player = self.player.draw(self.window, self.offset_x, self.offset_y)
        if self.index_cur_count == self.index_update_cnt:
            self.index_cur_count = 0
        
        self.draw_score()
        self.adjust_offset(top_left_player)

    def init_animate(self, state, chosen_action, next_state, new_score, traced_path):
        self.locked = True
        self.executing_state = state
        self.executing_action = chosen_action
        self.next_state = next_state
        self.new_score = new_score
        self.player.init_animate(state, chosen_action, next_state, traced_path)
        self.animate()

    def animate(self):
        # check if player has reached its final destination, then unlock the game for next step
        if self.player.locked:
            self.player.animate()
        else:
            # update the state in problem and also for the game
            self.unlock()
            return True     # to show animation over

    def unlock(self):
        self.score = self.new_score
        self.locked = False

class PlatformersMdpProblem:
    def __init__(self, layout: list[list[str]], fix_seed, living_reward = 0, noise = 0.4, s_value = -1, t_value = +1, w_value = +10):
        self.rng = np.random.default_rng(seed = fix_seed)
        self.num_rows = len(layout)
        self.num_cols = len(layout[0])
        self.actions = ('left', 'right', 'up', 'down', 'noop') 

        self.living_reward = living_reward
        self.noise = noise

        # state is the player position only
        self.cur_state = None

        self.states = set()
        self.blocks_pos = set()
        self.terminal_states = dict()
        self.ladders_pos = set()     # store the top and bottom position of ladder
        self.goods_pos = set()
        self.bads_pos = set()
        for i in range(len(layout)):
            for j in range(len(layout[i])):
                if layout[i][j] == '.':
                    # it is a state only if it is over a blockPos
                    if i+1<len(layout) and layout[i+1][j]=='B':
                        self.states.add((i, j))
                elif layout[i][j] == 'B':
                    self.blocks_pos.add((i, j))
                elif layout[i][j] == 'S':
                    self.terminal_states[(i, j)] = s_value
                    self.states.add((i, j))
                elif layout[i][j] == 'P':
                    self.states.add((i, j))
                    assert self.cur_state is None
                    self.cur_state = (i, j)
                elif layout[i][j] == 'T':
                    self.terminal_states[(i, j)] = t_value
                    self.goods_pos.add((i, j))
                    self.states.add((i, j))
                elif layout[i][j] == 'W':
                    self.goods_pos.add((i, j))
                    self.terminal_states[(i, j)] = w_value
                    self.states.add((i, j))
                elif layout[i][j] == 'L':
                    self.ladders_pos.add((i, j))
                    self.bads_pos.add((i, j))
                    self.states.add((i, j))

        assert self.cur_state is not None
        self.start_state = self.cur_state

        self.rules = PlatformersMdpPlayerRules(self)

        # for value iteration agent
        self.agent_iteration_wise_values = dict()
        
        # for policy iteration agent
        self.agent_iteration_wise_policy = dict()  

    def get_goods_pos(self):
        return set(self.goods_pos)

    def get_bads_pos(self):
        return set(self.bads_pos)

    def get_num_rows(self):
        return self.num_rows

    def get_num_cols(self):
        return self.num_cols

    def get_states(self):
        return self.states

    def get_state(self):
        return self.cur_state

    def get_reward(self, state, action, next_state):
        assert not self.is_terminal(state)

        if self.is_terminal(next_state):
            return self.terminal_states[next_state]

        return self.living_reward

    def get_start_state(self):
        self.start_state

    def is_terminal(self, state):
        return state in self.terminal_states

    def get_terminal_states(self):
        return self.terminal_states

    def get_transition_states_and_probs_unfiltered(self, state, action):
        actions = self.rules.get_actions(state)
        assert action in actions, "Illegal action!"

        assert not self.is_terminal(state)

        row, col = state

        successors = []

        for action_iter in actions:
            next_pos, _, _ = self.rules.get_next_state(state, action_iter)
            if action_iter == action:
                successors.append((action_iter, next_pos, 1-self.noise))
            else:
                successors.append((action_iter, next_pos, self.noise/(len(actions) - 1)))  # if actions is singleton, then this else part would never be reached

        return successors   

    def get_transition_states_and_probs(self, state, action):
        successors = self.get_transition_states_and_probs_unfiltered(state, action)
        return [(next_state, prob) for _, next_state, prob in successors]

    def environment_action(self, successors):
        r = self.rng.random()
        cumProb = 0

        for successor in successors:
            cumProb += successor[2]

            if r <= cumProb:
                return successor[0]

    def reset(self):
        self.cur_state = self.start_state

    def update_state(self, next_state):
        self.cur_state = next_state

    def get_actions(self, agent_index, state):
        return self.rules.get_actions(state)

    def do_action(self, state, chosen_action):
        next_state, traced_path, _ = self.rules.get_next_state(state, chosen_action)
        reward = self.get_reward(state, chosen_action, next_state)

        return next_state, reward, traced_path

    def register_values(self, values, iteration):
        self.agent_iteration_wise_values[iteration] = copy.deepcopy(values)

    def register_policy(self, policy, iteration):
        self.agent_iteration_wise_policy[iteration] = copy.deepcopy(policy)

    def get_next_pos_from_player_pos_and_action(self, pos, action):
        next_pos = self.rules.get_next_state(pos, action)[0]
        return next_pos

    def get_actions_from_player_pos(self, pos):
        return self.rules.get_actions(pos)

def run_episode_with_graphics(agent, problem, discount, graphics_seed, verbose=True):
    if verbose:
        print(f"----EPISODE begins----")
    run = True
    problem.reset()
    long_term_reward = 0
    total_discount = 1

    graphics = Graphics(problem.num_rows, problem.num_cols, problem.blocks_pos, problem.ladders_pos, problem.get_terminal_states(), long_term_reward, problem.start_state, graphics_seed)

    clock = pygame.time.Clock()
    graphics.draw()
    pygame.display.update()
    FPS = 60
    while run:
        clock.tick(FPS)
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                run = False
                break

        if graphics.locked:
            animationOver = graphics.animate()
            if animationOver:
                problem.update_state(graphics.next_state)
        else:
            state = problem.get_state()
            if verbose:
                print(f'state {state}')
            if problem.is_terminal(state):
                if verbose:
                    print(f'Terminal State Reached!')
                run = False
                break

            action = agent.act(state, problem)

            if hasattr(agent, "policy") and agent.policy is not None and graphics.policy_for_arrows is None:
                # even with Q Learning agents, if the student is maintaining the policy then it will be rendered else not
                graphics.policy_for_arrows = agent.policy # copy by reference

            if verbose:
                print(f'action {action}')

            transition_probs = problem.get_transition_states_and_probs_unfiltered(state, action)
            modified_action = problem.environment_action(transition_probs)

            next_state, reward, traced_path = problem.do_action(state, modified_action)
            if hasattr(agent, "observe_transition"):
                
                agent.observe_transition(state, action, next_state, reward, problem)

            if verbose:
                print(f'next_state {next_state}')
                print(f'reward {reward}')
                print(f'-----------------------')
            long_term_reward += reward * total_discount
            total_discount *= discount
            graphics.init_animate(state, modified_action, next_state, long_term_reward, traced_path)



        graphics.draw()

        pygame.display.update()

    pygame.quit()

    if verbose:
        print(f'----EPISODE ends----')
        print(f'Total returns: {long_term_reward}')
    return long_term_reward

def run_episode(agent, problem, discount, display, graphics_seed, verbose=True):

    if display:
        return run_episode_with_graphics(agent, problem, discount, graphics_seed, verbose)
        return 
    if verbose:
        print(f"----EPISODE begins----")

    problem.reset()
    long_term_reward = 0
    total_discount = 1
    while True:

        state = problem.get_state()
        if verbose:
            print(f'state {state}')
        if problem.is_terminal(state):
            if verbose:
                print(f'Terminal State Reached!')
            break

        action = agent.act(state, problem)
            
        if verbose:
            print(f'action {action}')

        transition_probs = problem.get_transition_states_and_probs_unfiltered(state, action)
        modified_action = problem.environment_action(transition_probs)

        next_state, reward, traced_path = problem.do_action(state, modified_action)
        if hasattr(agent, "observe_transition"):
            
            agent.observe_transition(state, action, next_state, reward, problem)

        long_term_reward += reward * total_discount
        total_discount *= discount
        if verbose:
            print(f'next_state {next_state}')
            print(f'reward {reward}')
            print(f'-----------------------')
        problem.update_state(next_state)
    # the episode is thus over
    if verbose:
        print(f'----EPISODE ends----')
        print(f'Total returns: {long_term_reward}')
    return long_term_reward


def parse_arguments():

    defined_layouts = get_files_in_dir("layouts")

    defined_agents = utils.get_class_names("playerAgents.py")

    defined_feature_extractors = utils.get_function_names(gameSettings.feature_extractors_file_name)

    arg_parser = argparse.ArgumentParser(description='Play the game of PlatformersMdp. Run "python3 platformersMdp.py -h" to view the list of argument options available')
    arg_parser.add_argument('--discount', type=float, default=0.9, help='Discount on future')
    arg_parser.add_argument('--epsilon', type=float, help='Specify the probability of exploration', default=gameSettings.default_epsilon_value)
    arg_parser.add_argument('--alpha', type=float, help='Specify the learning rate of temporal difference agent', default=gameSettings.default_ghost_noise_value)
    arg_parser.add_argument('--train', type = int, help='Number of games to train on', default = 0)
    arg_parser.add_argument('--test', type = int, help='Number of episodes of game to test on', default = 0)
    arg_parser.add_argument('--livingReward', type=float, default=0.0, help='Reward for living for a time step')
    arg_parser.add_argument('--noise', type=float, default=0.2, help='How often action results in unintended direction')
    arg_parser.add_argument('--iterations', type=int, default=100, help='Number of rounds of value/ policy iteration')
    arg_parser.add_argument('--layout', type=str, default="mdpBookGrid.lay", help='Layout to use (case sensitive)', choices = defined_layouts)
    arg_parser.add_argument('--agent', type=str, default="KeyboardAgent", help='Agent type', choices = defined_agents)
    arg_parser.add_argument('--noGraphics', action='store_true', default=False, help='Skip GUI display (not for KeyboardAgent)')
    arg_parser.add_argument('--noTrainGraphics', action='store_true', help='Disable the display')
    arg_parser.add_argument('--noTestGraphics', action='store_true', help='Disable the display')
    arg_parser.add_argument('--verbose', action='store_true', help='Display transitions in terminal')
    arg_parser.add_argument('--featureExtractor', type=str, help='Specify the feature extractor to use', default=gameSettings.default_feature_extractor, choices = defined_feature_extractors)
    arg_parser.add_argument('--S', type=float, default=-1.0, help='Negative reward for a state')
    arg_parser.add_argument('--T', type=float, default=+1.0, help='Positive reward for a state (usually, smaller positive reward value)')
    arg_parser.add_argument('--W', type=float, default=+10.0, help='Positive reward for a state (usually, larger positive reward value)')
    arg_parser.add_argument('--fixSeed', type=int, help='Fix a random seed')

    args = arg_parser.parse_args()

    return args


if __name__ == '__main__':

    args = parse_arguments()
    display = not args.noGraphics
    train_display = not args.noTrainGraphics
    test_display = not args.noTestGraphics
    if not display:
        train_display = False
        test_display = False
    feature_extractor = args.featureExtractor
    layout = parse_layout(args.layout)
    living_reward = args.livingReward
    noise = args.noise
    discount = args.discount
    s_value = args.S 
    t_value = args.T
    w_value = args.W
    iterations = args.iterations
    epsilon = args.epsilon
    alpha = args.alpha
    train = args.train
    test = args.test
    verbose = args.verbose


    if args.fixSeed is not None:
        assert 0<=args.fixSeed<=2**32-1, "Seed value must be between 0 and 2**32-1"
        simpleRNG = np.random.default_rng(seed = args.fixSeed)
    else:
        simpleRNG = np.random.default_rng() # undetermined seed

    assert display or args.agent != "KeyboardAgent"

    assert 0 <= noise <= 1
    assert 0 <= discount <= 1
    assert 0<=alpha<=1
    assert 0<=epsilon<=1
    assert train >= 0
    assert test >= 0

    if train == 0 and test == 0:
        # none specified
        test = 1    

    agent = getattr(playerAgents, args.agent)({'iterations': iterations, 'discount': discount, 'alpha': alpha, 'epsilon': epsilon, 'rng': np.random.default_rng(seed = simpleRNG.integers(0,2**32)), 'feature_extractor': feature_extractor})
    problem = PlatformersMdpProblem(layout, simpleRNG.integers(0,2**32), living_reward, noise, s_value, t_value, w_value)
    
    
    # at max 10 prints should come from training
    if train<=10:
        batch_size = 1
    else:
        num_batches = 10
        batch_size = np.ceil(train/num_batches)
    total_score_of_batch = 0
    last_train_index = -1
    for i in range(train):
        print_train = ((i+1)%batch_size == 0) or (i==train-1 and last_train_index!=i)

        try:
            score = run_episode(agent, problem, discount, train_display, simpleRNG.integers(0,2**32), verbose)
        except Exception as e:
            utils.print_exception(e)
            sys.exit(1)
        total_score_of_batch += score
        if print_train:
            print(f"Total for {i-last_train_index} games: {total_score_of_batch}\nAverage for {i-last_train_index} games: {total_score_of_batch/(i-last_train_index)}\n------------------")
            last_train_index = i
            total_score_of_batch = 0

    if hasattr(agent, 'stop_training'):
        agent.stop_training()
        if hasattr(agent, 'weights'):
            print(f'Training completed! \nWeights:')
            for feature in agent.weights:
                print(f'{feature}: {agent.weights[feature]}')
            print()

    for i in range(test):
        try:
            score = run_episode(agent, problem, discount, test_display, simpleRNG.integers(0,2**32), verbose)
        except Exception as e:
            utils.print_exception(e)
            sys.exit(1)
        print(f'Score: {score}')