import utils

def identity_feature_extractor(state, action, problem, cache = None):
	features = {f'({state}, {action})': 1}
	return features

def simple_feature_extractor(state, action, problem, cache = None):
	foods_pos = state.get_foods_positions()
	ghosts_pos = state.get_ghosts_positions()
	if cache is not None and len(cache)==0:
		cache['player'] = dict()
		cache['ghost'] = dict()

	features = dict()

	features["bias"] = 1.0

	# compute the location of pacman after he takes the action
	player_pos = state.get_player_position()
	next_player_pos, _ = problem.get_next_pos_from_player_pos_and_action(player_pos, action)

	if next_player_pos not in cache['player']:
		player_next_pos_distance_dict = utils.single_player_source_all_pos_dist(next_player_pos, problem)
		cache['player'][next_player_pos] = player_next_pos_distance_dict
	else:
		player_next_pos_distance_dict = cache['player'][next_player_pos]

	ghosts_dist = []
	for ghost_pos in ghosts_pos:
		if ghost_pos not in cache['ghost']:
			ghost_dist = utils.single_ghost_source_all_pos_dist(ghost_pos, problem)
			cache['ghost'][ghost_pos] = ghost_dist
		else:
			ghost_dist = cache['ghost'][ghost_pos]
		ghosts_dist.append(ghost_dist)

	# count the number of ghosts 1-step away
	features["no-of-ghosts-1-step-away"] = sum(int(ghost_dist[next_player_pos] == 1) if next_player_pos in ghost_dist else 0 for ghost_dist in ghosts_dist)  	# this should be as per ghost rules
	features['killed'] = int(next_player_pos in ghosts_pos)
	# if there is no danger of ghosts then add the food feature
	if not features["no-of-ghosts-1-step-away"] and next_player_pos in foods_pos:
		features["eats-food"] = 1.0

	dist = None
	for food_pos in foods_pos:
		if food_pos in player_next_pos_distance_dict:
			cur_dist = player_next_pos_distance_dict[food_pos]
			if dist is None or cur_dist < dist:
				dist = cur_dist

	if dist is not None:
		# make the distance a number less than one otherwise the update
		# will diverge wildly
		features["closest-food"] = float(dist)/(state.get_num_rows()*state.get_num_cols())
	for feature in features:
		features[feature] /= 10.0
		assert features[feature]<=1, features

	return features


'''
Q6: Advanced Feature Extractor
Implement a feature extractor that accounts for more fine details that the simple feature extractor. 
'''
def advanced_feature_extractor(state, action, problem, cache = None):
	'''
	Details:-
	1. traced_path: It is the list of positions that player traverses from player_pos to next_player_pos.
	
	Helpful APIs:-
	1. utils.single_player_source_all_pos_dist(next_player_pos, problem): Returns a dictionary with all reachable positions (as per player rules) as key and distance from next_player_pos as the value.
	2. single_ghost_source_all_pos_dist(ghost_pos, problem): Returns a dictionary with all reachable positions (as per ghost rules) as key and distance from ghost_pos as the value.
	'''

	foods_pos = state.get_foods_positions()
	ghosts_pos = state.get_ghosts_positions()
	ghosts_active_after_times = state.get_ghosts_active_after_times()
	ghosts_initial_pos = state.get_ghosts_initial_pos()
	ghosts_reborn = state.get_ghosts_reborn()
	player_pos = state.get_player_position()
	next_player_pos, traced_path = problem.get_next_pos_from_player_pos_and_action(player_pos, action)
	freezers_pos = state.get_freezers_positions()
	features = dict()
	features['bias'] = 1.0

	''' YOUR CODE HERE '''

	return features

	raise utils.MethodNotImplementedError('advanced_feature_extractor')


'''
Q7: Layout Independent Learning
Implement a feature extractor that focuses on winning as soon as possible and nothing else. This will be used for cross layout testing. 
'''
def cross_feature_extractor(state, action, problem, cache = None):
	'''
	Details:-
	1. traced_path: It is the list of positions that player traverses from player_pos to next_player_pos.
	
	Helpful APIs:-
	1. utils.single_player_source_all_pos_dist(next_player_pos, problem): Returns a dictionary with all reachable positions (as per player rules) as key and distance from next_player_pos as the value.
	2. single_ghost_source_all_pos_dist(ghost_pos, problem): Returns a dictionary with all reachable positions (as per ghost rules) as key and distance from ghost_pos as the value.
	'''

	foods_pos = state.get_foods_positions()
	ghosts_pos = state.get_ghosts_positions()
	ghosts_active_after_times = state.get_ghosts_active_after_times()
	ghosts_initial_pos = state.get_ghosts_initial_pos()
	ghosts_reborn = state.get_ghosts_reborn()
	player_pos = state.get_player_position()
	next_player_pos, traced_path = problem.get_next_pos_from_player_pos_and_action(player_pos, action)
	freezers_pos = state.get_freezers_positions()
	features = dict()
	features['bias'] = 1.0

	''' YOUR CODE HERE '''

	return features

	raise utils.MethodNotImplementedError('advanced_feature_extractor')