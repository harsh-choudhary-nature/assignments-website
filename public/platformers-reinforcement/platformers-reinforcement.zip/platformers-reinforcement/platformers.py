import argparse, sys
import gameSettings
import numpy as np
import problems
import utils


def main():
	defined_cost_functions = utils.get_function_names(gameSettings.cost_functions_file_name)
	defined_layouts = [filename for filename in utils.get_files_in_dir("layouts") if not filename.startswith("mdp")]
	defined_agents = [className for className in utils.get_class_names(gameSettings.player_agents_file_name) if className != "ValueIterationAgent" and className != "PolicyIterationAgent"]
	defined_ghost_agents = utils.get_class_names(gameSettings.ghost_agents_file_name)
	arg_parser = argparse.ArgumentParser(description='Play the game of Platformers. Run "python3 platformers.py -h" to view the list of argument options available')
	defined_feature_extractors = utils.get_function_names(gameSettings.feature_extractors_file_name)

	# Define the expected command-line arguments
	arg_parser.add_argument('--layout', type=str, help='Specify the layout(.lay file) of the game.', default=gameSettings.default_layout, choices = defined_layouts)
	arg_parser.add_argument('--testLayout', type=str, help='Specify the layout(.lay file) of the game for test.', choices = defined_layouts) # no default value
	arg_parser.add_argument('--playerAgent', type=str, help='Specify the type of agent to use', default=gameSettings.default_player_agent, choices=defined_agents)
	arg_parser.add_argument('--costFn', type=str, help='Specify the cost function for the player', default=gameSettings.default_cost_function, choices = defined_cost_functions)
	arg_parser.add_argument('--ghostAgent', type=str, help='Specify the number of ghosts', default=gameSettings.default_ghost_agent, choices = defined_ghost_agents)
	arg_parser.add_argument('--fixSeed', type=int, help='Fix a random seed')
	arg_parser.add_argument('--noGraphics', action='store_true', help='Disable the display')
	arg_parser.add_argument('--noTrainGraphics', action='store_true', help='Disable the display')
	arg_parser.add_argument('--noTestGraphics', action='store_true', help='Disable the display')
	arg_parser.add_argument('--featureExtractor', type=str, help='Specify the feature extractor to use', default=gameSettings.default_feature_extractor, choices = defined_feature_extractors)
	arg_parser.add_argument('--ghostNoise', type=float, help='Specify the probability of best action towards the ghost', default=gameSettings.default_ghost_noise_value)
	arg_parser.add_argument('--discount', type=float, help='Specify the discount to use', default=gameSettings.default_discount_value)
	arg_parser.add_argument('--epsilon', type=float, help='Specify the probability of exploration', default=gameSettings.default_epsilon_value)
	arg_parser.add_argument('--alpha', type=float, help='Specify the learning rate of temporal difference agent', default=gameSettings.default_ghost_noise_value)
	arg_parser.add_argument('--train', type = int, help='Number of games to train on', default = 0)
	arg_parser.add_argument('--test', type = int, help='Number of games to test on', default = 0)



	args = arg_parser.parse_args()

	layout_filename = args.layout
	player_agent = args.playerAgent
	cost_function = args.costFn
	ghost_agent = args.ghostAgent
	no_graphics = args.noGraphics
	no_train_graphics = args.noTrainGraphics
	no_test_graphics = args.noTestGraphics
	if no_graphics:
		no_train_graphics = True
		no_test_graphics = True
	feature_extractor = args.featureExtractor
	ghost_noise = args.ghostNoise
	discount = args.discount
	epsilon = args.epsilon
	alpha = args.alpha
	train = args.train
	test = args.test

	if args.testLayout is not None:
		test_layout_filename = args.testLayout
	else:
		test_layout_filename = layout_filename

	assert 0<=discount<=1
	assert 0<=alpha<=1
	assert 0<=epsilon<=1
	assert train >= 0
	assert test >= 0

	problem_args = {'layout_filename': layout_filename, 
					'test_layout_filename': test_layout_filename, 
					'player_agent': player_agent,
					'cost_function': cost_function,
					'ghost_agent': ghost_agent,
					'feature_extractor': feature_extractor,
					'ghost_noise': ghost_noise,
					'no_train_graphics': no_train_graphics,
					'no_test_graphics':	no_test_graphics,
					'discount': discount,
					'alpha': alpha,
					'epsilon': epsilon
					}
	if args.fixSeed is not None:
		assert 0<=args.fixSeed<=2**32-1, "Seed value must be between 0 and 2**32-1"
		simpleRNG = np.random.default_rng(seed = args.fixSeed)
	else:
		simpleRNG = np.random.default_rng()	# undetermined seed

	# Using the seed parameter in numpy.random.default_rng() will ensure reproducible results even if the host machine is changed, as long as the same version of NumPy and the same random number generator are used.

	problem_args['fix_seed'] = simpleRNG.integers(0, 2**32)
	problem = problems.PlatformersReinforcementProblem(problem_args)

	if train == 0 and test == 0:
		# none specified
		test = 1	


	# at max 10 prints should come from training
	if train<=10:
		batch_size = 1
	else:
		num_batches = 10
		batch_size = np.ceil(train/num_batches)
	total_score_of_batch = 0
	wins_of_batch = 0
	last_train_index = -1

	for i in range(train):
		print_train = ((i+1)%batch_size == 0) or (i==train-1 and last_train_index!=i)
		try:
			won, score = problem.solve(train=True)
		except Exception as e:
			utils.print_exception(e)
			sys.exit(1)
		total_score_of_batch += score
		wins_of_batch += int(won)
		if print_train:
			print(f"Total for {i-last_train_index} games: {total_score_of_batch}\nAverage for {i-last_train_index} games: {total_score_of_batch/(i-last_train_index)}\nWon games: {wins_of_batch}\n------------------")
			last_train_index = i
			total_score_of_batch = 0
			wins_of_batch = 0


		problem.reset()

	if hasattr(problem.player_agent, 'stop_training'):
		problem.player_agent.stop_training()
		if hasattr(problem.player_agent, 'weights'):
			print(f'Training completed! \nWeights:')
			for feature in problem.player_agent.weights:
				print(f'{feature}: {problem.player_agent.weights[feature]}')
			print()

	for i in range(test):
		print(f'{i}:', end = ' ')
		won, score = problem.solve(train=False)
		if won:
			print(f'You won!\tScore: {score}')
		else:
			print(f'You lost!\tScore: {score}')
		problem.reset()

		
if __name__ == "__main__":
	main()