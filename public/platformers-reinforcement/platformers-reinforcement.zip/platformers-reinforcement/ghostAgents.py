import utils

class RandomGhostAgent:
	def __init__(self, args):
		self.rng = args['rng']
		pass

	def act(self, agent_index, game_state, problem):
		actions = problem.get_actions(agent_index, game_state)
		return self.rng.choice(actions)

class StaticGhostAgent:
	def __init__(self, args):
		pass

	def act(self, agent_index, game_state, problem):
		return "noop"

class DirectionalGhostAgent:
	
	def __init__(self, args):
		pass
		self.ghost_noise = args['ghost_noise']
		self.rng = args['rng']

	def act(self, agent_index, game_state, problem):
		actions = problem.get_actions(agent_index, game_state)
		best_action, best_dist = None, 1e9
		player_pos = game_state.player_details.pos
		for action in actions:
			next_pos = problem.get_current_ghost_rules().get_next_game_state(agent_index, game_state, action)[0].ghosts_details[agent_index-1].pos
			next_dist = utils.graph_distance_bfs(next_pos, [player_pos], problem)
			if next_dist == -1:
				continue
			if next_dist < best_dist or best_action is None:
				best_action = action
				best_dist = next_dist
		
		if best_action is None:
			# choose the action that minimizes Manhattan distance
			for action in actions:
				next_pos = problem.get_current_ghost_rules().get_next_game_state(agent_index, game_state, action)[0].ghosts_details[agent_index-1].pos
				next_dist = utils.manhattan_distance(next_pos, player_pos)
				if next_dist<best_dist or best_action is None:
					best_action = action
					best_dist = next_dist
		# with self.ghost_noise probability choose best_action
		r = self.rng.random()
		if r<self.ghost_noise:
			return best_action
		else:
			return self.rng.choice(actions)

