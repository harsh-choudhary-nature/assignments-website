import utils, gameSettings
import numpy as np, gymnasium as gym
import argparse
import playerAgents
import pygame, sys

class MountainCarProblem:
	def __init__(self, args):
		self.fix_seed_value = args['fix_seed']
		self.problemRNG = np.random.default_rng(seed = args['fix_seed'])
		self.train_graphics_enabled = not args['no_train_graphics']
		self.test_graphics_enabled = not args['no_test_graphics']
		self.score = 0

		self.env = gym.make('MountainCar-v0')
		self.vis_env = gym.make('MountainCar-v0', render_mode='human')

		# Divide position and velocity into segments
		self.pos_space = np.linspace(self.env.observation_space.low[0], self.env.observation_space.high[0], 20)    # Between -1.2 and 0.6 into 20 bins
		self.vel_space = np.linspace(self.env.observation_space.low[1], self.env.observation_space.high[1], 20)    # Between -0.07 and 0.07 into 20 bins


		player_args = {'epsilon': args['epsilon'], 'alpha': args['alpha'], 'discount': args['discount'], 'rng': self.problemRNG}
		self.agent = getattr(playerAgents, args['agent'])(player_args)


	def solve(self, train):
		if train:
			if self.train_graphics_enabled:
				return self.solve_with_graphics()
			else:
				return self.solve_no_graphics()
		else:
			self.agent.stop_training()
			if self.test_graphics_enabled:
				return self.solve_with_graphics()
			else:
				return self.solve_no_graphics()

	def solve_with_graphics(self):
		observation = self.vis_env.reset()[0]
		state_p = np.digitize(observation[0], self.pos_space)
		state_v = np.digitize(observation[1], self.vel_space)
		self.state = (state_p, state_v)
		self.score = 0
		while not self.is_terminal(self.state):
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					print("*** Game closed by user!")
					self.env.close()
					return  # Exit the function to end the episode

			initial_state = self.state
			initial_score = self.score

			action = self.agent.act(self.state, self)

			observation, reward, terminated, _, _ = self.vis_env.step(action)
			next_state_p = np.digitize(observation[0], self.pos_space)
			next_state_v = np.digitize(observation[1], self.vel_space)
			next_state = (next_state_p, next_state_v)

			self.state = next_state
			self.score += reward

			final_state = next_state
			final_score = self.score
			reward = final_score - initial_score

			self.agent.observe_transition(initial_state, action, final_state, reward, self)

		return self.score		

	def solve_no_graphics(self):
		observation = self.env.reset()[0]
		state_p = np.digitize(observation[0], self.pos_space)
		state_v = np.digitize(observation[1], self.vel_space)
		self.state = (state_p, state_v)
		self.score = 0
		while not self.is_terminal(self.state):
			initial_state = self.state
			initial_score = self.score

			action = self.agent.act(self.state, self)

			observation, reward, terminated, _, _ = self.env.step(action)
			next_state_p = np.digitize(observation[0], self.pos_space)
			next_state_v = np.digitize(observation[1], self.vel_space)
			next_state = (next_state_p, next_state_v)

			self.state = next_state
			self.score += reward

			final_state = next_state
			final_score = self.score
			reward = final_score - initial_score

			self.agent.observe_transition(initial_state, action, final_state, reward, self)
			
		return self.score

	def reset(self):
		# reset in solve itself, so not needed
		pass

	def decay_epsilon(self, epsilon_decay_rate):
		self.agent.epsilon = max(self.agent.epsilon - epsilon_decay_rate, 0)

	def get_actions(self, agent_index, state):
		actions = list(range(self.env.action_space.n))
		return actions

	def get_next_state(self, state, action):
		# got using env.step itself, so not needed
		pass

	def is_terminal(self, state):
		return self.score < -1000 or state[0] == np.digitize(0.6, self.pos_space)

def main():
	defined_agents = [className for className in utils.get_class_names(gameSettings.player_agents_file_name) if className == "EpsilonGreedyQAgent"]
	arg_parser = argparse.ArgumentParser(description='Apply your epsilon greedy agent over the MountainCar Environment (Discrete Action Continuous State space) from gymnasium.')

	# Define the expected command-line arguments
	arg_parser.add_argument('--agent', type=str, help='Specify the type of agent to use', default='EpsilonGreedyQAgent', choices=defined_agents)
	arg_parser.add_argument('--fixSeed', type=int, help='Fix a random seed')
	arg_parser.add_argument('--noGraphics', action='store_true', help='Disable the display')
	arg_parser.add_argument('--noTrainGraphics', action='store_true', help='Disable the display')
	arg_parser.add_argument('--noTestGraphics', action='store_true', help='Disable the display')
	arg_parser.add_argument('--discount', type=float, help='Specify the discount to use', default=0.9)
	arg_parser.add_argument('--epsilon', type=float, help='Specify the probability of exploration', default=1)
	arg_parser.add_argument('--alpha', type=float, help='Specify the learning rate of temporal difference agent', default=0.9)
	arg_parser.add_argument('--train', type = int, help='Number of games to train on', default = 0)
	arg_parser.add_argument('--test', type = int, help='Number of games to test on', default = 0)



	args = arg_parser.parse_args()
	agent = args.agent
	no_graphics = args.noGraphics
	no_train_graphics = args.noTrainGraphics
	no_test_graphics = args.noTestGraphics
	if no_graphics:
		no_train_graphics = True
		no_test_graphics = True
	discount = args.discount
	epsilon = args.epsilon
	alpha = args.alpha
	train = args.train
	test = args.test

	assert 0<=discount<=1
	assert 0<=alpha<=1
	assert 0<=epsilon<=1
	assert train >= 0
	assert test >= 0


	problem_args = {'agent': agent,
	    			'no_train_graphics': no_train_graphics,
	    			'no_test_graphics': no_test_graphics,
	    			'discount': discount,
	    			'alpha': alpha,
	    			'epsilon': epsilon
	    			}

	if args.fixSeed is not None:
		assert 0<=args.fixSeed<=2**32-1, "Seed value must be between 0 and 2**32-1"
		simpleRNG = np.random.default_rng(seed = args.fixSeed)
	else:
		simpleRNG = np.random.default_rng() # undetermined seed

	
	problem_args['fix_seed'] = simpleRNG.integers(0, 2**32)
	problem = MountainCarProblem(problem_args)

	if train == 0 and test == 0:
		# none specified
		test = 1    

	# decaying epsilon
	epsilon_decay_rate = 2/(train + 1)
	# at max 10 prints should come from training

	if train<=10:
		batch_size = 1
	else:
		num_batches = 10
		batch_size = np.ceil(train/num_batches)
	total_score_of_batch = 0
	last_train_index = -1

	for i in range(train):
		print_train = ((i+1)%batch_size == 0) or (i==train-1 and last_train_index!=i)
		try:
			score = problem.solve(train=True)
		except Exception as e:
			utils.print_exception(e)
			sys.exit(1)
		total_score_of_batch += score
		problem.decay_epsilon(epsilon_decay_rate)
		problem.reset()
		if print_train:
			print(f"Total for {i-last_train_index} episodes: {total_score_of_batch}\nAverage for {i-last_train_index} episodes: {total_score_of_batch/(i-last_train_index)}\n------------------")
			last_train_index = i
			total_score_of_batch = 0

	for i in range(test):
		score = problem.solve(train=False)
		print(f'{i}: Score: {score}')
		problem.reset()


if __name__ == "__main__":
	main()