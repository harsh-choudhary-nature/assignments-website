from Game import Game
import pygame
import Agents
import Player
import os
import argparse
import gameSettings
import Problems
import utils
import GameState
import graphicsUtils

def run_game_graphics(problem, agent, layout_filename, search_function, cost_function, heuristic_function, display):
	pygame.init()

	info = pygame.display.Info()
	# Get the screen width and height
	screen_width = info.current_w*3//4
	screen_height = info.current_h*3//4
	max_rows = screen_height//gameSettings.grid_size
	max_cols = screen_width//gameSettings.grid_size

	top_left = (screen_width//8, screen_height//8)

	# Create the Game object
	game = Game(layout_filename, screen_height, screen_width, problem, cost_function)
	# Game object has a GameState object

	agent_str = agent
	if agent == "SearchAgent":
		agent = Agents.SearchAgent(search_function,heuristic_function)
	elif agent == "KeyboardAgent":
		agent = Agents.KeyboardAgent()
	else:
		agent = Agents.RandomAgent()

	game.set_agent_str(agent_str)
	if display:
		# Player object has an Agent object
		player = Player.Player()
		player.set_agent(agent)
		# Game object has a Player Object
		game.set_player(player)
		# Set the desired position for the window (e.g., top-left corner at (0, 0))
		os.environ['SDL_VIDEO_WINDOW_POS'] = f'{top_left[0]},{top_left[1]}'
		pygame.display.set_caption(gameSettings.caption)
		window = pygame.display.set_mode((game.screen_width,game.screen_height))

		player.set_sprite_sheets(gameSettings.player_name)
		game.set_foods_sprite_sheet(gameSettings.food_file_name, 32, 32)

		run = True
		clock = pygame.time.Clock()
		game.draw(window)
		pygame.display.update()
		while run:
			clock.tick(gameSettings.FPS)
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					run = False
					break

			game.handle_action_locking()	# the game checks if animation from last action is pending, if yes then continues that animation
			done = game.draw(window)


			pygame.display.update()
			if done:
				run = False
				print(f"You won!\nScore: {game.game_state.score}")
				break

		pygame.quit()
		if agent_str == "SearchAgent":
			return agent.plan
		elif agent_str == "RandomAgent":
			return player.executed_plan
		return None
	else:
		game_state = GameState.GameState(graphicsUtils.parse(layout_filename),cost_function)
		problem.set_game_state(game_state)
		state = problem.get_state()
		while not problem.is_goal_state(state):
			action = agent.act(problem)
			next_state = problem.get_next_state(state, action)
			cost = game_state.get_cost_of_action(state, action, next_state)
			game_state.update_game_state((next_state, action, cost))
			state = next_state
		print(f"You won!\nScore: {game_state.score}")
		if agent_str == "SearchAgent":
			return agent.plan
		return None

def main():
	defined_cost_functions = utils.get_function_names("costFunctions.py")
	defined_layouts = utils.get_files_in_dir("layouts")
	defined_heuristics = utils.get_function_names("heuristicFunctions.py")
	defined_agents = utils.get_class_names("Agents.py")
	defined_search_functions = utils.get_function_names("searchFunctions.py")
	arg_parser = argparse.ArgumentParser(description='Play the game of Platformers. Run "python3 platformers.py -h" to view the list of argument options available')

	# Define the expected command-line arguments
	arg_parser.add_argument('--layout', type=str, help='Specify the layout(.lay file) of the game.', default='single_achiever.lay', choices = defined_layouts)
	arg_parser.add_argument('--agent', type=str, help='Specify the type of agent to use', default='KeyboardAgent', choices=defined_agents)
	arg_parser.add_argument('--searchFn', type=str, help='Specify the search function to be used by the agent', default='dfs', choices=defined_search_functions)
	arg_parser.add_argument('--costFn', type=str, help='Specify the cost function in case you use "ucs" or "astar" for the search function', default='distance_based_cost', choices = defined_cost_functions)
	arg_parser.add_argument('--heuristicFn', type=str, help='Specify the heuristic function in case you use "astar" for the search function', default='null_heuristic', choices = defined_heuristics)
	arg_parser.add_argument('--no-graphics', action='store_true', help='Disable graphics display')
	# Parse the command-line arguments
	args = arg_parser.parse_args()

	# Access the values
	layout_filename = args.layout
	agent = args.agent
	search_function = args.searchFn
	cost_function = args.costFn
	heuristic_function = args.heuristicFn
	display = not args.no_graphics

	problem = Problems.PlatformersSearchProblem()
	assert display or agent != "KeyboardAgent", "KeyboardAgent can't be run without graphics"
	try:
		run_game_graphics(problem, agent, layout_filename, search_function, cost_function, heuristic_function, display)
	except Exception as e:
		utils.print_exception(e)
		return 0

if __name__ == "__main__":
	main()