import gameSettings


def action_based_cost(state, action, next_state):
	if action == "noop":
		cost = 10**(1)
	elif action == "left" or action == "right" or action == "jump":
		cost = 10**(2)
	elif action == "short_jump_left" or action == "short_jump_right":
		cost = 10**(3)
	else:
		cost = 10**(4)
	return cost

def distance_based_cost(state, action, next_state):
	cur_pos = state[0]
	next_pos = next_state[0]
	dist = 0
	if action == "jump":
		assert cur_pos == next_pos
		dist = 2
	elif action == "left" or action == "right":
		dist = 1
		# account for falling
		dist += next_pos[0]-cur_pos[0]
	elif action == "short_jump_left" or action == "short_jump_right":
		dist = 2
		# account for falling
		dist += next_pos[0]-cur_pos[0] + 1
	elif action == "long_jump_left" or action == "long_jump_right":
		dist = 3
		dist += next_pos[0]-cur_pos[0] + 1
	else:
		# action == "noop"
		dist = 1
	return gameSettings.cost_per_move*dist