import searchFunctions
import numpy as np
import utils

class KeyboardAgent:
	def __init__(self):
		self.buffer = ["noop"]

	@utils.timeout(1)
	def act(self, problem):
		state = problem.get_state()
		actions = problem.get_actions(state)
		action = "noop"
		if self.buffer[0] == "left" and "left" in actions:
			action = "left"
		elif self.buffer[0] == "right" and "right" in actions:
			action = "right"
		elif self.buffer[0] == "jump" and "jump" in actions:
			action = "jump"
		elif self.buffer[0] == "long_jump_left" and "long_jump_left" in actions:
			action = "long_jump_left"
		elif self.buffer[0] == "short_jump_left" and "short_jump_left" in actions:
			action = "short_jump_left"
		elif self.buffer[0] == "short_jump_right" and "short_jump_right" in actions:
			action = "short_jump_right"
		elif self.buffer[0] == "long_jump_right" and "long_jump_right" in actions:
			action = "long_jump_right"
		return action

class SearchAgent:
	def __init__(self, search_fn_str, heuristic_fn_str):
		self.search_fn_str = search_fn_str
		self.heuristic_fn_str = heuristic_fn_str
		self.plan = None
		self.plan_index = None
		
	@utils.timeout(4)
	def compute_plan(self, problem):
		import time
		search_fn = getattr(searchFunctions,self.search_fn_str)
		start = time.time()
		if self.search_fn_str == "astar":
			plan = search_fn(problem, self.heuristic_fn_str)
		else:
			plan = search_fn(problem)
		end = time.time()
		time_taken = end-start
		print("Time taken:", time_taken)
		print(f"Expanded states: {len(problem.expanded_states)}")
		return plan

	@utils.timeout(4)
	def act(self, problem):
		if self.plan == None:
			self.plan = self.compute_plan(problem)
			self.plan_index = 0
		action = self.plan[self.plan_index]
		self.plan_index += 1
		return action 

class RandomAgent:
	def __init__(self):
		pass

	'''
	Q1. Warm up problem. Make sure you understand the states and actions well.
	'''
	@utils.timeout(1)
	def act(self, problem):
		'''
		problem is an instance of the Search Problem you are trying to solve. All the helper functions that you will be using are deined in this class. You may wish to refer Problems.py, but it is not mandatory.

		state is a 2 element tuple capturing the dynamic aspects of game state. Here state[0] corresponds to the current player position (also a tuple) and state[1] corresponds to the tuple of uneaten food positions (tuple of 2 element tuples).

		actions is a list of actions that the player can perform given its current position (hence, state is passed as argument to get_actions). For ex: action long_jump_right will be in actions only if positions (px-1,py), (px-1, py-1) and (px-1, py-2) are free, where (px, py) is the current player position.
		'''
		state = problem.get_state()
		actions = problem.get_actions(state)
		
		# Write your code here
		# eg.: to return the first element of actions, you may write
		# return actions[0] 
		# Here you have to return action at a particular list index


		raise utils.MethodNotImplementedError('act')
