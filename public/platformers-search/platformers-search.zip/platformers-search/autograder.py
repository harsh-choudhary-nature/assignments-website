import utils
import argparse
import os, sys
import re
import Problems
import searchFunctions
import platformers
import Player
import Agents
import GameState
import graphicsUtils

def random_agent_test(question_data, display, scheme):
	defined_layouts = utils.get_files_in_dir("layouts")
	assert "layoutName" in question_data and question_data['layoutName'] in defined_layouts
	defined_cost_functions = utils.get_function_names("costFunctions.py")
	if "costFn" not in question_data:
		question_data['costFn'] = "distance_based_cost"
	else:
		assert question_data['costFn'] in defined_cost_functions
	question_data['heuristicFn'] = "null_heuristic"
	problem = Problems.PlatformersSearchProblem()
	assert scheme == "strict"
	ans_plans = []
	for i in range(int(question_data["numTests"])):
		if display:
			player = Player.Player()
			try:
				plan = platformers.run_game_graphics(problem,"RandomAgent",question_data['layoutName'],None,question_data['costFn'],question_data['heuristicFn'], display)
			except Exception as e:
				utils.print_exception(e)
				return 0
		else:
			agent = Agents.RandomAgent()
			game_state = GameState.GameState(graphicsUtils.parse(question_data['layoutName']),question_data['costFn'])
			problem.set_game_state(game_state)
			plan = []
			state = problem.get_state()
			while not problem.is_goal_state(state):
				try:
					action = agent.act(problem)
					plan.append(action)
				except Exception as e:
					utils.print_exception(e)
					return 0
				next_state = problem.get_next_state(state, action)
				cost = game_state.get_cost_of_action(state, action, next_state)
				game_state.update_game_state((next_state, action, cost))
				state = next_state

		ans_plans.append(plan)
	correct_pts = int(not all(lst == ans_plans[0] for lst in ans_plans))
	return correct_pts

def parse_test_file(file_path):
	with open(file_path, 'r') as file:
		content = file.read()

	# Remove comments
	content = re.sub(r'#.*', '', content)

	# Extract key-value pairs enclosed in triple or double quotes
	matches = re.findall(r'(\w+):\s*("""(?:.|\n)*?"""|".*?")', content)
	# Process the matches into a dictionary
	parsed_data = {}
	for key, value in matches:
		# Strip the quotes from the value
		value = value.strip('"')
		parsed_data[key] = value
	return parsed_data

def parse_graph(graph_str):
	lines = graph_str.split("\n")
	start_state = None
	goal_states = list()
	vertices = set()
	edges = list()
	for line in lines:
		stripped_line = line.strip()
		if len(stripped_line)>0:
			if "start_state" in stripped_line:
				start_state = stripped_line[len("start_state: "):]
				vertices.add(start_state)
			elif "goal_states" in stripped_line:
				goals = stripped_line[len("goal_states: "):].split(" ")
				for goal in goals:
					goal_states.append(goal.strip())
					vertices.add(goal_states[-1])
			else:
				# add state transitions
				start, action, end, cost = stripped_line.split(" ")
				start = start.strip()
				end = end.strip()
				action = action.strip()
				cost = float(cost.strip())
				vertices.add(start)
				vertices.add(end)
				edges.append((start, end, cost))
	return vertices, start_state, goal_states, edges

def parse_heuristic(heuristic_str):
	cache = dict()
	lines = heuristic_str.split("\n")
	for line in lines:
		stripped_line = line.strip()
		if len(stripped_line)>0:
			state, heuristic_val = stripped_line.split()
			state = state.strip()
			heuristic_val = float(heuristic_val.strip())
			cache[state] = heuristic_val
	return cache

def parse_limits_data(limits_str):
	cache = dict()
	lower_bounds = list()
	lines = limits_str.split("\n")
	for line in lines:
		stripped_line = line.strip()
		if len(stripped_line)>0:
			lower_bound, grade = stripped_line.split()
			lower_bound = int(lower_bound.strip())
			grade = int(grade.strip())
			cache[lower_bound] = grade
			lower_bounds.append(lower_bound)
	return cache, lower_bounds

class PlatformersSearchProblemTester:
	def __init__(self, question_data, solution_data):
		self.question_data = question_data
		self.solution_data = solution_data

	def test(self, scheme, display):
		problem = Problems.PlatformersSearchProblem()
		if display:
			player = Player.Player()
			try:
				plan = platformers.run_game_graphics(problem,"SearchAgent",self.question_data['layoutName'],self.question_data['searchFn'],self.question_data['costFn'],self.question_data['heuristicFn'], display)
			except Exception as e:
				utils.print_exception(e)
				return 0
		else:
			agent = Agents.SearchAgent(self.question_data['searchFn'],self.question_data['heuristicFn'])
			game_state = GameState.GameState(graphicsUtils.parse(self.question_data['layoutName']),self.question_data['costFn'])
			problem.set_game_state(game_state)
			try:
				plan = agent.compute_plan(problem)
			except Exception as e:
				utils.print_exception(e)
				return 0
		expanded_states_count = len(problem.expanded_states)
		correct_plan = [data.strip() for data in self.solution_data["solution"].split()]
		if scheme == "strict":
			correct_expanded_states_count = int(self.solution_data['expanded_states_count'].strip())
			if self.question_data['searchFn'] == "astar":
				correct_expanded_states_count_limit = int(self.solution_data['expanded_states_count_limit'].strip())
				if correct_plan != plan or expanded_states_count > correct_expanded_states_count_limit:
					print(f"Student's plan: {plan}\nCorrect plan: {correct_plan}\nStudent's expanded states count: {expanded_states_count}\nCorrect expanded states count: {correct_expanded_states_count}\nCorrect expanded states count limit: {correct_expanded_states_count_limit}\n")
					return 0
			else:
				if correct_plan != plan or correct_expanded_states_count != expanded_states_count:
					print(f"Student's plan: {plan}\nCorrect plan: {correct_plan}\nStudent's expanded states count: {expanded_states_count}\nCorrect expanded states count: {correct_expanded_states_count}")
					return 0
			return 1
		else:
			assert self.question_data['searchFn'] == "astar"
			expanded_states_count_limits, lower_bounds = parse_limits_data(self.solution_data["expanded_states_count_limits"])
			correct_plan_cost = problem.get_cost_of_plan(correct_plan)
			student_plan_cost = problem.get_cost_of_plan(plan)
			if correct_plan_cost != student_plan_cost:
				print(f"Student's plan: {plan}\nCorrect plan: {correct_plan}\nStudent's expanded states count: {expanded_states_count}\nStudent's plan length: {len(plan)}\nCorrect plan length: {len(correct_plan)}\nStudent's plan cost: {student_plan_cost}\nCorrect plan cost: {correct_plan_cost}\nThe heuristic is inconsistent!")
				print("-------------------------------------------------------------------")
				return 0
			for lower_bound in lower_bounds:
				if expanded_states_count > lower_bound:
					print(f"Student's expanded states count: {expanded_states_count}")
					print(f"Grading Scheme:-\n{self.solution_data['grading_scheme_description']}")
					return expanded_states_count_limits[lower_bound]
			assert False 	# must not reach here, invalid test grading scheme

	def validate_solution(self, scheme):
		assert "expanded_states_count" in self.solution_data
		if self.question_data['searchFn'] == "astar":
			if scheme == "strict":
				assert "expanded_states_count_limit" in self.solution_data
			else:
				assert "expanded_states_count_limits" in self.solution_data

	def validate_question(self, scheme):
		defined_layouts = utils.get_files_in_dir("layouts")
		defined_cost_functions = utils.get_function_names("costFunctions.py")
		defined_heuristics = utils.get_function_names("heuristicFunctions.py")
		assert "layoutName" in self.question_data and self.question_data['layoutName'] in defined_layouts

		if "costFn" not in self.question_data:
			self.question_data['costFn'] = "distance_based_cost"
		else:
			assert self.question_data['costFn'] in defined_cost_functions
		if "heuristicFn" not in self.question_data:
			self.question_data['heuristicFn'] = "null_heuristic"
		else:
			assert self.question_data['heuristicFn'] in defined_heuristics

	def print_solution(self, scheme, solution_file_path):
		if self.question_data['searchFn'] != "astar":
			problem = Problems.PlatformersSearchProblem()
			agent = Agents.SearchAgent(self.question_data['searchFn'],self.question_data['heuristicFn'])
			game_state = GameState.GameState(graphicsUtils.parse(self.question_data['layoutName']),self.question_data['costFn'])
			problem.set_game_state(game_state)
			try:
				plan = agent.compute_plan(problem)
			except Exception as e:
				utils.print_exception(e)
				sys.exit(1)
			expanded_states_count = len(problem.expanded_states)
			# manually write for astar as needs limits as well
			fh = open(solution_file_path, "w")
			fh.write(f"solution: \"\"\"\n{' '.join(plan)}\n\"\"\"\nexpanded_states_count: \"{expanded_states_count}\"")
			fh.close()

class GraphSearchProblemTester:
	def __init__(self, question_data, solution_data):
		self.question_data = question_data
		self.solution_data = solution_data

	@utils.timeout(4)
	def get_plan_and_expanded_states(self):
		vertices, start_state, goal_states, edges = parse_graph(self.question_data["graph"])
		problem = Problems.GraphSearchProblem()
		problem.set_graph(vertices, edges, start_state, goal_states)
		search_fn = getattr(searchFunctions, self.question_data["searchFn"])
		
		if self.question_data["searchFn"] == "astar":
			if "heuristic" in self.question_data:
				heuristic_dict = parse_heuristic(self.question_data["heuristic"])
				assert len(heuristic_dict)==len(vertices)
			else:
				heuristic_dict = dict()
			problem.set_heuristic_dict(heuristic_dict)
			plan = search_fn(problem, "graph_heuristics")
		else:
			plan = search_fn(problem)
		
		expanded_states = problem.expanded_states
		return plan, expanded_states

	def test(self):
		try:
			plan, expanded_states = self.get_plan_and_expanded_states()
		except Exception as e:
			utils.print_exception(e)
			return 0
		correct_plan = [data.strip() for data in self.solution_data["solution"].split()]
		correct_expanded_states = [data.strip() for data in self.solution_data["expanded_states"].split()]
		if correct_plan != plan or correct_expanded_states != expanded_states:
			print(f"{self.question_data['diagram']}\n{self.question_data['description']}")
			print(f"Student's plan: {plan}\nCorrect plan: {correct_plan}\nStudent's expanded states: {expanded_states}\nCorrect expanded states: {correct_expanded_states}")
			return 0
		return 1

	def validate_solution(self):
		assert 'expanded_states' in self.solution_data

	def validate_question(self):
		pass

	def print_solution(self, solution_file_path):
		try:
			plan, expanded_states = self.get_plan_and_expanded_states()
		except Exception as e:
			utils.print_exception(e)
			sys.exit(1)
		fh = open(solution_file_path, "w")
		fh.write(f"solution: \"{' '.join(plan)}\"\nexpanded_states: \"{' '.join(expanded_states)}\"")
		fh.close()

def run_one_test(test_dir, test_file_name, valid_problems, valid_searchFns, display, scheme, write_solution = False):
	# returns 1 if this testcase file is passed, else 0
	script_dir = os.path.dirname(os.path.abspath(__file__))
	path = os.path.join(script_dir,"test_cases",test_dir,test_file_name)

	test_case_name = test_file_name.split(".")[0]
	solution_file_path = os.path.join(script_dir,"test_cases",test_dir,test_case_name+".solution")
	question_data = parse_test_file(path)
	solution_data = parse_test_file(solution_file_path)

	assert "problem" in question_data, "The test file has no problem specified"
	result = 0
	if "agent" in question_data and question_data["agent"] == "RandomAgent":
		if not write_solution:
			result = random_agent_test(question_data, display, scheme)
			if result == 1:
				print(f"{test_file_name} passed!")
			else:
				print(f"*** Test failed {test_file_name}")
	else:		
		assert "searchFn" in question_data and question_data["problem"] in valid_problems and question_data["searchFn"] in valid_searchFns and "solution" in solution_data
		
		print(f"Running test case {path}")
		
		if scheme == "strict":
			if question_data["problem"]=="PlatformersSearchProblem":
				tester = PlatformersSearchProblemTester(question_data, solution_data)
				tester.validate_question(scheme)
				if not write_solution:
					tester.validate_solution(scheme)
					result = tester.test(scheme, display)
					if result == 1:
						print(f"{test_file_name} passed!")
					else:
						print(f"*** Test failed {test_file_name}")
				else:
					tester.print_solution(scheme, solution_file_path)
			elif question_data["problem"]=="GraphSearchProblem":
				tester = GraphSearchProblemTester(question_data, solution_data)
				tester.validate_question()
				if not write_solution:
					tester.validate_solution()
					result = tester.test()
					if result == 1:
						print(f"{test_file_name} passed!")
					else:
						print(f"*** Test failed {test_file_name}")
				else:
					tester.print_solution(solution_file_path)
			else:
				assert False
		else:
			if question_data["problem"]=="PlatformersSearchProblem":
				tester = PlatformersSearchProblemTester(question_data, solution_data)
				if not write_solution:
					tester.validate_question(scheme)
					tester.validate_solution(scheme)
					result = tester.test(scheme, display)
					if result == 0:
						print(f"*** Test failed {test_file_name}")
			else:
				assert False
	print("-------------------------------------------------------------------")
	return result
		

def run_one_test_directory(test_dir, valid_problems, valid_searchFns, display, write_solution=False)->tuple:
	# path is test_cases/test_dir
	print(f"Testing {test_dir}.........")
	script_dir = os.path.dirname(os.path.abspath(__file__))
	path = os.path.join(script_dir,"test_cases",test_dir)

	# get the config details
	config_file_path = os.path.join(path, "config")
	config_file_data = parse_test_file(config_file_path)

	assert "totalPts" in config_file_data and "scheme" in config_file_data
	total_points = int(config_file_data['totalPts'])
	if config_file_data['scheme'] == "strict":
		num_tests = 0
		num_tests_passed = 0
		for file in os.listdir(path):
			if file.endswith(".test"):
				num_tests += 1
				correct_pts = run_one_test(test_dir, file, valid_problems, valid_searchFns, display, "strict", write_solution)
				if 1 == correct_pts:
					num_tests_passed += 1
		if num_tests_passed < num_tests:
			correct_points = 0
		else:
			correct_points = total_points
	else:
		# currently we expect that for partial marking solutions we have only one test file, so put break statement
		num_tests = 0
		for file in os.listdir(path):
			if file.endswith(".test"):
				assert num_tests == 0
				num_tests += 1
				correct_pts = run_one_test(test_dir, file, valid_problems, valid_searchFns, display, "partial", write_solution)
				correct_points = correct_pts
				break
	if not write_solution:
		print(f"Verdict: {test_dir} {'failed' if correct_points<total_points else 'passed'}\nPoints: {correct_points}/{total_points}")
	print("====================================================================")
	print()

	return total_points, correct_points



defined_tests = utils.get_dirs_in_dir("test_cases")
total_tests = len(defined_tests)

arg_parser = argparse.ArgumentParser(description='Run the test cases for your implementation. Run "python3 autograder.py -h" to view the list of argument options available')

# Define the expected command-line arguments
arg_parser.add_argument('-q', type=str, help='Specify the name of specific tests folder in test_cases', choices = defined_tests, nargs = '+')
arg_parser.add_argument('--test', type=str, help='Specify the name of specific tests folder followed by slash(/) followed by test case file name (Overrules -q argument)')
arg_parser.add_argument('--no-graphics', action='store_true', help='Disable graphics display')

# Parse the command-line arguments
valid_problems = utils.get_class_names("Problems.py")
valid_searchFns = utils.get_function_names("searchFunctions.py")
args = arg_parser.parse_args()
print("Autograding in progress......\n")
display = not args.no_graphics
onetest = args.test

# Make this True when .solution files do not exist
write_solution = False 
if not onetest:
	tests = args.q

	if tests is None:
		# run all the tests
		tests = defined_tests

	val = 0
	total = 0
	for test in tests:
		dir_tot, dir_val = run_one_test_directory(test, valid_problems, valid_searchFns, display, write_solution=write_solution)
		total += dir_tot
		val += dir_val

	if not write_solution:
		if total > val:
			print(f"*** Some tests failed. Retry!")

		if total_tests == len(tests):
			print(f"Total points: {total}\nScored points: {val}\nScore: {val}/{total}")
else:
	try:
		folder, filename = onetest.split('/')
		folder = folder.strip()
		filename = filename.strip()
		script_dir = os.path.dirname(os.path.abspath(__file__))
		path = os.path.join(script_dir,"test_cases",folder, filename)

		# get the config details
		config_file_path = os.path.join(script_dir,"test_cases",folder, "config")
		config_file_data = parse_test_file(config_file_path)
		assert "totalPts" in config_file_data
		total_points = float(config_file_data['totalPts'])
		correct_pts = run_one_test(folder, filename, valid_problems, valid_searchFns, display, config_file_data['scheme'], write_solution=write_solution)
		assert correct_pts <= total_points
		print("====================================================================\n")
	except FileNotFoundError:
		print(f'Invalid test case!')
		sys.exit(1)
	except ValueError as e:
		print(f'{e}')
		sys.exit(1)
