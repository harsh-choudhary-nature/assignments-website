import costFunctions

class GameState:

	def __init__(self, layout, cost_fn_str):
		# layout: list of lists representing the walls

		self.layout = layout
		self.blocks_pos = list()
		self.foods_pos = list()
		self.ghosts_pos = list()
		self.player_pos = None
		self.num_rows = len(self.layout)
		assert self.num_rows>1
		self.num_cols = len(self.layout[0])
		for i in range(self.num_rows):
			for j in range(self.num_cols):
				if self.layout[i][j] == 'B':
					self.blocks_pos.append((i,j))
				elif self.layout[i][j] == 'D':
					self.foods_pos.append((i,j))
				elif self.layout[i][j] == 'P':
					self.player_pos = (i,j)
		assert self.player_pos != None
		self.facing = "left"
		self.possible_actions = ["left","right","jump","noop","long_jump_left","long_jump_right","short_jump_left","short_jump_right"]
		self.score = 100
		self.cost_fn_str = cost_fn_str
		self.total_foods = len(self.foods_pos)
		self.start_state = (self.player_pos, tuple(self.foods_pos))
		
	def update_game_state(self, successor):
		next_state, action, cost = successor
		self.score -= cost
		player_pos, foods_pos = next_state
		self.player_pos = player_pos
		self.foods_pos = list(foods_pos)
		
		if action == "left" or action == "short_jump_left" or action == "long_jump_left":
			self.facing = "left"
		elif action == "right" or action == "short_jump_right" or action == "long_jump_right":
			self.facing = "right"
	
	def is_goal_state(self):
		return len(self.foods_pos) == 0

	def get_cost_of_action(self, state, action, next_state):
		return getattr(costFunctions, self.cost_fn_str)(state, action, next_state)

	def get_num_rows(self):
		return self.num_rows

	def get_num_cols(self):
		return self.num_cols

	def get_foods_pos(self):
		return self.foods_pos

	def get_player_pos(self):
		return self.player_pos