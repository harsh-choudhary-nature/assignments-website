import pygame
from GameState import GameState
import graphicsUtils
import gameSettings

class Game:
	def __init__(self, layout_filename, screen_height, screen_width, problem, cost_fn_str):
		self.layout = graphicsUtils.parse(layout_filename)
		self.game_state = GameState(self.layout, cost_fn_str)
		self.problem = problem

		self.problem.set_game_state(self.game_state)
		self.screen_height = min(gameSettings.grid_size * self.game_state.num_rows, screen_height)
		self.screen_width = min(gameSettings.grid_size * self.game_state.num_cols, screen_width)
		self.background_image = graphicsUtils.get_image(gameSettings.bg_tile_name, "Background")
		self.block_image = graphicsUtils.get_image(gameSettings.block_file_name, "Terrain")
		self.index_update_cnt = 4
		self.index_cur_count = 0
		self.font = pygame.font.Font(None, 24)

	def set_player(self, player):
		self.player = player
		self.init_offset()

	def set_agent_str(self, agent_str):
		self.agent_str = agent_str

	def init_offset(self):
		if self.game_state.num_rows*gameSettings.grid_size<=self.screen_height and self.game_state.num_cols*gameSettings.grid_size<=self.screen_width:
			self.offset_x = 0
			self.offset_y = 0
		else:
			player_pos = self.game_state.player_pos
			player_x = player_pos[1]*gameSettings.grid_size + self.player.dx
			player_y = player_pos[0]*gameSettings.grid_size + self.player.dy
			# player_x and player_y are the top left coordinates
			# initially it can only be greater than the limits
			if player_x + gameSettings.grid_size >self.screen_width - gameSettings.grid_size:
				self.offset_x = player_x + gameSettings.grid_size - self.screen_width + (gameSettings.grid_size if player_pos[1]<self.game_state.num_cols-1 else 0)
			else:
				self.offset_x = 0
			if player_y + gameSettings.grid_size > self.screen_height - gameSettings.grid_size:
				self.offset_y = player_y + gameSettings.grid_size - self.screen_height + (gameSettings.grid_size if player_pos[0]<self.game_state.num_rows-1 else 0)
			else:
				self.offset_y = 0

	def adjust_offset(self, top_left_player):
		player_pixel_x, player_pixel_y = top_left_player
		player_pos = self.game_state.player_pos
		if player_pixel_x <2*gameSettings.grid_size:
			if self.offset_x > 0:
				self.offset_x += player_pixel_x - 2*gameSettings.grid_size
		elif player_pixel_x + gameSettings.grid_size > self.screen_width - 2*gameSettings.grid_size:
			if self.offset_x < (gameSettings.grid_size*self.game_state.num_cols - self.screen_width):	# max offset possible
				self.offset_x += player_pixel_x + gameSettings.grid_size - self.screen_width + 2*gameSettings.grid_size

		if player_pixel_y <2*gameSettings.grid_size:
			if self.offset_y > 0:
				self.offset_y += player_pixel_y - 2*gameSettings.grid_size

		elif player_pixel_y + gameSettings.grid_size > self.screen_height - 2*gameSettings.grid_size:
			if self.offset_y < (gameSettings.grid_size*self.game_state.num_rows - self.screen_height):	# max offset possible
				self.offset_y += player_pixel_y + gameSettings.grid_size - self.screen_height + 2*gameSettings.grid_size

	def set_foods_sprite_sheet(self, food_filename, width, height):
		self.food_image_sheet = graphicsUtils.get_food_image(food_filename, "Items","Fruits", width, height)
		self.food_image_sheet_index = 0
		self.foods_sprite_sheet_offsets = [i%len(self.food_image_sheet) for i in range(len(self.game_state.foods_pos))]

	def draw_background(self, window):
		for i in range(0, self.game_state.num_cols):
			for j in range(0, self.game_state.num_rows):
				x = i*gameSettings.grid_size
				y = j*gameSettings.grid_size
				window.blit(self.background_image,(x-self.offset_x,y-self.offset_y))

	def draw_blocks(self, window):
		for block in self.game_state.blocks_pos:
			x = block[1]*gameSettings.grid_size
			y = block[0]*gameSettings.grid_size
			window.blit(self.block_image,(x-self.offset_x,y-self.offset_y))

	def draw_foods(self, window):
		for i, food in enumerate(self.game_state.foods_pos):
			if food in self.player.eaten_foods_during_animation:
				continue
			x = food[1]*gameSettings.grid_size
			y = food[0]*gameSettings.grid_size
			window.blit(self.food_image_sheet[(self.food_image_sheet_index+self.foods_sprite_sheet_offsets[i])%len(self.food_image_sheet)],(x-self.offset_x,y-self.offset_y))
		self.index_cur_count += 1
		if self.index_cur_count == self.index_update_cnt:
			self.food_image_sheet_index = (self.food_image_sheet_index + 1)%len(self.food_image_sheet)
			self.index_cur_count = 0

	def draw_score(self, window):
		text = self.font.render(f'Score: {self.game_state.score}', True, (0, 0, 0))
		text_rect = text.get_rect()
		text_rect.topleft = (10, 10)
		window.blit(text, text_rect)


	def handle_action_locking(self):
		if self.agent_str == "KeyboardAgent":
			keys = pygame.key.get_pressed()
			possibles = {pygame.K_LEFT: "left", pygame.K_RIGHT: "right", pygame.K_SPACE: "jump", pygame.K_a: "long_jump_left", pygame.K_s: "short_jump_left", pygame.K_d: "short_jump_right", pygame.K_f: "long_jump_right"}
			for key in possibles:
				if keys[key]:
					self.player.agent.buffer[0] = possibles[key]
					break
			else:
				self.player.agent.buffer[0] = "noop"
		if self.player.locked == True:
			# continue the last action
			self.player.continue_last(self.problem)
		else:
			self.player.act(self.problem)

	def draw(self, window):
		self.draw_background(window)
		self.draw_blocks(window)
		self.draw_foods(window)
		top_left_player = self.player.draw_player(self.game_state.player_pos, self.game_state, window, self.offset_x, self.offset_y)
		self.draw_score(window)
		self.adjust_offset(top_left_player)
		if self.game_state.is_goal_state():
			return True

		return False
