import heapq
import os
import ast 
import traceback
import signal, time

class Stack:
    def __init__(self):
        self.list = []

    def push(self,item):
        self.list.append(item)

    def pop(self):
        return self.list.pop()

    def isEmpty(self):
        return len(self.list) == 0

class Queue:
    def __init__(self):
        self.list = []

    def push(self,item):
        self.list.insert(0,item)

    def pop(self):
        return self.list.pop()

    def isEmpty(self):
        return len(self.list) == 0

class PriorityQueue:
    def  __init__(self):
        self.heap = []
        self.count = 0

    def push(self, item, priority):
        entry = (priority, self.count, item)
        heapq.heappush(self.heap, entry)
        self.count += 1

    def pop(self):
        (_, _, item) = heapq.heappop(self.heap)
        return item

    def isEmpty(self):
        return len(self.heap) == 0

    def update(self, item, priority):
        for index, (p, c, i) in enumerate(self.heap):
            if i == item:
                if p <= priority:
                    break
                del self.heap[index]
                self.heap.append((priority, c, item))
                heapq.heapify(self.heap)
                break
        else:
            self.push(item, priority)


class MethodNotImplementedError(NotImplementedError):
    def __init__(self, method_name):
        stack = traceback.extract_stack()[-2]  # Get the second-last call in the stack
        file_name = stack.filename
        line_number = stack.lineno

        # Construct the error message
        error_message = (f"The method '{method_name}' is not implemented.\n"
                         f"File: {file_name}, Line: {line_number}")
        
        super().__init__(error_message)


def get_function_names(file_name):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(script_dir, file_name)
    with open(path, "r") as file:
        tree = ast.parse(file.read(), filename=path)

    function_names = [node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)]

    return function_names

def get_files_in_dir(dir):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(script_dir,dir)
    return [file for file in os.listdir(path) if os.path.isfile(os.path.join(path, file))]

def get_dirs_in_dir(dir):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(script_dir,dir)
    entries = os.listdir(path)
        
    # Filter out and list only directories
    directories = [entry for entry in entries if os.path.isdir(os.path.join(path, entry))]
    return directories

def get_class_names(file_name):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(script_dir, file_name)
    with open(path, "r") as file:
        file_content = file.read()

    # Parse the file content into an AST
    parsed_ast = ast.parse(file_content)

    # Extract all class definitions
    class_names = [node.name for node in ast.walk(parsed_ast) if isinstance(node, ast.ClassDef)]
    
    return class_names

def manhattan_distance( xy1, xy2 ):
    "Returns the Manhattan distance between points xy1 and xy2"
    return abs( xy1[0] - xy2[0] ) + abs( xy1[1] - xy2[1] )


class TimeoutException(Exception):
    pass

def timeout(seconds):
    assert seconds > 0
    def decorator(func):
        def _handle_timeout(signum, frame):
            raise TimeoutException(f"Function '{func.__name__}' timed out after {seconds} seconds")

        def wrapper(*args, **kwargs):
            if hasattr(signal, 'SIGALRM'):
                # works on linux
                # Set up signal handler for the timeout
                signal.signal(signal.SIGALRM, _handle_timeout)
                # Schedule an alarm
                signal.alarm(seconds)
                try:
                    result = func(*args, **kwargs)
                finally:
                    # Disable the alarm
                    signal.alarm(0)
                return result
            else:
                # for windows
                start = time.time()
                result = func(*args, **kwargs)
                time_taken = time.time() - start
                if time_taken > seconds:
                    _handle_timeout(None, None)
                return result
            
        return wrapper
    return decorator

def print_exception(exception):
    if isinstance(exception, TimeoutException) or isinstance(exception, MethodNotImplementedError):
        for line in exception.__str__().splitlines():
            print(f"*** {line}")
    else:
        full_traceback = traceback.format_exc()					
        for line in full_traceback.splitlines():
            print(f"*** {line}")