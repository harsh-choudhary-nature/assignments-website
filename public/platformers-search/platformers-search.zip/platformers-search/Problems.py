import utils

class PlatformersSearchProblem:
	def __init__(self):
		self.game_state = None
		self.expanded_states = list()
		self.check_empty_positions = {	"noop": 			[],
										"jump":				[(-1,0)],
										"right":			[(0,1)],
										"left":				[(0,-1)],
										"short_jump_right":	[(-1,0), (-1,1)],
										"short_jump_left":	[(-1,0), (-1,-1)],
										"long_jump_right":	[(-1,0), (-1,1), (-1,2)],
										"long_jump_left":	[(-1,0), (-1,-1), (-1,-2)]
										}

	def is_valid(self, pos):
		x, y = pos
		return x>=0 and x<self.game_state.num_rows and y>=0 and y<self.game_state.num_cols

	def set_game_state(self, game_state):
		self.game_state = game_state
		self.initial_player_pos = game_state.get_player_pos()

	def get_start_state(self):
		return self.game_state.start_state

	def get_state(self):
		return (self.game_state.player_pos,tuple(self.game_state.foods_pos))

	def is_goal_state(self, state):
		return len(state[1])==0

	def get_successors(self, state):
		self.expanded_states.append(state)
		successors = list()
		for action in self.get_actions(state):
			next_state = self.get_next_state(state, action)
			cost = self.game_state.get_cost_of_action(state, action, next_state)
			successors.append((next_state,action,cost))
		return successors

	def get_actions(self, state):
		player_pos = state[0]
		assert self.is_valid(player_pos)

		actions = []

		for action in self.check_empty_positions:
			for neigh_pos in self.check_empty_positions[action]:
				next_pos = (player_pos[0]+neigh_pos[0], player_pos[1]+neigh_pos[1])
				if not self.is_valid(next_pos) or next_pos in self.game_state.blocks_pos:
					break
			else:
				actions.append(action)
		return actions		

	def get_next_state(self, state, action):
		assert action in self.get_actions(state)
		player_pos, foods_pos = state
		foods_pos = list(foods_pos)
		traced_path = [player_pos] + [(player_pos[0]+neigh_pos[0], player_pos[1]+neigh_pos[1]) for neigh_pos in self.check_empty_positions[action]]
		next_pos = traced_path[-1]
		while next_pos[0]+1<self.game_state.num_rows and (next_pos[0]+1,next_pos[1]) not in self.game_state.blocks_pos:
			next_pos = (next_pos[0]+1,next_pos[1])
			traced_path.append(next_pos)

		for temp_pos in traced_path:
			if temp_pos in foods_pos:
				foods_pos.remove(temp_pos)

		next_state = (temp_pos, tuple(foods_pos))
		return next_state

	def get_cost_of_plan(self, plan):
		cost = 0
		cur_state = self.initial_player_pos, []		# foods pos does not matter
		for action in plan:
			next_state = self.get_next_state(cur_state, action)
			cost += self.game_state.get_cost_of_action(cur_state, action, next_state)
			cur_state = next_state
		return cost

class PlatformersFoodReachabilityProblem:
	def __init__(self, game_state):
		self.game_state = game_state
		self.check_empty_positions = {	"noop": 			[],
										"left":				[(0,-1)],
										"right":			[(0,1)],
										"jump":				[(-1,0)],
										"short_jump_left":	[(-1,0), (-1,-1)],
										"short_jump_right":	[(-1,0), (-1,1)],
										"long_jump_left":	[(-1,0), (-1,-1), (-1,-2)],
										"long_jump_right":	[(-1,0), (-1,1), (-1,2)]
										}

	def is_valid(self, pos):
		x, y = pos
		return x>=0 and x<self.game_state.num_rows and y>=0 and y<self.game_state.num_cols

	def is_valid_player_pos(self, pos):
		return self.is_valid(pos) and pos not in self.game_state.blocks_pos and (pos[0]+1, pos[1]) in self.game_state.blocks_pos

	def get_actions(self, player_pos):
		assert self.is_valid(player_pos)

		actions = []

		for action in self.check_empty_positions:
			for neigh_pos in self.check_empty_positions[action]:
				next_pos = (player_pos[0]+neigh_pos[0], player_pos[1]+neigh_pos[1])
				if not self.is_valid(next_pos) or next_pos in self.game_state.blocks_pos:
					break
			else:
				actions.append(action)
		return actions		

	def get_next_pos_and_traced_path(self, player_pos, action):

		assert action in self.get_actions(player_pos)
		traced_path = [player_pos] + [(player_pos[0]+neigh_pos[0], player_pos[1]+neigh_pos[1]) for neigh_pos in self.check_empty_positions[action]]
		next_pos = traced_path[-1]
		while next_pos[0]+1<self.game_state.num_rows and (next_pos[0]+1,next_pos[1]) not in self.game_state.blocks_pos:
			next_pos = (next_pos[0]+1,next_pos[1])
			traced_path.append(next_pos)

		return next_pos, traced_path

	'''
	Q7. Optional to implement it, but if you plan to use the reachability concept for advanced_heuristic, you may find implementing it useful.
	'''
	def simple_traversal(self, player_pos:tuple)->set:
		'''
		Returns the set of foods_pos in game_state that could be eaten by player starting from player_pos. 

		You may find these function calls helpful:-
		1. self.game_state.foods_pos: A list of all food positions that is uneaten at the time of instantiating this class.
		2. self.get_actions(cur_pos): Returns a list of all legal actions from cur_pos
		3. self.get_next_pos_and_traced_path(cur_pos, action): Gives the final position on which the player lands if it takes action action from its cur_pos, as well as a list containing the positions in the traced path from cur_pos to the final position. However, cur_pos must be a legal landed player position.
		
		'''
		assert self.is_valid_player_pos(player_pos)
		
		# Write your code here
		# Write a very simple algorithm (recursive or iterative) to capture all the food positions that could be reached from player_pos

		raise utils.MethodNotImplementedError('simple_traversal')

class GraphSearchProblem:
	def __init__(self):
		pass
		self.expanded_states = list()

	def set_graph(self, vertices, edges, start_vertex, end_vertices):
		self.vertices = vertices
		self.adjlist = {vertex: [] for vertex in self.vertices}
		for u, v, cost in edges:
			self.adjlist[u].append((v,cost))
		self.start_vertex = start_vertex
		self.end_vertices = end_vertices
		self.actions = list(self.vertices)

	def set_heuristic_dict(self, heuristic_dict):
		self.heuristic_dict = heuristic_dict

	def get_heuristic_dict(self):
		return self.heuristic_dict

	def get_start_state(self):
		return self.start_vertex

	def is_goal_state(self, state):
		return state in self.end_vertices

	def get_successors(self, state):
		self.expanded_states.append(state)
		successors = list()
		# action is the next_vertex you can move on
		for next_vertex, cost in self.adjlist[state]:
			successors.append((next_vertex, next_vertex, cost))
		return successors