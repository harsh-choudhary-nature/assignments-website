import graphicsUtils
import gameSettings

class Player:
	def __init__(self):
		self.sprite_sheet_name = "idle_left"
		self.player_idle_index = 0
		self.player_left_index = 0
		self.player_right_index = 0	
		self.player_fall_index = 0	
		self.player_jump_index = 0
		self.player_fire_index = 0
		self.player_smoke_index = 0

		self.sprite_index_update_count = 3
		self.sprite_index_cur_count = 0
		self.sprite_sheet_cur_index = 0

		self.locked = False
		self.executing_action = "noop"
		self.executing_move = "idle"

		self.x_vel = 1
		self.y_vel = 0
		self.gravity = 1
		self.x_vel_max = 4
		self.x_vel_min = -2
		self.y_vel_max = 8
		self.y_vel_min = -8
		self.y_vel_neg_max = -1
		self.eaten_foods_during_animation = set()

		self.agent = None

		self.dx = 0
		self.dy = 0

		self.executed_plan = []

	def set_agent(self, agent):
		self.agent = agent

	def set_sprite_sheets(self, name):
		self.player_sprite_sheets = graphicsUtils.load_sprite_sheets("MainCharacters",name,32,32,gameSettings.grid_size,True)

	def draw_player(self, player_pos, game_state, window, offset_x, offset_y):
		x = player_pos[1]*gameSettings.grid_size + self.dx
		y = player_pos[0]*gameSettings.grid_size + self.dy

		for food in game_state.foods_pos:
			if food in self.eaten_foods_during_animation:
				continue
			suspected_pos = (round(y/gameSettings.grid_size), round(x/gameSettings.grid_size))
			if suspected_pos == food:
				self.eaten_foods_during_animation.add(food)

		window.blit(self.player_sprite_sheets[self.sprite_sheet_name][self.sprite_sheet_cur_index],(x-offset_x,y-offset_y))
		return (x-offset_x,y-offset_y)
		

	def act(self, problem):
		self.locked = True
		state = problem.get_state()

		action = self.agent.act(problem)
		self.executed_plan.append(action)
		
		next_state = problem.get_next_state(state, action)
		if action == "noop":
			self.executing_action = "noop"
			self.executing_move = "idle"
			self.sprite_sheet_name = "idle_"+problem.game_state.facing
			self.dx = 0
			self.dy = 0
			self.continue_last(problem)
		elif action == "left":
			self.executing_action = "left"
			self.executing_move = "run"
			self.sprite_sheet_name = "run_left"
			self.dx = 0
			self.dy = 0
			cur_pos = state[0]
			next_pos = next_state[0]
			self.dist_x = (next_pos[1]-cur_pos[1])*gameSettings.grid_size
			self.dist_y = (next_pos[0]-cur_pos[0])*gameSettings.grid_size
			self.continue_last(problem) 
		elif action == "right":
			self.executing_action = "right"
			self.executing_move = "run"
			self.sprite_sheet_name = "run_right"
			self.dx = 0
			self.dy = 0
			cur_pos = state[0]
			next_pos = next_state[0]
			self.dist_x = (next_pos[1]-cur_pos[1])*gameSettings.grid_size
			self.dist_y = (next_pos[0]-cur_pos[0])*gameSettings.grid_size
			self.continue_last(problem) 
		elif action == "jump":
			self.executing_action = "jump"
			self.executing_move = "jump"
			self.sprite_sheet_name = "jump_wave_"+problem.game_state.facing
			self.dx = 0
			self.dy = 0
			cur_pos = state[0]
			intermediate_pos = (state[0][0]-1,state[0][1])
			self.dist_x = 0
			self.dist_y = (intermediate_pos[0]-cur_pos[0])*gameSettings.grid_size
			self.y_vel = self.y_vel_min
			self.touched_top = False
			self.continue_last(problem) 
		elif action == "short_jump_left":
			self.executing_action = "short_jump_left"
			self.executing_move = "jump"
			self.sprite_sheet_name = "jump_wave_left"
			self.dx = 0
			self.dy = 0
			cur_pos = state[0]
			intermediate_pos = (state[0][0]-1,state[0][1]-1)
			next_pos = next_state[0]
			self.dist_x = (intermediate_pos[1]-cur_pos[1])*gameSettings.grid_size
			self.dist_y1 = (intermediate_pos[0]-cur_pos[0])*gameSettings.grid_size
			self.dist_y2 = (next_pos[0] - cur_pos[0])*gameSettings.grid_size
			self.y_vel = self.y_vel_min
			self.touched_top = False
			self.continue_last(problem) 
		elif action == "short_jump_right":
			self.executing_action = "short_jump_right"
			self.executing_move = "jump"
			self.sprite_sheet_name = "jump_wave_right"
			self.dx = 0
			self.dy = 0
			cur_pos = state[0]
			intermediate_pos = (state[0][0]-1,state[0][1]+1)
			next_pos = next_state[0]
			self.dist_x = (intermediate_pos[1]-cur_pos[1])*gameSettings.grid_size
			self.dist_y1 = (intermediate_pos[0]-cur_pos[0])*gameSettings.grid_size
			self.dist_y2 = (next_pos[0] - cur_pos[0])*gameSettings.grid_size
			self.y_vel = self.y_vel_min
			self.touched_top = False
			self.continue_last(problem) 
		elif action == "long_jump_left":
			self.executing_action = "long_jump_left"
			self.executing_move = "jump"
			self.sprite_sheet_name = "jump_wave_left"
			self.dx = 0
			self.dy = 0
			cur_pos = state[0]
			intermediate_pos = (state[0][0]-1,state[0][1]-2)
			next_pos = next_state[0]
			self.dist_x = (intermediate_pos[1]-cur_pos[1])*gameSettings.grid_size
			self.dist_y1 = (intermediate_pos[0]-cur_pos[0])*gameSettings.grid_size
			self.dist_y2 = (next_pos[0] - cur_pos[0])*gameSettings.grid_size
			self.y_vel = self.y_vel_min
			self.touched_top = False
			self.continue_last(problem) 
		elif action == "long_jump_right":
			self.executing_action = "long_jump_right"
			self.executing_move = "jump"
			self.sprite_sheet_name = "jump_wave_right"
			self.dx = 0
			self.dy = 0
			cur_pos = state[0]
			intermediate_pos = (state[0][0]-1,state[0][1]+2)
			next_pos = next_state[0]
			self.dist_x = (intermediate_pos[1]-cur_pos[1])*gameSettings.grid_size
			self.dist_y1 = (intermediate_pos[0]-cur_pos[0])*gameSettings.grid_size
			self.dist_y2 = (next_pos[0] - cur_pos[0])*gameSettings.grid_size
			self.y_vel = self.y_vel_min
			self.touched_top = False
			self.continue_last(problem) 

	def continue_last(self, problem):
		if self.executing_action == "left":
			self.animate_left(problem) 
		elif self.executing_action == "right":
			self.animate_right(problem)
		elif self.executing_action == "jump":
			self.animate_jump(problem)
		elif self.executing_action == "short_jump_left":
			self.animate_short_jump_left(problem)
		elif self.executing_action == "short_jump_right":
			self.animate_short_jump_right(problem)
		elif self.executing_action == "long_jump_left":
			self.animate_long_jump_left(problem)
		elif self.executing_action == "long_jump_right":
			self.animate_long_jump_right(problem)
		else:
			self.animate_noop(problem)

	def animate_noop(self, problem):
		state = problem.get_state()
		next_state = problem.get_next_state(state, self.executing_action)
		cost = problem.game_state.get_cost_of_action(state, self.executing_action, next_state)
		successor = (next_state,self.executing_action,cost)
		problem.game_state.update_game_state(successor)
		self.unlock(problem)
		self.sprite_index_cur_count += 1
		if self.sprite_index_cur_count == self.sprite_index_update_count:
			self.player_idle_index = (self.player_idle_index + 1)%len(self.player_sprite_sheets[self.sprite_sheet_name])
			self.sprite_index_cur_count = 0
		self.sprite_sheet_cur_index = self.player_idle_index

	def animate_left(self, problem):
		if self.dx > self.dist_x*3//4:
			self.dx -= self.x_vel
		elif self.dx > self.dist_x:
			self.dx -= self.x_vel
			if self.dy < self.dist_y:
				self.executing_move = "fall"
				self.sprite_sheet_name = "fall_left"
				self.dy += self.y_vel
				self.y_vel = min(self.y_vel_max, self.y_vel+self.gravity)
		else:
			if self.dy < self.dist_y:
				self.dy += self.y_vel
				self.y_vel = min(self.y_vel_max, self.y_vel+self.gravity)
			else:
				state = problem.get_state()
				next_state = problem.get_next_state(state, self.executing_action)
				cost = problem.game_state.get_cost_of_action(state, self.executing_action, next_state)
				successor = (next_state,self.executing_action,cost)
				problem.game_state.update_game_state(successor)
				self.unlock(problem)
		self.sprite_index_cur_count += 1
		if self.sprite_index_cur_count == self.sprite_index_update_count:
			if self.executing_move == "run":
				self.player_left_index = (self.player_left_index + 1)%len(self.player_sprite_sheets[self.sprite_sheet_name])
			elif self.executing_move == "fall":
				self.player_fall_index = (self.player_fall_index + 1)%len(self.player_sprite_sheets[self.sprite_sheet_name])
			self.sprite_index_cur_count = 0
		if self.executing_move == "run":
			self.sprite_sheet_cur_index = self.player_left_index	
		else:
			self.sprite_sheet_cur_index = self.player_fall_index
		
	def animate_right(self, problem):
		if self.dx < self.dist_x*3//4:
			self.dx += self.x_vel
		elif self.dx < self.dist_x:
			self.dx += self.x_vel
			if self.dy < self.dist_y:
				self.executing_move = "fall"
				self.sprite_sheet_name = "fall_right"
				self.dy += self.y_vel
				self.y_vel = min(self.y_vel_max, self.y_vel+self.gravity)
		else:
			if self.dy < self.dist_y:
				self.dy += self.y_vel
				self.y_vel = min(self.y_vel_max, self.y_vel+self.gravity)
			else:
				state = problem.get_state()
				next_state = problem.get_next_state(state, self.executing_action)
				cost = problem.game_state.get_cost_of_action(state, self.executing_action, next_state)
				successor = (next_state,self.executing_action,cost)
				problem.game_state.update_game_state(successor)
				self.unlock(problem)
		self.sprite_index_cur_count += 1
		if self.sprite_index_cur_count == self.sprite_index_update_count:
			if self.executing_move == "run":
				self.player_right_index = (self.player_right_index + 1)%len(self.player_sprite_sheets[self.sprite_sheet_name])
			elif self.executing_move == "fall":
				self.player_fall_index = (self.player_fall_index + 1)%len(self.player_sprite_sheets[self.sprite_sheet_name])
			self.sprite_index_cur_count = 0
		if self.executing_move == "run":
			self.sprite_sheet_cur_index = self.player_right_index	
		else:
			self.sprite_sheet_cur_index = self.player_fall_index

	def animate_jump(self, problem):
		if self.dy > self.dist_y and not self.touched_top:
			self.dy += self.y_vel
			self.y_vel = min(self.y_vel + self.gravity, self.y_vel_neg_max)
		else:
			if self.y_vel<0:
				self.y_vel = 1
				self.touched_top = True
				self.sprite_sheet_name = "fall_"+problem.game_state.facing
				self.executing_move = "fall"
			if self.dy < 0:
				self.dy += self.y_vel
				self.y_vel = min(self.y_vel_max, self.y_vel + self.gravity)
			else:
				state = problem.get_state()
				next_state = problem.get_next_state(state, self.executing_action)
				cost = problem.game_state.get_cost_of_action(state, self.executing_action, next_state)
				successor = (next_state,self.executing_action,cost)
				problem.game_state.update_game_state(successor)
				self.unlock(problem)
		self.sprite_index_cur_count += 1
		if self.sprite_index_cur_count == self.sprite_index_update_count:
			if self.executing_move == "jump":
				self.player_jump_index = (self.player_jump_index + 1)%len(self.player_sprite_sheets[self.sprite_sheet_name])
			elif self.executing_move == "fall":
				self.player_fall_index = (self.player_fall_index + 1)%len(self.player_sprite_sheets[self.sprite_sheet_name])
			self.sprite_index_cur_count = 0
		if self.executing_move == "jump":
			self.sprite_sheet_cur_index = self.player_jump_index	
		else:
			self.sprite_sheet_cur_index = self.player_fall_index

	def animate_short_jump_left(self, problem):
		if self.dy > self.dist_y1 and not self.touched_top:
			self.dy += self.y_vel
			self.y_vel = min(self.y_vel + self.gravity, self.y_vel_neg_max)
			if self.dx > self.dist_x:
				self.dx -= self.x_vel
				if self.y_vel > self.y_vel_min//8:
					self.x_vel = min(self.x_vel_max, self.x_vel + 1)
		else:
			if self.y_vel<0:
				if self.dx > self.dist_x:
					self.dx -= self.x_vel
					if self.y_vel > self.y_vel_min//8:
						self.x_vel = min(self.x_vel_max, self.x_vel + 1)
					self.executing_move = "smoke"
					self.sprite_sheet_name = "jump_smoke_left"
				else:
					self.y_vel = 1
					self.touched_top = True
					self.sprite_sheet_name = "fall_left"
					self.executing_move = "fall"
					self.x_vel = 0
			else:
				if self.dy < self.dist_y2:
					self.dy += self.y_vel
					self.y_vel = min(self.y_vel_max, self.y_vel + self.gravity)
				else:
					state = problem.get_state()
					next_state = problem.get_next_state(state, self.executing_action)
					cost = problem.game_state.get_cost_of_action(state, self.executing_action, next_state)
					successor = (next_state,self.executing_action,cost)
					problem.game_state.update_game_state(successor)
					self.unlock(problem)
		self.sprite_index_cur_count += 1
		if self.sprite_index_cur_count == self.sprite_index_update_count:
			if self.executing_move == "jump":
				self.player_jump_index = (self.player_jump_index + 1)%len(self.player_sprite_sheets[self.sprite_sheet_name])
			elif self.executing_move == "fall":
				self.player_fall_index = (self.player_fall_index + 1)%len(self.player_sprite_sheets[self.sprite_sheet_name])
			elif self.executing_move == "smoke":
				self.player_smoke_index = (self.player_smoke_index + 1)%len(self.player_sprite_sheets[self.sprite_sheet_name])
			self.sprite_index_cur_count = 0
		if self.executing_move == "jump":
			self.sprite_sheet_cur_index = self.player_jump_index
		elif self.executing_move == "smoke":
			self.sprite_sheet_cur_index = self.player_smoke_index	
		else:
			self.sprite_sheet_cur_index = self.player_fall_index

	def animate_short_jump_right(self, problem):
		if self.dy > self.dist_y1 and not self.touched_top:
			self.dy += self.y_vel
			self.y_vel = min(self.y_vel + self.gravity, self.y_vel_neg_max)
			if self.dx < self.dist_x:
				self.dx += self.x_vel
				if self.y_vel > self.y_vel_min//8:
					self.x_vel = min(self.x_vel_max, self.x_vel + 1)
		else:
			if self.y_vel<0:
				if self.dx < self.dist_x:
					self.dx += self.x_vel
					if self.y_vel > self.y_vel_min//8:
						self.x_vel = min(self.x_vel_max, self.x_vel + 1)
					self.executing_move = "smoke"
					self.sprite_sheet_name = "jump_smoke_right"
				else:
					self.y_vel = 1
					self.touched_top = True
					self.sprite_sheet_name = "fall_right"
					self.executing_move = "fall"
					self.x_vel = 0
			else:
				if self.dy < self.dist_y2:
					self.dy += self.y_vel
					self.y_vel = min(self.y_vel_max, self.y_vel + self.gravity)
				else:
					state = problem.get_state()
					next_state = problem.get_next_state(state, self.executing_action)
					cost = problem.game_state.get_cost_of_action(state, self.executing_action, next_state)
					successor = (next_state,self.executing_action,cost)
					problem.game_state.update_game_state(successor)
					self.unlock(problem)
		self.sprite_index_cur_count += 1
		if self.sprite_index_cur_count == self.sprite_index_update_count:
			if self.executing_move == "jump":
				self.player_jump_index = (self.player_jump_index + 1)%len(self.player_sprite_sheets[self.sprite_sheet_name])
			elif self.executing_move == "fall":
				self.player_fall_index = (self.player_fall_index + 1)%len(self.player_sprite_sheets[self.sprite_sheet_name])
			elif self.executing_move == "smoke":
				self.player_smoke_index = (self.player_smoke_index + 1)%len(self.player_sprite_sheets[self.sprite_sheet_name])
			self.sprite_index_cur_count = 0
		if self.executing_move == "jump":
			self.sprite_sheet_cur_index = self.player_jump_index
		elif self.executing_move == "smoke":
			self.sprite_sheet_cur_index = self.player_smoke_index	
		else:
			self.sprite_sheet_cur_index = self.player_fall_index

	def animate_long_jump_left(self, problem):
		if self.dy > self.dist_y1 and not self.touched_top:
			self.dy += self.y_vel
			self.y_vel = min(self.y_vel + self.gravity, self.y_vel_neg_max)
			if self.dx > self.dist_x:
				self.dx -= self.x_vel
				if self.dy < self.dist_y1 + 8:
					self.x_vel = min(self.x_vel_max, self.x_vel + 1)
		else:
			if self.y_vel<0:
				if self.dx > self.dist_x:
					self.dx -= self.x_vel
					if self.dy < self.dist_y1 + 8:
						self.x_vel = min(self.x_vel_max, self.x_vel + 1)
					self.executing_move = "fire"
					self.sprite_sheet_name = "jump_fire_left"
				else:
					self.y_vel = 1
					self.touched_top = True
					self.sprite_sheet_name = "fall_left"
					self.executing_move = "fall"
					self.x_vel = 0
			else:
				if self.dy < self.dist_y2:
					self.dy += self.y_vel
					self.y_vel = min(self.y_vel_max, self.y_vel + self.gravity)
				else:
					state = problem.get_state()
					next_state = problem.get_next_state(state, self.executing_action)
					cost = problem.game_state.get_cost_of_action(state, self.executing_action,next_state)
					successor = (next_state,self.executing_action,cost)
					problem.game_state.update_game_state(successor)
					self.unlock(problem)
		self.sprite_index_cur_count += 1
		if self.sprite_index_cur_count == self.sprite_index_update_count:
			if self.executing_move == "jump":
				self.player_jump_index = (self.player_jump_index + 1)%len(self.player_sprite_sheets[self.sprite_sheet_name])
			elif self.executing_move == "fall":
				self.player_fall_index = (self.player_fall_index + 1)%len(self.player_sprite_sheets[self.sprite_sheet_name])
			elif self.executing_move == "fire":
				self.player_fire_index = (self.player_fire_index + 1)%len(self.player_sprite_sheets[self.sprite_sheet_name])
			self.sprite_index_cur_count = 0
		if self.executing_move == "jump":
			self.sprite_sheet_cur_index = self.player_jump_index
		elif self.executing_move == "fire":
			self.sprite_sheet_cur_index = self.player_fire_index	
		else:
			self.sprite_sheet_cur_index = self.player_fall_index

	def animate_long_jump_right(self, problem):
		if self.dy > self.dist_y1 and not self.touched_top:
			self.dy += self.y_vel
			self.y_vel = min(self.y_vel + self.gravity, self.y_vel_neg_max)
			if self.dx < self.dist_x:
				self.dx += self.x_vel
				if self.dy < self.dist_y1 + 8:
					self.x_vel = min(self.x_vel_max, self.x_vel + 1)
		else:
			if self.y_vel<0:
				if self.dx < self.dist_x:
					self.dx += self.x_vel
					if self.dy < self.dist_y1 + 8:
						self.x_vel = min(self.x_vel_max, self.x_vel + 1)
					self.executing_move = "fire"
					self.sprite_sheet_name = "jump_fire_right"
				else:
					self.y_vel = 1
					self.touched_top = True
					self.sprite_sheet_name = "fall_right"
					self.executing_move = "fall"
					self.x_vel = 0
			else:
				if self.dy < self.dist_y2:
					self.dy += self.y_vel
					self.y_vel = min(self.y_vel_max, self.y_vel + self.gravity)
				else:
					state = problem.get_state()
					next_state = problem.get_next_state(state, self.executing_action)
					cost = problem.game_state.get_cost_of_action(state, self.executing_action,next_state)
					successor = (next_state,self.executing_action,cost)
					problem.game_state.update_game_state(successor)
					self.unlock(problem)
		self.sprite_index_cur_count += 1
		if self.sprite_index_cur_count == self.sprite_index_update_count:
			if self.executing_move == "jump":
				self.player_jump_index = (self.player_jump_index + 1)%len(self.player_sprite_sheets[self.sprite_sheet_name])
			elif self.executing_move == "fall":
				self.player_fall_index = (self.player_fall_index + 1)%len(self.player_sprite_sheets[self.sprite_sheet_name])
			elif self.executing_move == "fire":
				self.player_fire_index = (self.player_fire_index + 1)%len(self.player_sprite_sheets[self.sprite_sheet_name])
			self.sprite_index_cur_count = 0
		if self.executing_move == "jump":
			self.sprite_sheet_cur_index = self.player_jump_index
		elif self.executing_move == "fire":
			self.sprite_sheet_cur_index = self.player_fire_index	
		else:
			self.sprite_sheet_cur_index = self.player_fall_index


	def unlock(self, problem):

		self.executing_action = "noop"
		self.executing_move = "idle"
		self.sprite_sheet_name = "idle_"+problem.game_state.facing
		self.execution_time = 0
		self.dx = 0
		self.dy = 0
		self.x_vel = 1
		self.y_vel = 0	
		self.locked = False
		