import Problems
import utils

'''
Q6. Heuristic for A* search
'''
def farthest_food_manhattan(state, problem: Problems.PlatformersSearchProblem, cache):
    '''
    Must implement it, heuristic(state) is the longest manhattan distnace between state[0] (player_pos) and any element in state[1] (foods_pos)

    It should return the farthest food from player position that is not eaten.
    '''
    from utils import manhattan_distance
    player_pos, foods_pos = state
    
    ''' YOUR CODE HERE '''

    raise utils.MethodNotImplementedError('farthest_food_manhattan')

def closest_food_manhattan(state, problem: Problems.PlatformersSearchProblem, cache):
    '''
    If you intend to use this heuristic, first implement it, heuristic(state) is the shortest manhattan distnace between state[0] and any element in state[1]
    '''
    from utils import manhattan_distance
    player_pos, foods_pos = state
    
    '''OPTIONAL: Not Counted towards grading!'''

    raise utils.MethodNotImplementedError('closest_food_manhattan')


def sum_food_manhattan(state, problem: Problems.PlatformersSearchProblem, cache):
    '''
    If you intend to use this heuristic, first implement it, heuristic(state) is the sum of manhattan distnaces between state[0] and all the element in state[1].
    Will this be a consistent heuristic?
    '''
    from utils import manhattan_distance
    player_pos, foods_pos = state
    
    '''OPTIONAL: Not Counted towards grading!'''

    raise utils.MethodNotImplementedError('sum_food_manhattan')

'''
Q7. Implement your advanced but time sensitive heuristic logic here. Grades depend on no. of expanded states and consistency of heuristic also, so be cautious.
'''
def advanced_heuristic(state, problem: Problems.PlatformersSearchProblem, cache):
    '''
    You may find these function calls helpful:-

    1. Problems.PlatformersFoodReachabilityProblem(problem.game_state): An object that you can use to get the set of all food positions that are reachable from player position in state[0].
    2. problem.game_state.get_num_rows(): Gives the total no. of rows in the world
    3. problem.game_state.get_num_cols(): Gives the total no. of columns in the world. 
    A position in the world is just a tuple (row, col) where row and col are 0 based valid row and column numbers

    These functions of PlatformersFoodReachabilityProblem class may be of interest to you:-
    1. is_valid_player_pos(player_pos): Whether player_pos is a valid landed player position.
    2. simple_traversal(player_pos): Tells set of all the food positions those are reachable from player_pos, but make sure player_pos is a valid landed player position only.

    Hint: If you are getting time limit exceeded, you may want to use cache effectively, and some precomputations may save you lots of time.

    '''

    from utils import manhattan_distance
    player_pos, foods_pos = state

    ''' YOUR CODE HERE '''

    return utils.MethodNotImplementedError('advanced_heuristic')


def early_food_heuristic(state, problem: Problems.PlatformersSearchProblem, cache):
    return len(state[1])

def null_heuristic(state, problem, cache):
    return 0

def graph_heuristics(state, problem, cache):
    heuristic_dict = problem.get_heuristic_dict()
    if state in heuristic_dict:
        return heuristic_dict[state]
    return 0