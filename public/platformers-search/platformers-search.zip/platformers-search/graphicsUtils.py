import os
import pygame
import gameSettings

def flip(sprites):
	return [pygame.transform.flip(sprite, flip_x = True, flip_y = False) for sprite in sprites]

def load_sprite_sheets(dir1, dir2, width, height, grid_size, direction=False):
	script_dir = os.path.dirname(os.path.abspath(__file__))
	path = os.path.join(script_dir, "assets", dir1, dir2)
	images = [f for f in os.listdir(path) if os.path.isfile(os.path.join(path, f))]

	all_sprites = {}

	for image in images:
		sprite_sheet = pygame.image.load(os.path.join(path, image)).convert_alpha()

		sprites = []
		for i in range(sprite_sheet.get_width() // width):
			surface = pygame.Surface((width, height), pygame.SRCALPHA, 32)
			rect = pygame.Rect(i * width, 0, width, height)
			surface.blit(sprite_sheet, (0, 0), rect)
			sprites.append(pygame.transform.scale(surface,(grid_size,grid_size)))  # we need 64x64 instead of 32x32 images

		if direction:
			all_sprites[image.replace(".png", "") + "_right"] = sprites
			all_sprites[image.replace(".png", "") + "_left"] = flip(sprites)
		else:
			all_sprites[image.replace(".png", "")] = sprites
	return all_sprites

def parse(layout_filename):
	layout = list()
	script_dir = os.path.dirname(os.path.abspath(__file__))
	path = os.path.join(script_dir, "layouts",layout_filename)
	fh = open(path, "r")
	for line in fh:
		layout.append(list())
		for char in line:
			if char == '.':
				layout[-1].append('.')
			elif char == 'B':
				layout[-1].append('B')
			elif char == 'D':
				layout[-1].append('D')
			elif char == 'P':
				layout[-1].append('P')
	return layout

def get_food_image(bg_filename, dir1, dir2, width, height):
	script_dir = os.path.dirname(os.path.abspath(__file__))
	sprite_sheet = pygame.image.load(os.path.join(script_dir,"assets",dir1, dir2, bg_filename)).convert_alpha()
	sprites = []
	for i in range(sprite_sheet.get_width() // width):
		surface = pygame.Surface((width, height), pygame.SRCALPHA, 32)
		rect = pygame.Rect(i * width, 0, width, height)
		surface.blit(sprite_sheet, (0, 0), rect)
		sprites.append(pygame.transform.scale(surface,(gameSettings.grid_size,gameSettings.grid_size)))  # we need 64x64 instead of 32x32 images
	return sprites

def get_image(bg_filename, dirname):
	script_dir = os.path.dirname(os.path.abspath(__file__))
	image = pygame.image.load(os.path.join(script_dir,"assets",dirname,bg_filename))
	return pygame.transform.scale(image, (gameSettings.grid_size, gameSettings.grid_size))
