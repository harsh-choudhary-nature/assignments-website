import utils


'''
Q2: Implement the depth first search (dfs) function here.
'''
def dfs(problem):
	'''
	problem is the PlatformersSearchProblem object and it provides APIs to obtain information about state and actions.
	
	Function calls you'll need:-
	1. problem.get_start_state(): returns a tuple of current player position, and a tuple of all food positions (food positions are also tuples, so this basically makes it a tuple of tuples)
	2. problem.get_successors(<current state>): returns a list of three element tuple successors, where one successor has next_state, action that took from <current state> to next_state and the cost of this action
	3. problem.is_goal_state(<state>): returns True or False based on whether the passed state is a goal state of the game.

	Stack has the usual methods:-
	1. push(element): adds the element to the stack
	2. pop(): Returns the top element of the stack and deletes it from the stack
	3. is_empty(): Returns bool indicating whether or not the stack is empty
	For more details, refer to utils.py

	Returns a list of actions
	'''

	from utils import Stack
	state = problem.get_start_state()
	stk = Stack()

	''' YOUR CODE HERE '''
	
	raise utils.MethodNotImplementedError('dfs')

'''
Q3: Implement the breadth first search (bfs) function here.
'''
def bfs(problem):
	'''
	problem is the PlatformersSearchProblem object and it provides APIs to obtain information about state and actions.
	
	Function calls you'll need:-
	1. problem.get_start_state(): returns a tuple of current player position, and a tuple of all food positions (food positions are also tuples, so this basically makes it a tuple of tuples)
	2. problem.get_successors(<current state>): returns a list of three element tuple successors, where one successor has next_state, action that took from <current state> to next_state and the cost of this action
	3. problem.is_goal_state(<state>): returns True or False based on whether the passed state is a goal state of the game.

	Queue has the usual methods:-
	1. push(element): adds the element to the queue
	2. pop(): Returns the top element of the queue and deletes it from the queue
	3. is_empty(): Returns bool indicating whether or not the queue is empty
	For more details, refer to utils.py

	Returns a list of actions
	'''

	from utils import Queue
	state = problem.get_start_state()
	q = Queue()
	
	''' YOUR CODE HERE '''

	raise utils.MethodNotImplementedError('bfs')

'''
Q5: Implement the uniform cost search (ucs) function here.
'''
def ucs(problem):
	'''
	problem is the PlatformersSearchProblem object and it provides APIs to obtain information about state and actions.
	
	Function calls you'll need:-
	1. problem.get_start_state(): returns a tuple of current player position, and a tuple of all food positions (food positions are also tuples, so this basically makes it a tuple of tuples)
	2. problem.get_successors(<current state>): returns a list of three element tuple successors, where one successor has next_state, action that took from <current state> to next_state and the cost of this action
	3. problem.is_goal_state(<state>): returns True or False based on whether the passed state is a goal state of the game.

	Priority Queue has the usual methods:-
	1. push(element): adds the element to the priority queue
	2. pop(): Returns the top element of the priority queue and deletes it from the priority queue
	3. is_empty(): Returns bool indicating whether or not the priority queue is empty
	For more details, refer to utils.py

	Returns a list of actions
	'''

	from utils import PriorityQueue
	state = problem.get_start_state()
	pq = PriorityQueue()
	
	''' YOUR CODE HERE '''

	raise utils.MethodNotImplementedError('ucs')

'''
Q6: Implement the A* function here.
'''
def astar(problem, heuristic_fn_str):
	'''
	problem is the PlatformersSearchProblem object and it provides APIs to obtain information about state and actions.
	
	Function calls you'll need:-
	1. problem.get_start_state(): returns a tuple of current player position, and a tuple of all food positions (food positions are also tuples, so this basically makes it a tuple of tuples)
	2. problem.get_successors(<current state>): returns a list of three element tuple successors, where one successor has next_state, action that took from <current state> to next_state and the cost of this action
	3. problem.is_goal_state(<state>): returns True or False based on whether the passed state is a goal state of the game.

	Priority Queue has the usual methods:-
	1. push(element): adds the element to the priority queue
	2. pop(): Returns the top element of the priority queue and deletes it from the priority queue
	3. is_empty(): Returns bool indicating whether or not the priority queue is empty
	For more details, refer to utils.py

	To call heuristic function, use:-
	heuristic(state, problem, cache) where cache is a dictionary to avoid recomputation or to pass extra arguments to heuristic

	Returns a list of actions
	'''

	from utils import PriorityQueue
	import heuristicFunctions
	cache = dict()
	heuristic = getattr(heuristicFunctions, heuristic_fn_str)
	state = problem.get_start_state()
	pq = PriorityQueue()
	
	''' YOUR CODE HERE '''

	raise utils.MethodNotImplementedError('astar')

def small_test3_search_test(problem):
	'''
	This is only to test the functioning of small_test2.lay, and it shall not function on any other layouts due to hardcoded plan
	'''
	return ["long_jump_left", "long_jump_right", "short_jump_right", "short_jump_right", "left", "right"]