import pygame
import gameSettings
import player
import ghost
import graphicsUtils
import os

class Game:

	def __init__(self, num_ghosts, num_rows, num_cols, blocks_pos, foods_pos, freezers_pos, player_start_pos, ghosts_start_pos, score, fix_seed_value):
		pygame.init()

		info = pygame.display.Info()
		self.screen_width = info.current_w*3//4
		self.screen_height = info.current_h*3//4
		self.max_rows = self.screen_height//gameSettings.grid_size
		self.max_cols = self.screen_width//gameSettings.grid_size
		self.top_left = (self.screen_width//8, self.screen_height//8)

		self.num_rows = num_rows
		self.num_cols = num_cols
		self.blocks_pos = blocks_pos
		self.foods_pos = foods_pos
		self.freezers_pos = freezers_pos
		self.score = score
		self.game_height, self.game_width = min(self.num_rows*gameSettings.grid_size, self.max_rows*gameSettings.grid_size), min(self.num_cols*gameSettings.grid_size, self.max_cols*gameSettings.grid_size)

		os.environ['SDL_VIDEO_WINDOW_POS'] = f'{self.top_left[0]}, {self.top_left[1]}'
		pygame.display.set_caption(gameSettings.caption)
		self.window = pygame.display.set_mode((self.game_width, self.game_height))

		self.player = player.Player(0, player_start_pos, fix_seed_value)
		self.ghosts = []
		for i in range(num_ghosts):
			self.ghosts.append(ghost.Ghost(i+1, ghosts_start_pos[i], fix_seed_value))

		self.locked = False

		self.font = pygame.font.Font(None, 24)
		self.background_image = graphicsUtils.get_image(gameSettings.bg_tile_name, gameSettings.background_folder)
		self.block_image = graphicsUtils.get_image(gameSettings.block_file_name, gameSettings.block_folder)
		self.food_image_sheet = graphicsUtils.get_food_image(gameSettings.food_file_name, gameSettings.food_folder1, gameSettings.food_folder2, gameSettings.sprite_sheet_height, gameSettings.sprite_sheet_height)
		self.freezer_image_sheet = graphicsUtils.get_food_image(gameSettings.freezer_file_name, gameSettings.food_folder1, gameSettings.food_folder2, gameSettings.sprite_sheet_height, gameSettings.sprite_sheet_height)
		self.food_image_sheet_index = 0
		self.freezer_image_sheet_index = 0
		self.index_cur_count = 0
		self.index_update_cnt = gameSettings.animation_update_cnt
		self.eaten_food_indices_during_animation = set()
		self.eaten_freezer_indices_during_animation = set()
		self.eaten_inactive_ghost_indices_during_animation = dict()

		self.game_over = False

		self.foods_sprite_sheet_offsets = [i%len(self.food_image_sheet) for i in range(len(self.foods_pos))]

	def init_offset(self, initial_player_pos):
		if self.num_rows*gameSettings.grid_size<=self.game_height and self.num_cols*gameSettings.grid_size<=self.game_width:
			self.offset_x = 0
			self.offset_y = 0
		else:
			player_x = initial_player_pos[1]*gameSettings.grid_size
			player_y = initial_player_pos[0]*gameSettings.grid_size
			# initially also it can be greater than the limits
			if player_x + gameSettings.grid_size > self.game_width - gameSettings.grid_size:
				self.offset_x = player_x + gameSettings.grid_size - self.game_width + (gameSettings.grid_size if initial_player_pos[1]<self.num_cols-1 else 0)
			else:
				self.offset_x = 0
			if player_y + gameSettings.grid_size > self.game_height - gameSettings.grid_size:
				self.offset_y = player_y + gameSettings.grid_size - self.game_height + (gameSettings.grid_size if initial_player_pos[0]<self.num_rows-1 else 0)
			else:
				self.offset_y = 0
		
	def adjust_offset(self, top_left_player):
		
		player_pixel_x, player_pixel_y = top_left_player
		if player_pixel_x <2*gameSettings.grid_size:
			if self.offset_x > 0:
				self.offset_x += player_pixel_x - 2*gameSettings.grid_size
		elif player_pixel_x + gameSettings.grid_size > self.game_width - 2*gameSettings.grid_size:
			if self.offset_x < (gameSettings.grid_size*self.num_cols - self.game_width):	# max offset possible
				self.offset_x += player_pixel_x + gameSettings.grid_size - self.game_width + 2*gameSettings.grid_size

		if player_pixel_y <2*gameSettings.grid_size:
			if self.offset_y > 0:
				self.offset_y += player_pixel_y - 2*gameSettings.grid_size

		elif player_pixel_y + gameSettings.grid_size > self.game_height - 2*gameSettings.grid_size:
			if self.offset_y < (gameSettings.grid_size*self.num_rows - self.game_height):	# max offset possible
				self.offset_y += player_pixel_y + gameSettings.grid_size - self.game_height + 2*gameSettings.grid_size


	def take_ply(self, problem):
		self.foods_pos = problem.game_state.foods_pos
		self.freezers_pos = problem.game_state.freezers_pos
		self.eaten_food_indices_during_animation = set()
		self.eaten_freezer_indices_during_animation = set()
		self.eaten_inactive_ghost_indices_during_animation = dict()

		cur_game_state = problem.game_state
			
		player_action = problem.player_agent.act(0, cur_game_state, problem)

		# for autograding  
		problem.actions.append(player_action)
		problem.num_generated_per_action.append(problem.generated_nodes_count_one_action)
		problem.generated_nodes_count_one_action = 0


		next_game_state, traced_path, self.food_indices_eaten_at_index_of_traced_path, self.freezer_indices_eaten_at_index_of_traced_path, self.inactive_ghost_indices_and_pos_eaten_at_index_of_traced_path, self.active_ghost_indices_eaten_at_index_of_traced_path = problem.player_rules.get_next_game_state(cur_game_state, player_action)

		for traced_path_index in self.inactive_ghost_indices_and_pos_eaten_at_index_of_traced_path:
			for ghost_index, ghost_pos in self.inactive_ghost_indices_and_pos_eaten_at_index_of_traced_path[traced_path_index]:
				self.eaten_inactive_ghost_indices_during_animation[ghost_index] = (ghost_pos, problem.game_state.ghosts_details[ghost_index].facing)

		problem.score -= problem.cost_function(0, cur_game_state, player_action, next_game_state)

		if player_action == "noop":
			self.score += gameSettings.points_per_move

		assert not self.player.locked
		self.player.init_animate(cur_game_state, player_action, next_game_state, traced_path)

		cur_game_state = next_game_state
		
		self.player_eaten_at_index_of_traced_path = [-1]*problem.num_ghosts
		if not cur_game_state.is_goal_state():
			for i in range(problem.num_ghosts):

				ghost_action = problem.ghost_agent.act(i+1, cur_game_state, problem)
				
				next_game_state, traced_path, self.player_eaten_at_index_of_traced_path[i] = problem.ghost_rules.get_next_game_state(i+1, cur_game_state, ghost_action)
				problem.score -= problem.cost_function(i+1, cur_game_state, player_action, next_game_state)

				assert not self.ghosts[i].locked
				self.ghosts[i].init_animate(cur_game_state, ghost_action, next_game_state, traced_path)

				cur_game_state = next_game_state
		
				if cur_game_state.is_goal_state():
					problem.game_state = cur_game_state
					for j in range(i+1, problem.num_ghosts):
						self.ghosts[j].init_animate(cur_game_state, "noop", cur_game_state, [cur_game_state.ghosts_details[j].pos])
					break
		else:
			for i in range(problem.num_ghosts):
				self.ghosts[i].init_animate(cur_game_state, "noop", cur_game_state, [cur_game_state.ghosts_details[i].pos])
			problem.game_state = cur_game_state

		problem.game_state = cur_game_state
		return False

	def draw_background(self):
		for i in range(0, self.num_cols):
			for j in range(0, self.num_rows):
				x = i*gameSettings.grid_size
				y = j*gameSettings.grid_size
				self.window.blit(self.background_image,(x-self.offset_x,y-self.offset_y))

	def draw_blocks(self):
		for block in self.blocks_pos:
			x = block[1]*gameSettings.grid_size
			y = block[0]*gameSettings.grid_size
			self.window.blit(self.block_image,(x-self.offset_x,y-self.offset_y))

	def draw_foods(self):
		for i in range(len(self.foods_pos)):
			if i in self.eaten_food_indices_during_animation:
				continue

			food = self.foods_pos[i]

			x = food[1]*gameSettings.grid_size
			y = food[0]*gameSettings.grid_size
			self.window.blit(self.food_image_sheet[(self.food_image_sheet_index + self.foods_sprite_sheet_offsets[i])%len(self.food_image_sheet)],(x-self.offset_x,y-self.offset_y))
		self.index_cur_count += 1
		if self.index_cur_count == self.index_update_cnt:
			self.food_image_sheet_index = (self.food_image_sheet_index + 1)%len(self.food_image_sheet)
			self.index_cur_count = 0

	def draw_freezers(self):
		for i in range(len(self.freezers_pos)):
			if i in self.eaten_freezer_indices_during_animation:
				continue

			freezer = self.freezers_pos[i]

			x = freezer[1]*gameSettings.grid_size
			y = freezer[0]*gameSettings.grid_size
			self.window.blit(self.freezer_image_sheet[self.freezer_image_sheet_index],(x-self.offset_x,y-self.offset_y))
		self.index_cur_count += 1
		if self.index_cur_count == self.index_update_cnt:
			self.freezer_image_sheet_index = (self.freezer_image_sheet_index + 1)%len(self.freezer_image_sheet)
			self.index_cur_count = 0

	def draw_score(self):
		text = self.font.render(f'Score: {self.score}', True, (0, 0, 0))
		text_rect = text.get_rect()
		text_rect.topleft = (10, 10)
		self.window.blit(text, text_rect)

	def draw(self):
		self.draw_background()
		self.draw_blocks()
		self.draw_foods()
		self.draw_freezers()
		top_left_player = self.player.draw(self.window, self.offset_x, self.offset_y)
		for i in range(len(self.ghosts)):
			if i not in self.eaten_inactive_ghost_indices_during_animation:
				self.ghosts[i].draw(self.window, self.offset_x, self.offset_y)
			else:
				# must animate them as idle frozen at self.eaten_inactive_ghost_indices_during_animation[i]
				self.ghosts[i].draw_reborn_ghost_premature(self.window, self.offset_x, self.offset_y,*self.eaten_inactive_ghost_indices_during_animation[i])	

		self.draw_score()
		self.adjust_offset(top_left_player)

	def handle_action_locking(self, problem):
		if self.locked:
			return self.continue_last(problem)
		else:
			self.locked = True
			return self.take_ply(problem)

	def continue_last(self, problem):
		if self.game_over:
			return True

		player_pos = self.player.cur_game_state.player_details.pos
		x = player_pos[1]*gameSettings.grid_size + self.player.dx
		y = player_pos[0]*gameSettings.grid_size + self.player.dy
		suspected_pos = (round(y/gameSettings.grid_size), round(x/gameSettings.grid_size))
		cost = 0
		if suspected_pos != self.player.traced_path[self.player.traced_path_index]:
			self.player.traced_path_index += 1
			
			cost -= gameSettings.points_per_move
			
		if self.player.traced_path_index in self.food_indices_eaten_at_index_of_traced_path:
			cost -= gameSettings.points_per_food
			for index in self.food_indices_eaten_at_index_of_traced_path[self.player.traced_path_index]:
				self.eaten_food_indices_during_animation.add(index)
			del self.food_indices_eaten_at_index_of_traced_path[self.player.traced_path_index]
			if(len(self.eaten_food_indices_during_animation)==len(self.foods_pos)):
				cost -= gameSettings.points_for_winning
				self.game_over = True
		
		if self.player.traced_path_index in self.freezer_indices_eaten_at_index_of_traced_path:
			for index in self.freezer_indices_eaten_at_index_of_traced_path[self.player.traced_path_index]:
				self.eaten_freezer_indices_during_animation.add(index)
				# make all the ghosts as frozen
			for ghost in self.ghosts:
				ghost.frozen = True
			del self.freezer_indices_eaten_at_index_of_traced_path[self.player.traced_path_index]

		if self.player.traced_path_index in self.inactive_ghost_indices_and_pos_eaten_at_index_of_traced_path:
			cost -= gameSettings.points_per_ghost
			for ghost_index, ghost_prev_pos in self.inactive_ghost_indices_and_pos_eaten_at_index_of_traced_path[self.player.traced_path_index]:
				self.ghosts[ghost_index].frozen = False
				del self.eaten_inactive_ghost_indices_during_animation[ghost_index]
			del self.inactive_ghost_indices_and_pos_eaten_at_index_of_traced_path[self.player.traced_path_index]
		if self.player.traced_path_index in self.active_ghost_indices_eaten_at_index_of_traced_path:
			# without loss of generality, pick the first index from it
			assert self.player.traced_path_index == len(self.player.traced_path)-1
			cost -= gameSettings.points_for_losing
			del self.active_ghost_indices_eaten_at_index_of_traced_path[self.player.traced_path_index]
			self.game_over = True
			self.player.alive = False

		self.score -= cost
		self.player.animate()

		for i in range(len(self.ghosts)):
			ghost_pos = self.ghosts[i].cur_game_state.ghosts_details[i].pos
			x = ghost_pos[1]*gameSettings.grid_size + self.ghosts[i].dx
			y = ghost_pos[0]*gameSettings.grid_size + self.ghosts[i].dy
			suspected_ghost_pos = (round(y/gameSettings.grid_size), round(x/gameSettings.grid_size))

			cost = 0
			if suspected_ghost_pos != self.ghosts[i].traced_path[self.ghosts[i].traced_path_index] and self.ghosts[i].traced_path_index+1<len(self.ghosts[i].traced_path):
				self.ghosts[i].traced_path_index += 1
				
			if self.player_eaten_at_index_of_traced_path[i] == self.ghosts[i].traced_path_index and suspected_ghost_pos == suspected_pos:
				cost -= gameSettings.points_for_losing
				self.game_over = True
			self.score -= cost
			if i not in self.eaten_inactive_ghost_indices_during_animation:
				if suspected_ghost_pos != self.ghosts[i].traced_path[self.ghosts[i].traced_path_index] and self.ghosts[i].traced_path_index+1>=len(self.ghosts[i].traced_path):
					self.ghosts[i].early_unlock()
				self.ghosts[i].animate()
		# check if all the animations completed then unlock the game
		animation_completed = not self.player.locked
		for ghost in self.ghosts:
			animation_completed = animation_completed and not ghost.locked
		self.locked = not animation_completed
		
		# if game is completed then return True
		return not self.locked and problem.game_state.is_goal_state()