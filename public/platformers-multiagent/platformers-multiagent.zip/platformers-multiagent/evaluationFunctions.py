'''
Functions in this file will be called only by the playerAgent, hence agent_index is not needed
'''
import utils


'''
Default Naive evaluation function to evaluate the state.
'''
def score_evaluation_function(game_state, problem, helper_cache = None):
	return game_state.get_score()


'''
Question 6: Better Evaluation Function.
'''
def better_evaluation_function(game_state, problem, helper_cache = None):
	'''
	args:- 
	1. game_state: The configuration of the game board as passed from act method.
	2. problem: The problem instance, offers several helpful method calls.

	You can find these functions helpful (already implemented):-
	1. utils.single_player_source_all_pos_dist(player_pos, problem): returns a dictionary, say 'dist', where dist[pos] tells the min no. of moves required to reach from player_pos to pos, as per player rules. It uses bfs algorithm.
	CAUTION: Do not call this function from a game_state that is already a goal state.
	2. utils.single_ghost_source_all_pos_dist(ghost_pos, problem): returns a dictionary, say 'dist', where dist[pos] tells the min no. of moves required to reach from ghost_pos to pos, as per ghost rules. It uses bfs algorithm.
	CAUTION: Do not call this function from a game_state that is already a goal state.

	You may find some properties from the game state helpful to evaluate the goodness of the game state. These are extracted and made available to you below.
	'''

	player_pos = game_state.get_player_position()
	foods_pos = game_state.get_foods_positions()
	freezers_pos = game_state.get_freezers_positions()
	ghosts_pos = game_state.get_ghosts_positions()
	ghosts_active_after_times = game_state.get_ghosts_active_after_times()
	ghosts_reborn = game_state.get_ghosts_reborn()
	ghosts_initial_pos = game_state.get_ghosts_initial_pos()
	score = game_state.get_score()
	
	"""*** YOUR CODE HERE ***"""

		
	raise utils.MethodNotImplementedError('better_evaluation_function')

def graph_game_tree_evaluation_function(game_state, problem, args = None):
	if game_state in problem.evaluation:
		return problem.evaluation[game_state]
	# as per reference autograder, this access should yield error
	raise utils.TestFailureError(f"Invalid access to evaluation functions: {game_state} has no evaluation defined", 1)
	return problem.default_evaluation