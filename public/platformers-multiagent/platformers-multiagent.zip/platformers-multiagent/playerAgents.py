import pygame
import utils, gameSettings
import evaluationFunctions

class KeyboardAgent:
	def __init__(self, args):
		self.buffer = ['noop']

	def read_in_buffer(self, agent_index, game_state, problem):
		keys = pygame.key.get_pressed()
		actions = problem.get_actions(agent_index, game_state)
		if keys[pygame.K_LEFT] and "left" in actions:
			self.buffer[0] = "left"
		elif keys[pygame.K_RIGHT] and "right" in actions:
			self.buffer[0] = "right"
		elif keys[pygame.K_SPACE] and "jump" in actions:
			self.buffer[0] = "jump"
		elif keys[pygame.K_a] and "long_jump_left" in actions:
			self.buffer[0] = "long_jump_left"
		elif keys[pygame.K_s] and "short_jump_left" in actions:
			self.buffer[0] = "short_jump_left"
		elif keys[pygame.K_d] and "short_jump_right" in actions:
			self.buffer[0] = "short_jump_right"
		elif keys[pygame.K_f] and "long_jump_right" in actions:
			self.buffer[0] = "long_jump_right"
		else:
			pass
	
	@utils.timeout(gameSettings.timeout_duration)
	def act(self, agent_index, game_state, problem):
		self.read_in_buffer(agent_index, game_state, problem)
		action = self.buffer[0]
		self.buffer[0] = 'noop'
		return action

class RandomAgent:
	def __init__(self, args):
		self.rng = args['rng']

	@utils.timeout(gameSettings.timeout_duration)
	def act(self, agent_index, game_state, problem):
		actions = problem.get_actions(agent_index, game_state)
		return self.rng.choice(actions)

class ReflexAgent:
	def __init__(self, args):
		'''
		self.rng is a random number generator, instantiated internally as np.random.default_rng(seed = fixSeed). This should be used in case you want to debug with fixed seed, and otherwise too. The helpful methods are:-
		1. self.rng.integers(low, high) => generates a random integer x s.t. low<=x<high.
		2. self.rng.random() => Generates random float in the half-open interval [0.0, 1.0).
		3. self.rng.choice(lst) => Generates a random element from the list.

		You can surf the web to know other options and methods you can use.
		''' 
		self.rng = args['rng']

	'''
	Question 1: Reflex Agent act method
	Implement a basic reflex agent that select that action which gives it best overall evaluation (evaluation function to be designed as well) based on the immediate next game state obtained by taking that action.
	'''	
	@utils.timeout(gameSettings.timeout_duration)
	def act(self, agent_index, game_state, problem):
		'''
		args:- 
		1. agent_index: This shall always be 0 for player agent and 1 onwards for each ghost agents
		2. game_state: The current configuration of the game board (as rendered on screen)
		3. problem: The problem instance, offers several helpful method calls


		Methods you might find useful:-
		1. problem.get_actions(agent_index, game_state): Returns a list of valid actions for the specified agent (through agent index) as per the game_state passed
		2. self.evaluation_function(game_state, action, problem): Evaluates the state action pair, i.e., the value to represent goodness/badness of taking 'action' in 'game_state'
		3. self.rng.choice(<lst>): will sample a random element from a list (lst)
		'''

		'''***YOUR CODE HERE***'''

		raise utils.MethodNotImplementedError('act')


	'''
	Question 1: Evaluation function
	Return a float value that is representative of the goodness or badness value of taking 'action' from 'cur_game_state' by the player. Higher numbers are better.
	'''
	def evaluation_function(self, cur_game_state, action, problem):
		'''
		args:-
		1. cur_game_state: The current configuration of the game board (as rendered on screen)
		2. action: The action reflex agent is currently evaluating to take from cur_game_state.
		3. problem: The problem instance, offers several helpful method calls

		Methods you might find useful:-
		1. problem.get_next_game_state(0, cur_game_state, action): Returns the next game state if player (agent_index 0) takes 'action' from cur_game_state
		2. next_game_state.get_player_position(): The position of player in next game state
		3. next_game_state.get_foods_positions(): List of positions where food is still uneaten in next game state
		4. next_game_state.get_ghosts_positions(): List of position of ghosts in next game state
		5. next_game_state.get_ghosts_active_after_times(): List of length equal to no. of ghosts, where ghost agent_index i's information is at index i-1 of this list (0 based indexing for list and 1 based for ghost indices), representing how many time units (in terms of game ply) remain before a ghost becomes active again; so 0 indicates an active ghost, 1 indicates a frozen ghost that will become active after this game ply, and so on
		6. next_game_state.get_ghosts_reborn(): List of bools (indexing same as active_after_times), where an element being True indicates that a frozen ghost was hit by a player and is reborned. Reborned ghosts remain stationary at their starting position for one ply.
		7. next_game_state.get_num_foods(): The no. of foods left uneaten in next game state
		8. next_game_state.get_score(): The score so far in reaching the next game state as per the game's cost function
		'''
		next_game_state = problem.get_next_game_state(0, cur_game_state, action)
		new_player_pos = next_game_state.get_player_position()
		new_foods_pos = next_game_state.get_foods_positions()
		new_ghosts_pos = next_game_state.get_ghosts_positions()
		new_ghosts_active_after_times = next_game_state.get_ghosts_active_after_times()
		new_ghosts_reborn = next_game_state.get_ghosts_reborn()
		num_foods = next_game_state.get_num_foods()     
		next_score = next_game_state.get_score()
		
		'''***YOUR CODE HERE***'''

		raise utils.MethodNotImplementedError('evaluation_function')

		
class MinimaxAgent:
	def __init__(self, args):
		self.evaluation_function = getattr(evaluationFunctions, args['evaluation_function'])
		self.depth = args['depth']

	'''
	Question 2: Minimax
	Implement a Minimax agent that selects the action which gives it best overall evaluation after simulating the game with Minimax algorithm upto 'self.depth' plies, evaluating naively on score evaluation function.
	'''		
	@utils.timeout(gameSettings.timeout_duration)
	def act(self, agent_index, game_state, problem):
		'''
		args:- 
		1. agent_index: This shall always be 0 for player agent and 1 onwards for each ghost agents
		2. game_state: The current configuration of the game board (as rendered on screen)
		3. problem: The problem instance, offers several helpful method calls


		Methods you might find useful:-
		1. problem.is_goal_state(cur_game_state): Returns a bool indicating whether or not this game state is a goal state
		2. self.evaluation_function(cur_game_state, problem): Returns the evaluation score for cur_game_state
		3. problem.get_actions(agent_index, game_state): Returns a list of valid actions for the specified agent (through agent index) as per the game_state passed. Iterate through the actions in order provided by this only. If two actions give same value then the one ordered early in this list will be prioritized.
		4. problem.get_num_agents(): Returns the total no. of agents (player + ghost, player is agent_index 0 and ghosts are indexed 1,2,..,num_agents)
		5. problem.get_next_game_state(agent_index, cur_game_state, action): Returns the next game state if given agent_index takes given action in cur_game_state. Call this exactly once for each cur_game_state, action pair for an agent_index.
		'''

		'''***YOUR CODE HERE***'''
		def minimax(agent_index, cur_game_state, cur_depth, problem):
			if cur_depth == self.depth or problem.is_goal_state(cur_game_state):
				pass

			pass
			
		pass

		raise utils.MethodNotImplementedError('act')

class AlphaBetaAgent:
	def __init__(self, args):
		self.evaluation_function = getattr(evaluationFunctions, args['evaluation_function'])
		self.depth = args['depth']

	'''
	Question 3: AlphaBeta Pruning
	Implement a AlphaBeta agent that selects the action which gives it best overall evaluation after simulating the game with Minimax algorithm upto 'self.depth' plies, evaluating naively on score evaluation function, but additionally applies alpha- beta pruning to avoid generating states that are guaranteed not to contribute to the answer.
	'''		
	@utils.timeout(gameSettings.timeout_duration)
	def act(self, agent_index, game_state, problem):
		'''
		args:- 
		1. agent_index: This shall always be 0 for player agent and 1 onwards for each ghost agents
		2. game_state: The current configuration of the game board (as rendered on screen)
		3. problem: The problem instance, offers several helpful method calls


		Methods you might find useful:-
		1. problem.is_goal_state(cur_game_state): Returns a bool indicating whether or not this game state is a goal state
		2. self.evaluation_function(cur_game_state, problem): Returns the evaluation score for cur_game_state
		3. problem.get_actions(agent_index, game_state): Returns a list of valid actions for the specified agent (through agent index) as per the game_state passed. Iterate through the actions in order provided by this only. If two actions give same value then the one ordered early in this list will be prioritized.
		4. problem.get_num_agents(): Returns the total no. of agents (player + ghost, player is agent_index 0 and ghosts are indexed 1,2,..,num_agents)
		5. problem.get_next_game_state(agent_index, cur_game_state, action): Returns the next game state if given agent_index takes given action in cur_game_state. Call this exactly once for each cur_game_state, action pair for an agent_index.

		Note: Do not prune on equality to ensure compatibility with autograder!
		'''

		'''***YOUR CODE HERE***'''
		def alphabeta(agent_index, cur_game_state, cur_depth, problem, alpha, beta):
			if cur_depth == self.depth or problem.is_goal_state(cur_game_state):
				pass

			pass
			
		pass
		
		raise utils.MethodNotImplementedError('act')


class ExpectimaxAgent:
	def __init__(self, args):
		self.evaluation_function = getattr(evaluationFunctions, args['evaluation_function'])
		self.depth = args['depth']

	'''
	Question 4: Expectimax
	Implement a Expectimax agent that selects the action which gives it best overall evaluation after simulating the game with expectimax algorithm upto 'self.depth' plies, evaluating naively on score evaluation function.
	'''	
	@utils.timeout(gameSettings.timeout_duration)	
	def act(self, agent_index, game_state, problem):
		'''
		args:- 
		1. agent_index: This shall always be 0 for player agent and 1 onwards for each ghost agents
		2. game_state: The current configuration of the game board (as rendered on screen)
		3. problem: The problem instance, offers several helpful method calls


		Methods you might find useful:-
		1. problem.is_goal_state(cur_game_state): Returns a bool indicating whether or not this game state is a goal state
		2. self.evaluation_function(cur_game_state, problem): Returns the evaluation score for cur_game_state
		3. problem.get_actions(agent_index, game_state): Returns a list of valid actions for the specified agent (through agent index) as per the game_state passed. Iterate through the actions in order provided by this only. If two actions give same value then the one ordered early in this list will be prioritized.
		4. problem.get_num_agents(): Returns the total no. of agents (player + ghost, player is agent_index 0 and ghosts are indexed 1,2,..,num_agents)
		5. problem.get_next_game_state(agent_index, cur_game_state, action): Returns the next game state if given agent_index takes given action in cur_game_state. Call this exactly once for each cur_game_state, action pair for an agent_index.
		'''

		'''***YOUR CODE HERE***'''
		def expectimax(agent_index, cur_game_state, cur_depth, problem):
			if cur_depth == self.depth or problem.is_goal_state(cur_game_state):
				pass

			pass
			
		pass
		
		raise utils.MethodNotImplementedError('act')

class ExpectimaxAgentWithCache:
	def __init__(self, args):
		self.evaluation_function = getattr(evaluationFunctions, args['evaluation_function'])
		self.depth = args['depth']
		self.cache = dict()		# use this to memoize the results of expectimax

	'''
	Question 5: Faster Expectimax
	Implement a Expectimax agent that selects the action which gives it best overall evaluation after simulating the game with expectimax algorithm upto 'self.depth' plies, evaluating naively on score evaluation function. However, it shoudl cache the results to avoid repeated calculations.
	'''		
	@utils.timeout(gameSettings.timeout_duration)
	def act(self, agent_index, game_state, problem):
		'''
		args:- 
		1. agent_index: This shall always be 0 for player agent and 1 onwards for each ghost agents
		2. game_state: The current configuration of the game board (as rendered on screen)
		3. problem: The problem instance, offers several helpful method calls


		Methods you might find useful:-
		1. problem.is_goal_state(cur_game_state): Returns a bool indicating whether or not this game state is a goal state
		2. self.evaluation_function(cur_game_state, problem): Returns the evaluation score for cur_game_state
		3. problem.get_actions(agent_index, game_state): Returns a list of valid actions for the specified agent (through agent index) as per the game_state passed. Iterate through the actions in order provided by this only. If two actions give same value then the one ordered early in this list will be prioritized.
		4. problem.get_num_agents(): Returns the total no. of agents (player + ghost, player is agent_index 0 and ghosts are indexed 1,2,..,num_agents)
		5. problem.get_next_game_state(agent_index, cur_game_state, action): Returns the next game state if given agent_index takes given action in cur_game_state. Call this exactly once for each cur_game_state, action pair for an agent_index.
		'''

		'''***YOUR CODE HERE***'''

		def expectimax(agent_index, cur_game_state, cur_depth, problem):
			pass

		pass
		
		return utils.MethodNotImplementedError('act')


'''
Question 6: Implement the act method as per your choice, either using AlphaBeta or ExpectimaxWithCache or something even cleverer, just keep in mind the following:-
1. Time limit per call to act is 1s.
2. self.evaluation_function redirects to better_evaluation_function(game_state, problem, helper_cache = None) in evaluationFunctions.py, so write your logic there. The helper_cache may also be helpful in caching some results specific to evaluation of specific game states. (Some hints provided there to guide you)
3. The ghost agents will be DirectionalGhostAgents with epsilon of 0.5. This may let you decide on the algorithm to use in act method.
4. Use self.evaluation_cache to pass to evaluation function (if you want) and self.cache to memoize recursive calls (again, if you want), or you may define your custom data structures if you do not want to use these, but make sure to manage all the things understanding the above three points.

=> We will run your game on mediumClassic.lay 10 times and we shall follow the following grading scheme:-
1. <5 games won: 0 marks
2. >=5 games won:-
	2.1. average of top 5 games < 500: 3 marks
	2.2. 500 <= average of top 5 games < 600: 5 marks
	2.3. 600 <= average of top 5 games: 6 marks
'''
class CreativeAgent:
	def __init__(self, args):
		self.evaluation_function = getattr(evaluationFunctions, args['evaluation_function'])
		self.depth = args['depth']
		self.cache = dict()
		self.evaluation_cache = dict()

		'''
		If needed , define your own members here. If you need to pass some extra arguments to evaluation function (like current depth), you can use something like self.evaluation_cache['depth'] = cur_depth. It is all upto you how to use these objects and anymore you want to design.
		'''

	@utils.timeout(gameSettings.timeout_duration)
	def act(self, agent_index, game_state, problem):
		'''
		args:- 
		1. agent_index: This shall always be 0 for player agent and 1 onwards for each ghost agents
		2. game_state: The current configuration of the game board (as rendered on screen)
		3. problem: The problem instance, offers several helpful method calls


		Methods you might find useful:-
		1. problem.is_goal_state(cur_game_state): Returns a bool indicating whether or not this game state is a goal state
		2. self.evaluation_function(cur_game_state, problem): Returns the evaluation score for cur_game_state
		3. problem.get_actions(agent_index, game_state): Returns a list of valid actions for the specified agent (through agent index) as per the game_state passed. Iterate through the actions in order provided by this only. If two actions give same value then the one ordered early in this list will be prioritized.
		4. problem.get_num_agents(): Returns the total no. of agents (player + ghost, player is agent_index 0 and ghosts are indexed 1,2,..,num_agents)
		5. problem.get_next_game_state(agent_index, cur_game_state, action): Returns the next game state if given agent_index takes given action in cur_game_state. Call this exactly once for each cur_game_state, action pair for an agent_index.
		'''

		'''***YOUR CODE HERE***'''

		raise utils.MethodNotImplementedError('act')
