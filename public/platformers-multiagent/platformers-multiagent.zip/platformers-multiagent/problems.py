import utils
import gameState
import game
import playerAgents, ghostAgents
import ghostRules, playerRules
import costFunctions
import pygame
import gameSettings
import numpy as np

class PlatformersMultiagentSearchProblem:

	def __init__(self, args):
		assert 'fix_seed' in args
		self.fix_seed_value = args['fix_seed']
		self.problemRNG = np.random.default_rng(seed = args['fix_seed'])

		layout = utils.parse(args['layout_filename'])
		self.graphics_enabled = not args['no_graphics']
		self.game_state = gameState.GameState(layout)
		self.num_ghosts = len(self.game_state.ghosts_details)
		self.cost_function = getattr(costFunctions, args['cost_function'])
		self.ghost_rules = ghostRules.GhostRules(self.game_state.num_rows, self.game_state.num_cols, self.cost_function)
		self.player_rules = playerRules.PlayerRules(self.game_state.num_rows, self.game_state.num_cols, self.cost_function)
		self.score = 0

		if args['player_agent']=='KeyboardAgent' and not self.graphics_enabled:
			assert False
		
		player_args = {'evaluation_function': args['evaluation_function'], 'depth': args['depth'], 'rng': self.problemRNG}
		self.player_agent = getattr(playerAgents, args['player_agent'])(player_args)
		ghost_args = {'evaluation_function': gameSettings.default_eval_fn, 'depth': args['depth'], 'epsilon': args['epsilon'], 'rng': self.problemRNG}
		self.ghost_agent = getattr(ghostAgents, args['ghost_agent'])(ghost_args)

		self.generated_nodes_count_one_action = 0
		self.num_generated_per_action = []
		self.actions = []

	def solve(self):
		result = False, 0  			# assumes not won, and 0 points

		if self.graphics_enabled:
			self.game = game.Game(self.num_ghosts, self.game_state.num_rows, self.game_state.num_cols, self.game_state.blocks_pos, self.game_state.foods_pos, self.game_state.freezers_pos, self.game_state.player_details.pos, [ghost_details.pos for ghost_details in self.game_state.ghosts_details], self.score, self.fix_seed_value)
			self.game.init_offset(self.game_state.player_details.pos)
			result = self.solve_with_graphics()
		else:
			result = self.solve_no_graphics()

		return result

	def solve_with_graphics(self):
		run = True
		clock = pygame.time.Clock()
		self.game.draw()
		pygame.display.update()
		won = False
		while run:
			clock.tick(gameSettings.FPS)
			for event in pygame.event.get():
				if event.type == pygame.QUIT:
					run = False
					break

			done = self.game.handle_action_locking(self)	# the game checks if animation from last action is pending, if yes then continues that animation
			self.game.draw()

			pygame.display.update()
			if done:
				run = False
				if len(self.game_state.foods_pos)==0:
					print(f"You won!\tScore: {self.score}\tTotal expanded: {sum(self.num_generated_per_action)}")
					won = True
				else:
					print(f"You lost!\tScore: {self.score}\tTotal expanded: {sum(self.num_generated_per_action)}")
					won = False
				break
		pygame.quit()
		return won, self.score

	def solve_no_graphics(self):
		while not self.game_state.is_goal_state():

			cur_game_state = self.game_state
			

			player_action = self.player_agent.act(0, cur_game_state, self)
			
			# for autograding  
			self.actions.append(player_action)
			self.num_generated_per_action.append(self.generated_nodes_count_one_action)
			self.generated_nodes_count_one_action = 0


			next_game_state, traced_path, food_indices_eaten_at_index_of_traced_path, freezer_indices_eaten_at_index_of_traced_path, inactive_ghost_indices_eaten_at_index_of_traced_path, active_ghost_indices_eaten_at_index_of_traced_path = self.player_rules.get_next_game_state(cur_game_state, player_action)
			self.score -= self.cost_function(0, cur_game_state, player_action, next_game_state)
			cur_game_state = next_game_state
			
			if not cur_game_state.is_goal_state():
				for i in range(self.num_ghosts):
					
					ghost_action = self.ghost_agent.act(i+1, cur_game_state, self)
					next_game_state, traced_path, player_eaten_at_index_of_traced_path = self.ghost_rules.get_next_game_state(i+1, cur_game_state, ghost_action)
					self.score -= self.cost_function(i+1, cur_game_state, player_action, next_game_state)
					cur_game_state = next_game_state
			
					if cur_game_state.is_goal_state():
						self.game_state = cur_game_state
						break
			else:
				self.game_state = cur_game_state
				break
			self.game_state = cur_game_state
		if len(self.game_state.foods_pos)==0:
			print(f"You won!\tScore: {self.score}\tTotal expanded: {sum(self.num_generated_per_action)}")
			won = True
		else:
			print(f"You lost!\tScore: {self.score}\tTotal expanded: {sum(self.num_generated_per_action)}")
			won = False
		return won, self.score

	def get_actions(self, agent_index, game_state):
		if agent_index == 0:
			return self.player_rules.get_actions(game_state)
		else:
			return self.ghost_rules.get_actions(agent_index, game_state)

	def get_num_ghosts(self):
		return self.num_ghosts

	def get_num_agents(self):
		return 1 + self.get_num_ghosts()

	def is_goal_state(self, game_state):
		return game_state.is_goal_state()

	def get_next_game_state(self, agent_index, game_state, action):
		self.generated_nodes_count_one_action += 1
		if agent_index == 0:
			return self.player_rules.get_next_game_state(game_state, action)[0]
		else:
			return self.ghost_rules.get_next_game_state(agent_index, game_state, action)[0]

	def get_actions_from_player_pos(self, player_pos):
		# these members accesses from game_state do not change and hence it can be accessed from any instance
		return self.player_rules.get_actions_from_player_pos(player_pos, self.game_state.blocks_pos)


	def get_next_pos_from_player_pos_and_action(self, player_pos, action):

		traced_path = [player_pos] + [(player_pos[0]+neigh_pos[0], player_pos[1]+neigh_pos[1]) for neigh_pos in self.player_rules.check_empty_positions[action]]

		
		next_pos = traced_path[-1]
		# these members accesses from game_state do not change and hence it can be accessed from any instance
		while next_pos[0]+1<self.game_state.num_rows and (next_pos[0]+1,next_pos[1]) not in self.game_state.blocks_pos:
			next_pos = (next_pos[0]+1,next_pos[1])
			traced_path.append(next_pos)
		return next_pos, traced_path

	def get_actions_from_ghost_pos(self, ghost_pos):
		return self.ghost_rules.get_actions_from_ghost_pos(ghost_pos, self.game_state.blocks_pos)

	def get_next_pos_from_ghost_pos_and_action(self, ghost_pos, action):

		traced_path = [ghost_pos] + [(ghost_pos[0]+neigh_pos[0], ghost_pos[1]+neigh_pos[1]) for neigh_pos in self.ghost_rules.check_empty_positions[action]]

		
		next_pos = traced_path[-1]
		# these members accesses from game_state do not change and hence it can be accessed from any instance
		while next_pos[0]+1<self.game_state.num_rows and (next_pos[0]+1,next_pos[1]) not in self.game_state.blocks_pos:
			next_pos = (next_pos[0]+1,next_pos[1])
			traced_path.append(next_pos)
		return next_pos, traced_path



class GraphGameTree:
	# only the first action returned by the player is important
	def __init__(self, args):
		player_agent_args = {	'evaluation_function': 	"graph_game_tree_evaluation_function",
								'depth': 				args['depth']
							}
		self.player_agent = getattr(playerAgents, args['player_agent'])(player_agent_args)
		self.num_agents = args['num_agents']
		self.start_state = args['start_state']
		self.win_states = args['win_states']
		self.lose_states = args['lose_states']
		self.default_evaluation = args['default_evaluation']
		self.adjlist = args['adjlist']
		self.evaluation = args['evaluation']

		self.cur_game_state = self.start_state
		self.generated = [self.cur_game_state]

		# the start state is agent_index 0, and all the states there after are agent_index 1,2,.,num_agents-1
		# no problem as here the state and the agents are the same, so action to take comes solely from the state information

	def solve(self):
		# apply only one ply
		assert not self.is_goal_state(self.start_state)
		
		action = self.player_agent.act(0, self.cur_game_state, self)

		return action

	def get_actions(self, agent_index, game_state):
		# actions depend only on game_state as we have a direct mapping
		return [action for action, next_state in self.adjlist[game_state]]

	def get_num_agents(self):
		return self.num_agents

	def is_goal_state(self, game_state):
		return game_state in self.win_states or game_state in self.lose_states

	def get_next_game_state(self, agent_index, game_state, action):
		for succ_action, succ_next_state in self.adjlist[game_state]:
			if action == succ_action:
				self.generated.append(succ_next_state)
				return succ_next_state
		assert False