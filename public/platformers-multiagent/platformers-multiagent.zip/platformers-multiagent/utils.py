import heapq
import os
import ast
import signal, time 
import traceback

class Stack:
    def __init__(self):
        self.list = []

    def push(self,item):
        self.list.append(item)

    def pop(self):
        return self.list.pop()

    def isEmpty(self):
        return len(self.list) == 0

class Queue:
    def __init__(self):
        self.list = []

    def push(self,item):
        self.list.insert(0,item)

    def pop(self):
        return self.list.pop()

    def isEmpty(self):
        return len(self.list) == 0

class PriorityQueue:
    def  __init__(self):
        self.heap = []
        self.count = 0

    def push(self, item, priority):
        entry = (priority, self.count, item)
        heapq.heappush(self.heap, entry)
        self.count += 1

    def pop(self):
        (_, _, item) = heapq.heappop(self.heap)
        return item

    def isEmpty(self):
        return len(self.heap) == 0

    def update(self, item, priority):
        for index, (p, c, i) in enumerate(self.heap):
            if i == item:
                if p <= priority:
                    break
                del self.heap[index]
                self.heap.append((priority, c, item))
                heapq.heapify(self.heap)
                break
        else:
            self.push(item, priority)


def get_function_names(file_name):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(script_dir, file_name)
    with open(path, "r") as file:
        tree = ast.parse(file.read(), filename=path)

    function_names = [node.name for node in ast.walk(tree) if isinstance(node, ast.FunctionDef)]

    return function_names

def get_files_in_dir(dir):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(script_dir,dir)
    return [file for file in os.listdir(path) if os.path.isfile(os.path.join(path, file))]

def get_dirs_in_dir(dir):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(script_dir,dir)
    entries = os.listdir(path)
        
    # Filter out and list only directories
    directories = [entry for entry in entries if os.path.isdir(os.path.join(path, entry))]
    return directories

def get_class_names(file_name):
    script_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(script_dir, file_name)
    with open(path, "r") as file:
        file_content = file.read()

    # Parse the file content into an AST
    parsed_ast = ast.parse(file_content)

    # Extract all class definitions
    class_names = [node.name for node in ast.walk(parsed_ast) if isinstance(node, ast.ClassDef)]
    
    return class_names

def manhattan_distance( xy1, xy2 ):
    "Returns the Manhattan distance between points xy1 and xy2"
    return abs( xy1[0] - xy2[0] ) + abs( xy1[1] - xy2[1] )

def parse(layout_filename):
    layout = list()
    script_dir = os.path.dirname(os.path.abspath(__file__))
    path = os.path.join(script_dir, "layouts",layout_filename)
    fh = open(path, "r")
    for line in fh:
        layout.append(list())
        for char in line:
            if char == '.':
                layout[-1].append('.')
            elif char == 'B':
                layout[-1].append('B')
            elif char == 'D':
                layout[-1].append('D')
            elif char == 'P':
                layout[-1].append('P')
            elif char == 'G':
                layout[-1].append('G')
            elif char == 'F':
                layout[-1].append('F')

    return layout

def get_all_indices(lst, element):
    return [i for i, x in enumerate(lst) if x == element]


'''returns distance to the nearest'''
def graph_distance_bfs(main_pos, others_pos, problem):
    queue = Queue()
    queue.push((main_pos, 0))
    visited = set()
    visited.add(main_pos)
    while not queue.isEmpty():
        cur_pos, moves_till_now = queue.pop()
        if cur_pos in others_pos:
            return moves_till_now
        actions = problem.get_actions_from_player_pos(cur_pos)
        for action in actions:
            next_pos, _ = problem.get_next_pos_from_player_pos_and_action(cur_pos, action)
            if next_pos not in visited:
                visited.add(next_pos)
                queue.push((next_pos, moves_till_now + 1))

    return -1

'''ans_dict is passed by reference'''
def single_player_source_all_pos_dist(source_pos, problem):
    queue = Queue()
    queue.push((source_pos, 0, True))
    visited = set()
    visited.add((source_pos, True))
    ans_dict = dict()
    while not queue.isEmpty():
        cur_pos, moves_till_now, valid = queue.pop()
        if cur_pos not in ans_dict:
            ans_dict[cur_pos] = moves_till_now
        if valid:
            actions = problem.get_actions_from_player_pos(cur_pos)
            for action in actions:
                assert action is not None
                next_pos, traced_path = problem.get_next_pos_from_player_pos_and_action(cur_pos, action)
                for temp_pos in traced_path[:-1]:
                    if (temp_pos, False) not in visited:
                        visited.add((temp_pos, False))
                        queue.push((temp_pos, moves_till_now + 1, False))
                else:
                    if (next_pos, True) not in visited:
                        visited.add((next_pos, True))
                        queue.push((next_pos, moves_till_now + 1, True))

    return ans_dict

def single_ghost_source_all_pos_dist(source_pos, problem):
    queue = Queue()
    queue.push((source_pos, 0))
    visited = set()
    visited.add(source_pos)
    ans_dict = dict()
    while not queue.isEmpty():
        cur_pos, moves_till_now = queue.pop()

        ans_dict[cur_pos] = moves_till_now
        actions = problem.get_actions_from_ghost_pos(cur_pos)
        for action in actions:
            assert action is not None
            next_pos, traced_path = problem.get_next_pos_from_ghost_pos_and_action(cur_pos, action)
            if next_pos not in visited:
                visited.add(next_pos)
                queue.push((next_pos, moves_till_now + 1))

    return ans_dict


class TestFailureError(Exception):
    def __init__(self, error_message, error_code):
        super().__init__(error_message)
        self.error_code = error_code

    def __str__(self):
        return f"[Error {self.error_code}]: {self.args[0]}"


class TimeoutException(Exception):
    pass

def timeout(seconds):
    assert seconds > 0
    def decorator(func):
        def _handle_timeout(signum, frame):
            raise TimeoutException(f"Function '{func.__name__}' timed out after {seconds} seconds")

        def wrapper(*args, **kwargs):
            if hasattr(signal, 'SIGALRM'):
                # works on linux
                # Set up signal handler for the timeout
                signal.signal(signal.SIGALRM, _handle_timeout)
                # Schedule an alarm
                signal.alarm(seconds)
                try:
                    result = func(*args, **kwargs)
                finally:
                    # Disable the alarm
                    signal.alarm(0)
                return result
            else:
                # for windows
                start = time.time()
                result = func(*args, **kwargs)
                time_taken = time.time() - start
                if time_taken > seconds:
                    _handle_timeout(None, None)
                return result
            
        return wrapper
    return decorator


class MethodNotImplementedError(NotImplementedError):
    def __init__(self, method_name):
        stack = traceback.extract_stack()[-2]  # Get the second-last call in the stack
        file_name = stack.filename
        line_number = stack.lineno

        # Construct the error message
        error_message = (f"The method '{method_name}' is not implemented.\n"
                         f"File: {file_name}, Line: {line_number}")
        
        super().__init__(error_message)

def print_exception(exception):
    if isinstance(exception, TimeoutException) or isinstance(exception, MethodNotImplementedError) or isinstance(exception, TestFailureError):
        for line in exception.__str__().splitlines():
            print(f"*** {line}")
    else:
        full_traceback = traceback.format_exc()					
        for line in full_traceback.splitlines():
            print(f"*** {line}")