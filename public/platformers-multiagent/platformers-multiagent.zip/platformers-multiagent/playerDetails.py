import gameSettings

class PlayerDetails:

	def __init__(self, index, pos):
		self.index = index
		self.pos = pos
		self.facing = gameSettings.default_facing
		self.alive = True

	def __str__(self):
		return f"index-{self.index} pos-{self.pos} facing-{self.facing} alive-{self.alive}"

	def deep_copy(self):
		copy_player_details = PlayerDetails(self.index, self.pos)
		copy_player_details.facing = self.facing
		copy_player_details.alive = self.alive
		return copy_player_details

	def __eq__(self, other):
		if isinstance(other, PlayerDetails):
			return self.index == other.index and self.pos == other.pos and self.facing == other.facing and self.alive == other.alive

		return False

	def __hash__(self):
		return hash((self.index, self.pos, self.facing, self.alive))