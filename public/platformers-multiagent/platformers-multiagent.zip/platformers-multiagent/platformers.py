import argparse, sys
import gameSettings
import numpy as np
import problems
import utils


def main():
	defined_cost_functions = utils.get_function_names(gameSettings.cost_functions_file_name)
	defined_layouts = utils.get_files_in_dir("layouts")
	defined_agents = utils.get_class_names(gameSettings.player_agents_file_name)
	defined_ghost_agents = utils.get_class_names(gameSettings.ghost_agents_file_name)
	defined_evaluation_functions = utils.get_function_names(gameSettings.evaluation_functions_file_name)
	arg_parser = argparse.ArgumentParser(description='Play the game of Platformers. Run "python3 platformers.py -h" to view the list of argument options available')

	# Define the expected command-line arguments
	arg_parser.add_argument('--layout', type=str, help='Specify the layout(.lay file) of the game.', default=gameSettings.default_layout, choices = defined_layouts)
	arg_parser.add_argument('--playerAgent', type=str, help='Specify the type of agent to use', default=gameSettings.default_player_agent, choices=defined_agents)
	arg_parser.add_argument('--costFn', type=str, help='Specify the cost function for the player', default=gameSettings.default_cost_function, choices = defined_cost_functions)
	arg_parser.add_argument('--ghostAgent', type=str, help='Specify the number of ghosts', default=gameSettings.default_ghost_agent, choices = defined_ghost_agents)
	arg_parser.add_argument('--fixSeed', type=int, help='Specify the fix seed for the game')
	arg_parser.add_argument('--noGraphics', action='store_true', help='Disable the display')
	arg_parser.add_argument('--evalFn', type=str, help='Specify the evaluation function to use', default=gameSettings.default_eval_fn, choices = defined_evaluation_functions)
	arg_parser.add_argument('--depth', type=lambda x: int(x) if int(x) > 0 else argparse.ArgumentTypeError("Depth must be greater than 0"), help='Specify the depth of search for Minimax Search Agent', default=gameSettings.default_search_depth)
	arg_parser.add_argument('--epsilon', type=float, help='Specify the probability of best action towards the ghost', default=gameSettings.default_epsilon_value)
	arg_parser.add_argument('--test', type = int, help='Number of games to test on', default = 1)


	args = arg_parser.parse_args()

	layout_filename = args.layout
	player_agent = args.playerAgent
	cost_function = args.costFn
	ghost_agent = args.ghostAgent
	no_graphics = args.noGraphics
	evaluation_function = args.evalFn
	depth = args.depth
	epsilon = args.epsilon
	test = args.test
	problem_args = {'layout_filename': layout_filename, 
					'player_agent': player_agent,
					'cost_function': cost_function,
					'ghost_agent': ghost_agent,
					'no_graphics': no_graphics,
					'evaluation_function': evaluation_function,
					'depth': depth,
					'epsilon': epsilon
					}
	if args.fixSeed is not None:
		assert 0<=args.fixSeed<=2**32-1, "Seed value must be between 0 and 2**32-1"
		simpleRNG = np.random.default_rng(seed = args.fixSeed)
	else:
		simpleRNG = np.random.default_rng()	# undetermined seed


	# Using the seed parameter in numpy.random.default_rng() will ensure reproducible results even if the host machine is changed, as long as the same version of NumPy and the same random number generator are used.

	for i in range(test):
		problem_args['fix_seed'] = simpleRNG.integers(0, 2**32)
		problem = problems.PlatformersMultiagentSearchProblem(problem_args)
		try:
			problem.solve()
		except Exception as e:
			utils.print_exception(e)
			sys.exit(1)

if __name__ == "__main__":
	main()