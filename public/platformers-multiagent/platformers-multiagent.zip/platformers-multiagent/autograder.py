import utils
import argparse
import os, sys
import re
import problems
import gameSettings
import numpy as np

def parse_test_file(file_path):
	with open(file_path, 'r') as file:
		content = file.read()

	# Remove comments
	content = re.sub(r'#.*', '', content)

	# Extract key-value pairs enclosed in triple or double quotes
	matches = re.findall(r'(\w+):\s*("""(?:.|\n)*?"""|".*?")', content)
	# Process the matches into a dictionary
	parsed_data = {}
	for key, value in matches:
		# Strip the quotes from the value
		value = value.strip('"')
		parsed_data[key] = value
	return parsed_data

def parse_graph(graph_str):
	lines = graph_str.split("\n")
	adjlist = dict()
	for line in lines:
		stripped_line = line.strip()
		if len(stripped_line)>0:
			try:
				state, action, next_state = stripped_line.split(' ')	# if successor is invalid will lead to value error 
			except ValueError:
				print(f'*** The .test file is not valid')
				sys.exit(1)

			if state not in adjlist:
				adjlist[state] = []

			adjlist[state].append((action, next_state))
	return adjlist

def parse_evaluation(evaluation_str):
	cache = dict()
	lines = evaluation_str.split("\n")
	for line in lines:
		stripped_line = line.strip()
		if len(stripped_line)>0:
			try:
				state, evaluation_val = stripped_line.split()
			except ValueError:
				print(f'*** The .test file is not valid')
				sys.exit(1)
			state = state.strip()
			evaluation_val = float(evaluation_val.strip())
			cache[state] = evaluation_val
	return cache

def parse_limits_data(limits_str):
	cache = dict()
	lower_bounds = list()
	lines = limits_str.split("\n")
	for line in lines:
		stripped_line = line.strip()
		if len(stripped_line)>0:
			lower_bound, grade = stripped_line.split()
			lower_bound = int(lower_bound.strip())
			grade = float(grade.strip())
			cache[lower_bound] = grade
			lower_bounds.append(lower_bound)
	return cache, lower_bounds

class PlatformersMultiagentSearchProblemTester:
	def __init__(self, question_data, solution_data):
		self.question_data = question_data
		self.solution_data = solution_data

	def get_problem_args(self):
		args = {	'no_graphics': not display,
					'layout_filename': self.question_data['layoutName'],
					'cost_function': self.question_data['costFn'],
					'evaluation_function': self.question_data['evalFn'],
					'depth': self.question_data['depth'],
					'player_agent': self.question_data['playerAgent'],
					'epsilon': self.question_data['ghostEpsilon'],
					'ghost_agent': self.question_data['ghostAgent'],
				}
		return args

	def test(self, scheme):
		simpleRNG = np.random.default_rng(seed = self.question_data['fixSeed'])
		args = self.get_problem_args()

		total_won_scores = []
		total_wins = 0 
		for i in range(self.question_data['numGames']):
			args['fix_seed'] = simpleRNG.integers(0, 2**32)
			problem = problems.PlatformersMultiagentSearchProblem(args)
			try:
				won, score = problem.solve()
			except Exception as e:
				utils.print_exception(e)
				return 0
			if won:
				total_wins += 1
				total_won_scores.append(score)

		if scheme == "strict":
			# problem is defined as only one problem as numGames is set to 1 in validate
			correct_actions = self.solution_data['actions'].split(' ')
			correct_generated_states_count = list(map(int, self.solution_data['generatedStatesCount'].split(' ')))
			actions = problem.actions
			generated_states_count = problem.num_generated_per_action
			if correct_actions != actions or correct_generated_states_count != generated_states_count:
				print(f"Student's optimal actions: {actions}\nCorrect optimal actions: {correct_actions}\nStudent's generated states count: {generated_states_count}\nCorrect generated states count: {correct_generated_states_count}")
				return 0
			return 1
		else:
			grade_dict_lower_bounds, lower_bounds = parse_limits_data(self.question_data["winsThresholds"])
			if self.question_data['playerAgent'] == "ReflexAgent":
				print(f'\nGrading Scheme:-\n{self.question_data["winsThresholdsStr"]}')
				for i, lower_bound in enumerate(lower_bounds):
					if total_wins < lower_bound:
						if i>0:
							print(f'\n*** Games passed: {total_wins}\nProviding Partial Marks: {grade_dict_lower_bounds[lower_bounds[i-1]]}')

							return grade_dict_lower_bounds[lower_bounds[i-1]]
						else:
							print(f'\n*** Games passed: {total_wins}\nProviding Partial Marks: 0')

							return 0
				else:
					print(f'\nGames won: {total_wins}\nProviding Full Marks: {grade_dict_lower_bounds[lower_bound]}')
					return grade_dict_lower_bounds[lower_bound]
	
			elif self.question_data['playerAgent'] == "CreativeAgent":
				print(f'\nGrading Scheme:-\nGames Won:-\n{self.question_data["winsThresholdsStr"]}\nAverage of top 5 won:-\n{self.question_data["avgThresholdsStr"]}')
				
				grade_dict_avg_score, avg_score_lower_bounds = parse_limits_data(self.question_data["avgThresholds"])
				assert len(lower_bounds) == 1 
				if total_wins >= lower_bounds[0]:
					secured = grade_dict_lower_bounds[lower_bounds[0]]
					avg_top_5 = sum(sorted(total_won_scores, reverse=True)[:5])/5
					for i, lower_bound in enumerate(avg_score_lower_bounds):
						if avg_top_5 < lower_bound:
							if i>0:
								print(f'\n*** Games won: {total_wins}\nWon Game Scores: {total_won_scores}\nAverage of top 5 won games: {avg_top_5}\nProviding Partial Marks: {grade_dict_avg_score[avg_score_lower_bounds[i-1]]}')

								return grade_dict_avg_score[avg_score_lower_bounds[i-1]]
							else:
								print(f'\n*** Games won: {total_wins}\nWon Game Scores: {total_won_scores}\nAverage of top 5 won games: {avg_top_5}\nProviding Partial Marks: {secured}')

							return secured
					else:
						print(f'\nGames won: {total_wins}\nWon Game Scores: {total_won_scores}\nAverage of top 5: {avg_top_5}\nProviding Full Marks: {grade_dict_avg_score[lower_bound]}')
						return grade_dict_avg_score[lower_bound]		
				else:
					print(f'\n*** Games Won: {total_wins}\nProviding Partial Marks: 0')
					return 0

	def validate_solution(self, scheme):
		if scheme == "strict":
			assert 'actions' in self.solution_data
			assert 'generatedStatesCount' in self.solution_data
			assert '\n' not in self.solution_data['actions']
			assert '\n' not in self.solution_data['generatedStatesCount']

	def validate_question(self, scheme):
		defined_layouts = utils.get_files_in_dir("layouts")
		defined_player_agents = utils.get_class_names(gameSettings.player_agents_file_name)
		defined_ghost_agents = utils.get_class_names(gameSettings.ghost_agents_file_name)
		defined_evaluation_functions = utils.get_function_names(gameSettings.evaluation_functions_file_name)
		assert "layoutName" in self.question_data and "playerAgent" in self.question_data and self.question_data["playerAgent"] != "KeyboardAgent" and self.question_data['layoutName'] in defined_layouts and self.question_data['playerAgent'] in defined_player_agents

		self.question_data['costFn'] = gameSettings.default_cost_function
		
		if 'evalFn' in self.question_data:
			assert self.question_data['evalFn'] in defined_evaluation_functions, "The evaluation function is not defined"
		else:
			self.question_data['evalFn'] = gameSettings.default_eval_fn
		if 'depth' not in self.question_data:
			self.question_data['depth'] = gameSettings.default_search_depth
		self.question_data['depth'] = int(self.question_data['depth'])
		assert self.question_data['depth'] > 0
		if 'ghostEpsilon' in self.question_data:
			assert float(self.question_data['ghostEpsilon']) <= 1 and float(self.question_data['ghostEpsilon']) >=0, "The probability value is incorrect"
		else:
			self.question_data['ghostEpsilon'] = gameSettings.default_epsilon_value
			# else do nothing
		self.question_data['ghostEpsilon'] = float(self.question_data['ghostEpsilon'])
		assert self.question_data['ghostEpsilon']>=0 and self.question_data['ghostEpsilon']<=1

		if 'ghostAgent' not in self.question_data:
			self.question_data['ghostAgent'] = gameSettings.default_ghost_agent
		assert self.question_data['ghostAgent'] in defined_ghost_agents
		assert 'fixSeed' in self.question_data
		self.question_data['fixSeed'] = int(self.question_data['fixSeed'])
		assert 0<=self.question_data['fixSeed']<=2**32-1, "Seed must be between 0 and 2**32 - 1"

		if scheme == "strict":
			self.question_data['numGames'] = 1
		else:
			assert "winsThresholds" in self.question_data
			assert "winsThresholdsStr" in self.question_data
			assert 'numGames' in self.question_data and int(self.question_data['numGames']) > 0
			self.question_data['numGames'] = int(self.question_data['numGames'])
			if self.question_data['playerAgent'] == "CreativeAgent":
				assert "avgThresholds" in self.question_data and "avgThresholdsStr" in self.question_data

	def print_solution(self, scheme, solution_file_path):
		simpleRNG = np.random.default_rng(seed = self.question_data['fixSeed'])
		args = self.get_problem_args()
		for i in range(self.question_data['numGames']):
			args['fix_seed'] = simpleRNG.integers(0, 2**32)
			problem = problems.PlatformersMultiagentSearchProblem(args)
			try:
				problem.solve()
			except Exception as e:
				utils.print_exception(e)
				sys.exit(1)

		if scheme == "strict":
			# problem is defined, and only one problem as numGames is set to 1 in validate for strict
			actions = problem.actions
			generated_states_count = problem.num_generated_per_action
			fh = open(solution_file_path, "w")
			fh.write(f"actions: \"{' '.join(actions)}\"\n\ngeneratedStatesCount: \"{' '.join(map(str, generated_states_count))}\"")
			fh.close()

class GraphGameTreeTester:
	def __init__(self, question_data, solution_data):
		self.question_data = question_data
		self.solution_data = solution_data

	def get_problem(self):
		start_state = self.question_data['startState'].strip()
		win_states = self.question_data['winStates'].split(" ")
		lose_states = self.question_data['loseStates'].split(" ")
		default_evaluation = 0 	# for those states evaluation is not defined	
		adjlist = parse_graph(self.question_data["successors"])
		evaluation = parse_evaluation(self.question_data['evaluation'])
		args = {	'player_agent': 		self.question_data['playerAgent'].strip(),
					'depth':				self.question_data['depth'],
					'num_agents':			int(self.question_data['numAgents']),
					'start_state':			start_state,
					'win_states':			win_states,
					'lose_states':			lose_states,
					'default_evaluation':	default_evaluation,
					'adjlist':				adjlist,
					'evaluation':			evaluation
				}
		problem = problems.GraphGameTree(args)
		return problem

	def test(self):
		problem = self.get_problem()
		try:
			action = problem.solve()
		except Exception as e:
			utils.print_exception(e)
			return 0
		generated = problem.generated

		correct_action = self.solution_data['action'].strip()
		assert '\n' not in self.solution_data['generated']
		correct_generated = self.solution_data['generated'].split(' ')
		if action != correct_action or set(generated) != set(correct_generated):
			print(f"Student's action: {action}\nCorrect action: {correct_action}\nStudent's generated states: {' '.join(generated)}\nCorrect generated states: {' '.join(correct_generated)}\n{self.question_data['diagram']}")
			return 0
		return 1

	def validate_solution(self):
		assert 'action' in self.solution_data
		assert 'generated' in self.solution_data


	def validate_question(self):
		defined_player_agents = utils.get_class_names('playerAgents.py')
		assert 'playerAgent' in self.question_data
		assert self.question_data['playerAgent'] in defined_player_agents
		assert 'depth' not in self.question_data or int(self.question_data['depth'])>0
		assert 'numAgents' in self.question_data and int(self.question_data['numAgents'])>0
		assert 'startState' in self.question_data
		assert 'winStates' in self.question_data
		assert 'loseStates' in self.question_data
		assert 'successors' in self.question_data
		assert 'evaluation' in self.question_data
		if 'depth' not in self.question_data:
			self.question_data['depth'] = gameSettings.default_search_depth
		self.question_data['depth'] = int(self.question_data['depth'])

	def print_solution(self, solution_file_path):
		problem = self.get_problem()
		try:
			action = problem.solve()
		except Exception as e:
			utils.print_exception(e)
			sys.exit(1)
		generated = problem.generated

		fh = open(solution_file_path, "w")
		fh.write(f"action: \"{action}\"\n\ngenerated: \"{' '.join(generated)}\"")
		fh.close()

def run_one_test(test_dir, test_file_name, valid_problems, display, scheme, write_solution=False):
	# returns 1 if passed and scheme is strict
	# returns the scored point if the scheme is partial
	script_dir = os.path.dirname(os.path.abspath(__file__))
	path = os.path.join(script_dir,"test_cases",test_dir,test_file_name)

	test_case_name = test_file_name.split(".")[0]
	solution_file_path = os.path.join(script_dir,"test_cases",test_dir,test_case_name+".solution")
	question_data = parse_test_file(path)
	solution_data = parse_test_file(solution_file_path)

	assert "problem" in question_data, "The test file has no problem specified"
	result = 0
	print(f"Running test case {path}")
	
	if scheme == "strict":
		# returns 1 or 0 based on passed or failed
		if question_data["problem"]=="PlatformersMultiagentSearchProblem":

			tester = PlatformersMultiagentSearchProblemTester(question_data, solution_data)
			tester.validate_question(scheme)
			if not write_solution:
				tester.validate_solution(scheme)
				result = tester.test(scheme)
				if result == 1:
					print(f"{test_file_name} passed!")
				else:
					print(f"*** Test failed {test_file_name}")
			else:
				tester.print_solution(scheme, solution_file_path)

		elif question_data["problem"]=="GraphGameTree":
			tester = GraphGameTreeTester(question_data, solution_data)
			tester.validate_question()
			if not write_solution:
				tester.validate_solution()
				result = tester.test()
				if result == 1:
					print(f"{test_file_name} passed!")
				else:
					print(f"*** Test failed {test_file_name}")
			else:
				tester.print_solution(solution_file_path)
			
		else:
			assert False
			# check if problem is valid
	else:
		if question_data["problem"]=="PlatformersMultiagentSearchProblem":

			tester = PlatformersMultiagentSearchProblemTester(question_data, solution_data)
			tester.validate_question(scheme)
			if not write_solution:
				tester.validate_solution(scheme)
				result = tester.test(scheme)
		else:
			assert False

	print("-------------------------------------------------------------------")
	return result

		

def run_one_test_directory(test_dir, valid_problems, display, write_solution = False)->tuple:
	# path is test_cases/test_dir
	print(f"Testing {test_dir}.........")
	script_dir = os.path.dirname(os.path.abspath(__file__))
	path = os.path.join(script_dir,"test_cases",test_dir)

	# get the config details
	config_file_path = os.path.join(path, "CONFIG")
	config_file_data = parse_test_file(config_file_path)
	assert "scheme" in config_file_data
	if config_file_data['scheme'] == "strict":
		assert "maxPoints" in config_file_data
		total_points = int(config_file_data['maxPoints'])
		num_tests = 0
		num_tests_passed = 0
		for file in os.listdir(path):
			if file.endswith(".test"):
				num_tests += 1
				correct_pts = run_one_test(test_dir, file, valid_problems, display, "strict", write_solution)
				if correct_pts == 1:
					num_tests_passed += 1
		if num_tests_passed < num_tests:
			correct_points = 0
		else:
			correct_points = total_points
	else:
		assert 'maxPoints' in config_file_data, "The config file is not correct"
		total_points = float(config_file_data['maxPoints'])
		num_tests = 0
		correct_points = 0
		for file in os.listdir(path):
			if file.endswith(".test"):
				num_tests += 1
				correct_pts = run_one_test(test_dir, file, valid_problems, display, "partial", write_solution)
				correct_points += correct_pts
				
		assert correct_points <= total_points

	if not write_solution:
		print(f"Verdict: {test_dir} {'failed' if correct_points<total_points else 'passed'}\nPoints: {correct_points}/{total_points}")
	print("====================================================================")
	print()

	return total_points, correct_points



defined_tests = utils.get_dirs_in_dir("test_cases")
total_tests = len(defined_tests)

arg_parser = argparse.ArgumentParser(description='Run the test cases for your implementation. Run "python3 autograder.py -h" to view the list of argument options available')

# Define the expected command-line arguments
arg_parser.add_argument('-q', type=str, help='Specify the name of specific tests folder in test_cases', choices = defined_tests, nargs = '+')
arg_parser.add_argument('--test', type=str, help='Specify the name of specific tests folder followed by slash(/) followed by test case file name (Overrules -q argument)')
arg_parser.add_argument('--noGraphics', action='store_true', help='Disable graphics display')

# Parse the command-line arguments
args = arg_parser.parse_args()
print("Autograding in progress......\n")

valid_problems = utils.get_class_names("problems.py")
display = not args.noGraphics
onetest = args.test
write_solution = False
if not onetest:
	tests = args.q
	if tests is None:
		# run all the tests
		tests = defined_tests

	val = 0
	total = 0
	for test in tests:
		dir_tot, dir_val = run_one_test_directory(test, valid_problems, display, write_solution)
		total += dir_tot
		val += dir_val

	if not write_solution:
		if total > val:
			print(f"*** Some tests failed. Retry!")

		if total_tests == len(tests):
			print(f"Total points: {total}\nScored points: {val}\nScore: {val}/{total}")
else:
	try:
		folder, filename = onetest.split('/')
		folder = folder.strip()
		filename = filename.strip()
		script_dir = os.path.dirname(os.path.abspath(__file__))
		path = os.path.join(script_dir,"test_cases",folder, filename)

		# get the config details
		config_file_path = os.path.join(script_dir,"test_cases",folder, "CONFIG")
		config_file_data = parse_test_file(config_file_path)
		assert "maxPoints" in config_file_data
		total_points = float(config_file_data['maxPoints'])
		correct_pts = run_one_test(folder, filename, valid_problems, display, config_file_data['scheme'], write_solution)
		assert correct_pts <= total_points
		print("====================================================================\n")
	except FileNotFoundError:
		print(f'Invalid test case!')
		sys.exit(1)
	except ValueError as e:
		print(f'{e}')
		sys.exit(1)