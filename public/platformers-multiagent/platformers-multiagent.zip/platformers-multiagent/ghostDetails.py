import gameSettings

class GhostDetails:

	def __init__(self, index, pos):
		self.index = index
		self.pos = pos
		self.active = 0
		# active = 0 means currently active and active>0 means that many plies remaining to become active again
		self.facing = gameSettings.default_facing
		self.reborn = False
		self.initial_pos = pos

	def __str__(self):
		return f"index-{self.index} pos-{self.pos} active-{self.active} facing-{self.facing} reborn-{self.reborn}"

	def __repr__(self):
		return self.__str__()

	def deep_copy(self):
		copy_ghost_details = GhostDetails(self.index, self.pos)
		copy_ghost_details.active = self.active
		copy_ghost_details.facing = self.facing
		copy_ghost_details.reborn = self.reborn
		copy_ghost_details.initial_pos = self.initial_pos
		return copy_ghost_details

	def __eq__(self, other):
		if isinstance(other, GhostDetails):
			# if index matches, initial_pos will definitely match
			return self.index == other.index and self.pos == other.pos and self.active == other.active and self.facing == other.facing and self.reborn == other.reborn 

		return False

	def __hash__(self):
		# if index matches, initial_pos will definitely match	
		return hash((self.index, self.pos, self.active, self.facing, self.reborn))