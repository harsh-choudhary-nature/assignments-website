import utils

class RandomGhostAgent:
	def __init__(self, args):
		self.rng = args['rng']

	def act(self, agent_index, game_state, problem):
		actions = problem.get_actions(agent_index, game_state)
		if self.rng:
			return self.rng.choice(actions)
		return self.rng.choice(actions)

class StaticGhostAgent:
	def __init__(self, args):
		pass

	def act(self, agent_index, game_state, problem):
		return "noop"

''' tries to remain on the platform always'''
class PlatformGhostAgent:
	def __init__(self, args):
		pass
		self.rng = args['rng']

	def act(self, agent_index, game_state, problem):
		cur_ghost_pos_y = game_state.ghosts_details[agent_index-1].pos[0]
		actions = problem.get_actions(agent_index, game_state)

		action = self.rng.choice(actions)
		first_action = action
		next_game_state, _, _ = problem.ghost_rules.get_next_game_state(agent_index, game_state, action)
		next_ghost_pos_y = next_game_state.ghosts_details[agent_index-1].pos[0]

		while next_ghost_pos_y != cur_ghost_pos_y:
			actions.remove(action)
			if len(actions) == 0:
				return first_action
			
			action = self.rng.choice(actions)
			next_game_state, _, _ = problem.ghost_rules.get_next_game_state(agent_index, game_state, action)
			next_ghost_pos_y = next_game_state.ghosts_details[agent_index-1].pos[0]
		return action


class DirectionalGhostAgent:
	
	def __init__(self, args):
		pass
		self.epsilon = args['epsilon']
		self.rng = args['rng']

	def act(self, agent_index, game_state, problem):
		actions = problem.get_actions(agent_index, game_state)
		best_action, best_dist = None, 1e9
		player_pos = game_state.player_details.pos
		for action in actions:
			next_pos = problem.ghost_rules.get_next_game_state(agent_index, game_state, action)[0].ghosts_details[agent_index-1].pos
			next_dist = utils.graph_distance_bfs(next_pos, [player_pos], problem)
			if next_dist == -1:
				continue
			if next_dist < best_dist or best_action is None:
				best_action = action
				best_dist = next_dist
		
		if best_action is None:
			# choose the action that minimizes Manhattan distance
			for action in actions:
				next_pos = problem.ghost_rules.get_next_game_state(agent_index, game_state, action)[0].ghosts_details[agent_index-1].pos
				next_dist = utils.manhattan_distance(next_pos, player_pos)
				if next_dist<best_dist or best_action is None:
					best_action = action
					best_dist = next_dist
		# with 1 - self.epsilon probability choose best_action
		r = self.rng.random()
		if r<1 - self.epsilon:
			return best_action
		else:
			return self.rng.choice(actions)

