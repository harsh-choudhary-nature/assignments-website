import gameSettings
import graphicsUtils
import numpy as np

class Ghost:

	def __init__(self, agent_index, start_pos, fix_seed_value):
		self.rng = np.random.default_rng(seed = fix_seed_value)
		self.index = agent_index
		self.ghost_sprite_sheets = graphicsUtils.load_sprite_sheets(gameSettings.characters_folder ,gameSettings.ghost_name ,gameSettings.sprite_sheet_height ,gameSettings.sprite_sheet_height ,gameSettings.grid_size, True)
		self.locked = False
		self.dx = 0
		self.dy = 0
		self.gravity = gameSettings.gravity
		self.xvel = 1
		self.yvel = 0
		self.xvel_max = gameSettings.xvel_max
		self.yvel_max = gameSettings.yvel_max
		self.yvel_min = gameSettings.yvel_min
		self.sprite_index_cur_count = 0
		self.sprite_index_update_count = gameSettings.animation_update_cnt
		self.start_pos = start_pos
		self.cur_game_state = None
		self.ghost_action = "noop"
		self.next_game_state = None
		self.traced_path = None
		self.animation_suffix = self.rng.choice(["left", "right"])
		self.traced_path_index = 0
		self.frozen = False
		self.reborn = False
		self.action_animation_list_index = 0
		self.action_animation_list_map = { 	"noop": 	 		[["idle_"],["frozen_"]],
											"left":				[["run_", "fall_"]],
											"right":			[["run_", "fall_"]],
											"jump":				[["jump_wave_", "fall_"]],
											"short_jump_left":	[["jump_wave_", "jump_smoke_", "fall_"]],
											"short_jump_right":	[["jump_wave_", "jump_smoke_", "fall_"]],
											"long_jump_left":	[["jump_wave_", "jump_fire_", "fall_"]],
											"long_jump_right":	[["jump_wave_", "jump_fire_", "fall_"]]
											}
		self.sprite_sheet_cur_index = {	"idle_":		0,
										"run_":			0,
										"fall_":		0,
										"jump_wave_":	0,
										"jump_smoke_":	0,
										"jump_fire_":	0,
										"frozen_":		0
										}


	def init_animate(self, cur_game_state, ghost_action, next_game_state, traced_path):
		self.locked = True
		if (self.cur_game_state is not None and (self.cur_game_state.ghosts_details[self.index-1].active > 1 or (self.cur_game_state.ghosts_details[self.index-1].active == 1 and cur_game_state.ghosts_details[self.index-1].reborn))): 
			self.frozen = True 
		else:
			self.frozen = False
		self.cur_game_state = cur_game_state
		self.ghost_action = ghost_action
		self.next_game_state = next_game_state
		self.traced_path = traced_path
		self.animation_suffix = self.next_game_state.ghosts_details[self.index-1].facing
		self.traced_path_index = 0
		self.action_animation_list_index = 0
		self.yvel = self.yvel_max if ghost_action in {"jump", "short_jump_left", "long_jump_left", "short_jump_right", "handle_long_jump_right"} else 0
		self.reborn = self.cur_game_state.ghosts_details[self.index-1].reborn
		self.animate()

	def animate(self):

		if not self.locked:
			self.synchronize()
		elif self.ghost_action == "noop":
			self.handle_noop()
		elif self.ghost_action == "left":
			self.handle_left()
		elif self.ghost_action == "right":
			self.handle_right()
		elif self.ghost_action == "jump":
			self.handle_jump()
		elif self.ghost_action == "short_jump_left":
			self.handle_short_jump_left()
		elif self.ghost_action == "short_jump_right":
			self.handle_short_jump_right()
		elif self.ghost_action == "long_jump_left":
			self.handle_long_jump_left()
		elif self.ghost_action == "long_jump_right":
			self.handle_long_jump_right()

	def synchronize(self):
		return

	def handle_noop(self):
		self.unlock()
		# till the reborn sign is not off, this will not be rendered at the updated position, and this is handled by game.py itself

	def handle_left(self):
		if self.action_animation_list_index == 0:
			self.dx -= self.xvel
			if abs(self.dx)>=gameSettings.grid_size:
				self.action_animation_list_index += 1
		else:
			if abs(self.dx)<gameSettings.grid_size:
				self.dx -= self.xvel
			if abs(self.dy)<gameSettings.grid_size*(self.traced_path[-1][0]-self.traced_path[1][0]):
				self.dy += self.yvel
				self.yvel = min(self.yvel+self.gravity, self.yvel_max)
			elif abs(self.dx)>=gameSettings.grid_size:
				self.unlock()

	def handle_right(self):
		if self.action_animation_list_index == 0:
			self.dx += self.xvel
			if abs(self.dx) >= gameSettings.grid_size:
				self.action_animation_list_index += 1
		else:
			if abs(self.dx) < gameSettings.grid_size:
				self.dx += self.xvel
			if abs(self.dy) < gameSettings.grid_size*(self.traced_path[-1][0]-self.traced_path[1][0]):
				self.dy += self.yvel
				self.yvel = min(self.yvel+self.gravity, self.yvel_max)
			elif abs(self.dx) >= gameSettings.grid_size:
				self.unlock()

	def handle_jump(self):
		if self.action_animation_list_index == 0:
			self.dy -= self.yvel
			self.yvel = max(2*self.yvel_min, self.yvel - self.gravity)
			if abs(self.dy) >= gameSettings.grid_size:
				self.action_animation_list_index += 1
				self.yvel = self.yvel_min
		else:
			self.dy += self.yvel
			self.yvel = min(self.yvel_max, self.yvel + self.gravity)
			if self.dy >= 0:	# self.dy will be negative, and it being positive means reached initial position
				self.unlock()

	def handle_short_jump_left(self):
		if self.action_animation_list_index == 0:
			self.dy -= self.yvel
			self.yvel = max(self.yvel - self.gravity, 2*self.yvel_min)
			if abs(self.dx) < gameSettings.grid_size and abs(self.dy) >= gameSettings.grid_size*14//16:
				self.dx -= self.xvel
				self.xvel = min(self.xvel + 1, self.xvel_max)
			if abs(self.dy) >= gameSettings.grid_size:
				self.action_animation_list_index += 1
		elif self.action_animation_list_index == 1:
			self.dx -= self.xvel
			self.xvel = min(self.xvel + 1, self.xvel_max)
			if abs(self.dx) >= gameSettings.grid_size:
				self.action_animation_list_index += 1
				self.yvel = self.yvel_min
		else:
			if self.dy + gameSettings.grid_size < gameSettings.grid_size*(self.traced_path[-1][0]-self.traced_path[2][0]):	# sign important here
				self.dy += self.yvel
				self.yvel = max(self.yvel, self.yvel_max)
			else:
				self.unlock()

	def handle_short_jump_right(self):
		if self.action_animation_list_index == 0:
			self.dy -= self.yvel
			self.yvel = max(self.yvel - self.gravity, 2*self.yvel_min)
			if abs(self.dx) < gameSettings.grid_size and abs(self.dy) >= gameSettings.grid_size*14//16:
				self.dx += self.xvel
				self.xvel = min(self.xvel + 1, self.xvel_max)
			if abs(self.dy) >= gameSettings.grid_size:
				self.action_animation_list_index += 1
		elif self.action_animation_list_index == 1:
			self.dx += self.xvel
			self.xvel = min(self.xvel + 1, self.xvel_max)
			if abs(self.dx) >= gameSettings.grid_size:
				self.action_animation_list_index += 1
				self.yvel = self.yvel_min
		else:
			if self.dy + gameSettings.grid_size < gameSettings.grid_size*(self.traced_path[-1][0]-self.traced_path[2][0]):	# sign important here
				self.dy += self.yvel
				self.yvel = max(self.yvel, self.yvel_max)
			else:
				self.unlock()

	def handle_long_jump_left(self):
		if self.action_animation_list_index == 0:
			self.dy -= self.yvel
			self.yvel = max(self.yvel - self.gravity, 2*self.yvel_min)
			if abs(self.dx) < 2*gameSettings.grid_size and abs(self.dy) >= gameSettings.grid_size*14//16:
				self.dx -= self.xvel
				self.xvel = min(self.xvel + 1, self.xvel_max)
			if abs(self.dy) >= gameSettings.grid_size:
				self.action_animation_list_index += 1
		elif self.action_animation_list_index == 1:
			self.dx -= self.xvel
			self.xvel = min(self.xvel + 1, self.xvel_max)
			if abs(self.dx) >= 2*gameSettings.grid_size:
				self.action_animation_list_index += 1
				self.yvel = self.yvel_min
		else:
			if self.dy + gameSettings.grid_size < gameSettings.grid_size*(self.traced_path[-1][0]-self.traced_path[3][0]):	# sign important here
				self.dy += self.yvel
				self.yvel = max(self.yvel, self.yvel_max)
			else:
				self.unlock()

	def handle_long_jump_right(self):
		if self.action_animation_list_index == 0:
			self.dy -= self.yvel
			self.yvel = max(self.yvel - self.gravity, 2*self.yvel_min)
			if abs(self.dx) < 2*gameSettings.grid_size and abs(self.dy) >= gameSettings.grid_size*14//16:
				self.dx += self.xvel
				self.xvel = min(self.xvel + 1, self.xvel_max)
			if abs(self.dy) >= gameSettings.grid_size:
				self.action_animation_list_index += 1
		elif self.action_animation_list_index == 1:
			self.dx += self.xvel
			self.xvel = min(self.xvel + 1, self.xvel_max)
			if abs(self.dx) >= 2*gameSettings.grid_size:
				self.action_animation_list_index += 1
				self.yvel = self.yvel_min
		else:
			if self.dy + gameSettings.grid_size < gameSettings.grid_size*(self.traced_path[-1][0]-self.traced_path[3][0]):	# sign important here
				self.dy += self.yvel
				self.yvel = max(self.yvel, self.yvel_max)
			else:
				self.unlock()

	def unlock(self):
		self.cur_game_state = self.next_game_state
		self.ghost_action = "noop"
		self.next_game_state = None
		self.animation_suffix = self.cur_game_state.ghosts_details[self.index-1].facing
		self.action_animation_list_index = 0
		self.dx = 0
		self.dy = 0
		self.xvel = 1
		self.yvel = 0
		self.locked = False	

	def early_unlock(self):
		self.cur_game_state = self.next_game_state
		self.next_game_state = None
		self.animation_suffix = self.cur_game_state.ghosts_details[self.index-1].facing
		self.action_animation_list_index = 0
		self.dx = 0
		self.dy = 0
		self.xvel = 1
		self.yvel = 0
		self.locked = False	

	def draw(self, window, offset_x, offset_y):
		if self.cur_game_state is not None:
			ghost_pos = self.cur_game_state.ghosts_details[self.index-1].pos
		else:
			ghost_pos = self.start_pos

		x = ghost_pos[1]*gameSettings.grid_size + self.dx
		y = ghost_pos[0]*gameSettings.grid_size + self.dy

		cur_sprite_sheet_key = self.action_animation_list_map[self.ghost_action][int(self.frozen)][self.action_animation_list_index]
		cur_sprite_sheet_index = self.sprite_sheet_cur_index[cur_sprite_sheet_key]
		cur_sprite_sheet = cur_sprite_sheet_key + self.animation_suffix
		window.blit(self.ghost_sprite_sheets[cur_sprite_sheet][cur_sprite_sheet_index],(x-offset_x,y-offset_y))

		self.sprite_index_cur_count += 1
		if self.sprite_index_cur_count == self.sprite_index_update_count:
			self.sprite_sheet_cur_index[cur_sprite_sheet_key] = (cur_sprite_sheet_index + 1)%len(self.ghost_sprite_sheets[cur_sprite_sheet])
			self.sprite_index_cur_count = 0


	def draw_reborn_ghost_premature(self, window, offset_x, offset_y, pos, facing):
		x = pos[1]*gameSettings.grid_size
		y = pos[0]*gameSettings.grid_size

		cur_sprite_sheet_key = "frozen_" if self.frozen else "idle_"
		cur_sprite_sheet_index = self.sprite_sheet_cur_index[cur_sprite_sheet_key]
		cur_sprite_sheet = cur_sprite_sheet_key + facing
		window.blit(self.ghost_sprite_sheets[cur_sprite_sheet][cur_sprite_sheet_index],(x-offset_x,y-offset_y))

		self.sprite_index_cur_count += 1
		if self.sprite_index_cur_count == self.sprite_index_update_count:
			self.sprite_sheet_cur_index[cur_sprite_sheet_key] = (cur_sprite_sheet_index + 1)%len(self.ghost_sprite_sheets[cur_sprite_sheet])
			self.sprite_index_cur_count = 0